"""
Clases abstractas y estructuras de datos del sistema de agentes.

Define el contrato que todo arquetipo de depositante debe implementar,
así como las estructuras de estado y decisión que fluyen por el motor.
"""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional

logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════════════════
# Enumeraciones
# ═══════════════════════════════════════════════════════════════════════════

class ActionType(str, Enum):
    """Acciones posibles de un depositante."""
    HOLD = "hold"
    PARTIAL_WITHDRAW = "partial_withdraw"
    FULL_WITHDRAW = "full_withdraw"
    TRANSFER_OUT = "transfer_out"
    INCREASE_DEPOSIT = "increase_deposit"


class ChannelType(str, Enum):
    """Canales por los que un depositante puede actuar."""
    BRANCH = "branch"
    APP = "app"
    CALL_CENTER = "call_center"
    EXECUTIVE = "executive"
    ATM = "atm"


class AppState(str, Enum):
    """Estado operativo de la app móvil/banca en línea."""
    NORMAL = "normal"
    SLOW = "slow"
    DOWN = "down"


class QueueState(str, Enum):
    """Estado de filas en agencias."""
    NORMAL = "normal"
    LONG = "long"
    CRITICAL = "critical"


# ═══════════════════════════════════════════════════════════════════════════
# Estructuras de datos
# ═══════════════════════════════════════════════════════════════════════════

@dataclass
class ScenarioState:
    """Estado observable del escenario en un período dado.

    Este es el input que recibe cada agente para tomar su decisión.
    Se construye por el StateManager y se pasa al motor LLM.

    Attributes:
        period: Período actual (hora o mes).
        period_unit: Unidad temporal.
        rumor_intensity: Intensidad del rumor (0-10, módulo liquidez).
        app_state: Estado de la app.
        queue_state: Estado de filas en agencia.
        pct_population_acted: Fracción de población que ya retiró.
        cumulative_withdrawals_qm: Retiros acumulados en millones de quetzales.
        lcr_current: Ratio de cobertura de liquidez proyectado.
        intervention_active: Intervención activa en este período.
        intervention_history: Intervenciones ya aplicadas.
        delta_unemployment: Shock acumulado de desempleo (pp, módulo crédito).
        delta_inflation: Shock acumulado de inflación (pp, módulo crédito).
        depreciation_current_pct: Depreciación acumulada (%, módulo FX).
        depreciation_speed: Velocidad de depreciación.
        custom: Datos adicionales específicos del escenario.
    """
    period: int = 0
    period_unit: str = "horas"
    rumor_intensity: float = 0.0
    app_state: AppState = AppState.NORMAL
    queue_state: QueueState = QueueState.NORMAL
    pct_population_acted: float = 0.0
    cumulative_withdrawals_qm: float = 0.0
    lcr_current: float = 1.45
    intervention_active: Optional[str] = None
    intervention_history: list[str] = field(default_factory=list)
    # Módulo crédito
    delta_unemployment: float = 0.0
    delta_inflation: float = 0.0
    # Módulo FX
    depreciation_current_pct: float = 0.0
    depreciation_speed: str = "gradual"
    # Extensible
    custom: dict[str, Any] = field(default_factory=dict)

    def to_prompt_context(self) -> str:
        """Genera texto descriptivo del estado para el prompt del LLM."""
        lines = [
            f"Período actual: {self.period} ({self.period_unit})",
        ]
        if self.rumor_intensity > 0:
            lines.append(
                f"Intensidad del rumor en redes: {self.rumor_intensity:.1f}/10"
            )
        if self.app_state != AppState.NORMAL:
            labels = {AppState.SLOW: "lenta y con errores", AppState.DOWN: "caída completamente"}
            lines.append(f"La aplicación del banco está {labels.get(self.app_state, str(self.app_state.value))}")
        if self.queue_state != QueueState.NORMAL:
            labels = {QueueState.LONG: "largas (30+ minutos)", QueueState.CRITICAL: "críticas (2+ horas, policía presente)"}
            lines.append(f"Las filas en agencias están {labels.get(self.queue_state, str(self.queue_state.value))}")
        if self.pct_population_acted > 0:
            lines.append(
                f"Aproximadamente {self.pct_population_acted * 100:.1f}% de los clientes "
                f"ya han retirado fondos"
            )
        if self.cumulative_withdrawals_qm > 0:
            lines.append(
                f"Retiros acumulados: Q{self.cumulative_withdrawals_qm:,.1f} millones"
            )
        if self.intervention_active:
            labels = {
                "comunicado_oficial": "El banco acaba de emitir un comunicado oficial negando problemas",
                "ejecutivos_llaman": "Los ejecutivos de cuenta están llamando a clientes importantes",
                "refinanciamiento_masivo": "El banco está ofreciendo refinanciamiento masivo",
                "intervencion_banguat": "El Banco de Guatemala ha intervenido en el mercado cambiario",
            }
            lines.append(labels.get(self.intervention_active, f"Intervención activa: {self.intervention_active}"))
        if self.delta_unemployment > 0:
            lines.append(f"El desempleo ha subido {self.delta_unemployment:.1f} puntos porcentuales")
        if self.delta_inflation > 0:
            lines.append(f"La inflación ha subido {self.delta_inflation:.1f} puntos porcentuales")
        if self.depreciation_current_pct > 0:
            lines.append(
                f"El quetzal se ha depreciado {self.depreciation_current_pct:.1f}% frente al dólar"
            )
        return "\n".join(lines)


@dataclass
class AgentDecision:
    """Resultado de la decisión de un agente.

    Attributes:
        agent_id: Identificador del arquetipo.
        action: Acción decidida.
        probability: Probabilidad de ejecución (0.0-1.0).
        channel: Canal preferido.
        reasoning: Razonamiento del LLM o del fallback.
        used_llm: Si la decisión vino del LLM (True) o fallback (False).
        raw_llm_response: Respuesta cruda del LLM para auditoría.
        amount_pct: Porcentaje del saldo a retirar (0-100).
    """
    agent_id: str
    action: ActionType
    probability: float
    channel: ChannelType
    reasoning: str
    used_llm: bool = False
    raw_llm_response: Optional[str] = None
    amount_pct: float = 0.0

    def __post_init__(self) -> None:
        """Valida y acota la probabilidad."""
        self.probability = max(0.0, min(1.0, self.probability))
        self.amount_pct = max(0.0, min(100.0, self.amount_pct))


# ═══════════════════════════════════════════════════════════════════════════
# Agente base abstracto
# ═══════════════════════════════════════════════════════════════════════════

class BaseAgent(ABC):
    """Clase base para todos los arquetipos de agentes simulados.

    Cada agente representa un segmento de depositantes con comportamiento
    propio. Debe implementar la descripción de persona (para el prompt LLM)
    y un fallback determinístico.

    Attributes:
        agent_id: Identificador único del arquetipo.
        name: Nombre descriptivo.
        population: Número de individuos representados.
        avg_balance_q: Saldo promedio en quetzales.
        sensitivity: Sensibilidad al rumor (0.0-1.0).
        panic_threshold: Umbral de pánico colectivo (0.0-1.0).
        preferred_channel: Canal habitual.
        latency_periods: Períodos de latencia antes de actuar.
        panic_multiplier: Multiplicador de pánico sobre otros agentes.
        age: Edad representativa.
    """

    def __init__(
        self,
        agent_id: str,
        name: str,
        population: int,
        avg_balance_q: float,
        sensitivity: float,
        panic_threshold: float,
        preferred_channel: ChannelType,
        latency_periods: int = 0,
        panic_multiplier: float = 1.0,
        age: int = 40,
    ) -> None:
        self.agent_id = agent_id
        self.name = name
        self.population = population
        self.avg_balance_q = avg_balance_q
        self.sensitivity = sensitivity
        self.panic_threshold = panic_threshold
        self.preferred_channel = preferred_channel
        self.latency_periods = latency_periods
        self.panic_multiplier = panic_multiplier
        self.age = age
        self._acted_count: int = 0
        self._decision_history: list[dict[str, Any]] = []

        logger.debug(
            "Agente creado: %s (pop=%d, balance=Q%.0f, sens=%.2f)",
            agent_id, population, avg_balance_q, sensitivity,
        )

    @property
    def remaining_population(self) -> int:
        """Individuos que aún no han actuado."""
        return max(0, self.population - self._acted_count)

    @property
    def pct_acted(self) -> float:
        """Fracción de la población que ya actuó."""
        if self.population == 0:
            return 0.0
        return self._acted_count / self.population

    def record_actions(self, count: int) -> None:
        """Registra que `count` individuos actuaron."""
        self._acted_count = min(self.population, self._acted_count + count)

    def record_decision(
        self,
        period: int,
        state: "ScenarioState",
        decision: "AgentDecision",
        n_acted: int = 0,
    ) -> None:
        """Registra una decisión en la memoria del agente.

        La memoria persiste entre períodos y se incluye en el prompt
        del LLM para que el agente "recuerde" lo que decidió antes.

        Args:
            period: Período de la decisión.
            state: Estado del escenario cuando se tomó la decisión.
            decision: La decisión tomada.
            n_acted: Cuántos individuos del segmento actuaron.
        """
        self._decision_history.append({
            "period": period,
            "rumor_intensity": round(state.rumor_intensity, 1),
            "pct_population_acted": round(state.pct_population_acted * 100, 1),
            "app_state": state.app_state.value,
            "queue_state": state.queue_state.value,
            "intervention": state.intervention_active,
            "my_action": decision.action.value,
            "my_probability": round(decision.probability, 3),
            "my_reasoning": decision.reasoning[:150] if decision.reasoning else "",
            "n_acted_in_my_segment": n_acted,
            "pct_my_segment_acted": round(
                self._acted_count / self.population * 100, 1
            ) if self.population > 0 else 0,
        })

    def get_memory_narrative(self) -> str:
        """Genera un resumen narrativo de las decisiones pasadas.

        En lugar de solo listar JSON, genera un texto que el LLM
        puede interpretar como experiencia vivida.

        Returns:
            Texto con la memoria del agente, o vacío si no hay historia.
        """
        if not self._decision_history:
            return ""

        lines = ["--- MI EXPERIENCIA EN ESTA CRISIS (lo que ya viví) ---"]

        for mem in self._decision_history:
            period = mem["period"]
            action_labels = {
                "hold": "decidí no hacer nada y esperar",
                "partial_withdraw": "retiré una parte de mis fondos",
                "full_withdraw": "retiré todo mi dinero",
                "transfer_out": "transferí mis fondos a otro banco",
                "latencia": "no me había enterado todavía",
                "amplify_panic": "el ambiente se sentía tenso",
            }
            action_text = action_labels.get(mem["my_action"], mem["my_action"])

            line = f"Hora {period}: El rumor estaba en {mem['rumor_intensity']}/10"

            if mem.get("intervention"):
                intv_labels = {
                    "comunicado_oficial": ", el banco había emitido un comunicado oficial",
                    "ejecutivos_llaman": ", los ejecutivos del banco estaban llamando a clientes",
                }
                line += intv_labels.get(mem["intervention"], f", había intervención: {mem['intervention']}")

            line += f". El {mem['pct_population_acted']}% de los clientes ya había actuado."

            if mem["app_state"] != "normal":
                app_labels = {"slow": "La app del banco iba lenta.", "down": "La app del banco estaba caída."}
                line += f" {app_labels.get(mem['app_state'], '')}"

            if mem["queue_state"] != "normal":
                q_labels = {"long": "Las filas en agencia eran largas.", "critical": "Las filas eran enormes, había policía."}
                line += f" {q_labels.get(mem['queue_state'], '')}"

            line += f" Yo {action_text}."

            if mem["n_acted_in_my_segment"] > 0:
                line += f" De las personas como yo, {mem['pct_my_segment_acted']}% ya había retirado."

            lines.append(line)

        lines.append(
            "\nAhora ha pasado más tiempo. La situación puede haber cambiado. "
            "Basándote en lo que ya viviste y en la situación actual, ¿qué harías AHORA?"
        )

        return "\n".join(lines)

    def reset(self) -> None:
        """Reinicia el agente para una nueva simulación."""
        self._acted_count = 0
        self._decision_history = []

    def can_act_in_period(self, period: int) -> bool:
        """Verifica si el agente puede actuar en el período dado.

        Respeta la latencia configurada.
        """
        return period > self.latency_periods

    @abstractmethod
    def persona_description(self) -> str:
        """Retorna la descripción en primera persona para el prompt LLM.

        Debe incluir edad, perfil financiero, relación con el banco,
        preocupaciones y comportamiento habitual.
        """

    @abstractmethod
    def fallback_decision(self, state: ScenarioState) -> AgentDecision:
        """Decisión determinística cuando el LLM no está disponible.

        Esta función SIEMPRE debe retornar un resultado válido.
        Implementa la heurística del arquetipo.

        Args:
            state: Estado actual del escenario.

        Returns:
            AgentDecision con la decisión determinística.
        """

    def build_prompt(self, state: ScenarioState) -> str:
        """Construye el prompt completo para el LLM, incluyendo memoria.

        Estructura del prompt:
          1. Persona: quién sos
          2. Memoria: qué decidiste antes y qué pasó (si hay historia)
          3. Situación actual: qué está pasando ahora
          4. Instrucción: qué formato de respuesta

        La memoria es lo que diferencia este sistema de un modelo
        paramétrico. Sin memoria, el LLM pattern-matchea. Con memoria,
        el LLM razona sobre una experiencia acumulada.

        Args:
            state: Estado actual del escenario.

        Returns:
            Prompt listo para enviar al LLM.
        """
        memory = self.get_memory_narrative()

        prompt = (
            f"Eres un cliente de banco en Guatemala. Tu perfil:\n\n"
            f"{self.persona_description()}\n\n"
        )

        if memory:
            prompt += f"{memory}\n\n"

        prompt += (
            f"--- SITUACIÓN ACTUAL (hora {state.period}) ---\n"
            f"{state.to_prompt_context()}\n\n"
            f"--- INSTRUCCIÓN ---\n"
        )

        if memory:
            prompt += (
                f"Ya viviste las horas anteriores de esta crisis. "
                f"Tu estado emocional ACUMULA lo que ya pasó — si antes "
                f"estabas nervioso y la situación empeoró, ahora estás más "
                f"nervioso. Si el banco actuó y te calmaste, puede que "
                f"ahora estés más tranquilo.\n\n"
                f"Considerando todo lo que ya viviste y la situación ACTUAL, "
                f"decide qué harías AHORA.\n"
            )
        else:
            prompt += (
                f"Es el inicio de la crisis. Acabás de enterarte de la situación.\n"
                f"Basándote en tu perfil y la situación actual, decide qué harías.\n"
            )

        prompt += (
            f"\nResponde ÚNICAMENTE con un JSON válido (sin markdown, sin texto adicional):\n"
            f'{{\n'
            f'  "action": "hold" | "partial_withdraw" | "full_withdraw" | "transfer_out",\n'
            f'  "probability": 0.0 a 1.0,\n'
            f'  "amount_pct": 0 a 100,\n'
            f'  "channel": "branch" | "app" | "call_center" | "executive" | "atm",\n'
            f'  "reasoning": "Explicación de tu decisión considerando tu experiencia previa"\n'
            f'}}\n'
        )

        return prompt

    def __repr__(self) -> str:
        return (
            f"{self.__class__.__name__}(id={self.agent_id!r}, "
            f"pop={self.population}, balance=Q{self.avg_balance_q:,.0f})"
        )
