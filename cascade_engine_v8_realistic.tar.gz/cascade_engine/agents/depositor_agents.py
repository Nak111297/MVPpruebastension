"""
Los 5 arquetipos concretos de depositantes para el módulo de liquidez.

Cada clase implementa:
  - persona_description(): perfil en primera persona para el prompt LLM.
  - fallback_decision(): heurística determinística calibrada.

Los parámetros por defecto son sintéticos y pueden sobreescribirse
mediante calibration.apply_calibration_to_agents() sin tocar este código.
"""

from __future__ import annotations

import logging
from typing import Optional

from agents.base_agent import (
    ActionType,
    AgentDecision,
    AppState,
    BaseAgent,
    ChannelType,
    QueueState,
    ScenarioState,
)

logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════════════════
# 1. Conservador Mayor (+55 años)
# ═══════════════════════════════════════════════════════════════════════════

class ConservadorMayorAgent(BaseAgent):
    """Pensionado/rentista, alta sensibilidad, actúa en agencia.

    Perfil: +55 años, Q45,000 saldo promedio, depende del banco para
    pensión y ahorros de vida. Alta sensibilidad al rumor (85%).
    Umbral de pánico bajo (30%) — actúa rápido cuando ve filas.
    """

    def __init__(
        self,
        population: int = 18_000,
        avg_balance_q: float = 45_000.0,
        **overrides,
    ) -> None:
        defaults = dict(
            agent_id="conservador_mayor",
            name="Conservador Mayor (+55)",
            population=population,
            avg_balance_q=avg_balance_q,
            sensitivity=0.85,
            panic_threshold=0.30,
            preferred_channel=ChannelType.BRANCH,
            latency_periods=0,
            panic_multiplier=1.0,
            age=62,
        )
        defaults.update(overrides)
        super().__init__(**defaults)

    def persona_description(self) -> str:
        return (
            f"Tengo {self.age} años y soy jubilado. Mis ahorros de toda la vida "
            f"están en G&T Continental — aproximadamente Q{self.avg_balance_q:,.0f}. "
            f"Mi pensión se deposita aquí cada mes. No uso la aplicación del "
            f"teléfono; siempre voy a la agencia personalmente. "
            f"Si escucho que el banco tiene problemas, me preocupo mucho "
            f"porque no tengo otra fuente de ingresos. "
            f"Cuando veo filas largas en la agencia, me asusto más. "
            f"Prefiero retirar todo y guardar el efectivo en mi casa antes "
            f"que arriesgar mis ahorros."
        )

    def fallback_decision(self, state: ScenarioState) -> AgentDecision:
        """Heurística: alta reacción al rumor, retira en agencia."""
        intensity = state.rumor_intensity / 10.0
        base_prob = intensity * self.sensitivity

        # Amplifica si filas son largas (retroalimenta el pánico)
        if state.queue_state == QueueState.CRITICAL:
            base_prob *= 1.3
        elif state.queue_state == QueueState.LONG:
            base_prob *= 1.15

        # El comunicado lo calma parcialmente
        if state.intervention_active == "comunicado_oficial":
            base_prob *= 0.55

        # Si muchos ya retiraron, entra en pánico
        if state.pct_population_acted > self.panic_threshold:
            base_prob *= 1.25

        base_prob = min(base_prob, 0.95)

        if base_prob > 0.5:
            action = ActionType.FULL_WITHDRAW
            amount_pct = 100.0
        elif base_prob > 0.25:
            action = ActionType.PARTIAL_WITHDRAW
            amount_pct = 50.0
        else:
            action = ActionType.HOLD
            amount_pct = 0.0

        return AgentDecision(
            agent_id=self.agent_id,
            action=action,
            probability=base_prob,
            channel=ChannelType.BRANCH,
            reasoning=(
                f"Fallback determinístico: intensidad={intensity:.2f}, "
                f"filas={state.queue_state.value}, prob={base_prob:.3f}"
            ),
            used_llm=False,
            amount_pct=amount_pct,
        )


# ═══════════════════════════════════════════════════════════════════════════
# 2. Empresario con Crédito
# ═══════════════════════════════════════════════════════════════════════════

class EmpresarioCreditoAgent(BaseAgent):
    """Empresario con crédito activo — salir le cuesta.

    Perfil: 45 años, Q200,000 saldo, tiene línea de crédito activa.
    Baja sensibilidad (35%) porque mover su relación crediticia es costoso.
    Umbral de pánico alto (60%) — necesita mucha evidencia para actuar.
    Opera a través de su ejecutivo de cuenta.
    """

    def __init__(
        self,
        population: int = 4_500,
        avg_balance_q: float = 200_000.0,
        **overrides,
    ) -> None:
        defaults = dict(
            agent_id="empresario_credito",
            name="Empresario con Crédito",
            population=population,
            avg_balance_q=avg_balance_q,
            sensitivity=0.35,
            panic_threshold=0.60,
            preferred_channel=ChannelType.EXECUTIVE,
            latency_periods=0,
            panic_multiplier=1.0,
            age=45,
        )
        defaults.update(overrides)
        super().__init__(**defaults)

    def persona_description(self) -> str:
        return (
            f"Tengo {self.age} años y soy empresario. Tengo Q{self.avg_balance_q:,.0f} "
            f"en mi cuenta empresarial en G&T Continental, además de una línea "
            f"de crédito activa que uso para mi negocio. Mi ejecutivo de cuenta "
            f"me atiende directamente. No puedo mover mi crédito fácilmente a "
            f"otro banco, así que solo retiraría depósitos en un caso extremo. "
            f"Soy racional y analizo la situación antes de actuar. "
            f"Si mi ejecutivo me llama para tranquilizarme, probablemente "
            f"me quede."
        )

    def fallback_decision(self, state: ScenarioState) -> AgentDecision:
        """Heurística: bajo pánico, reacciona a niveles extremos."""
        intensity = state.rumor_intensity / 10.0
        base_prob = intensity * self.sensitivity

        # Los ejecutivos llamando lo calman mucho
        if state.intervention_active == "ejecutivos_llaman":
            base_prob *= 0.30

        if state.intervention_active == "comunicado_oficial":
            base_prob *= 0.60

        # Solo se asusta si mucha gente ya retiró
        if state.pct_population_acted > self.panic_threshold:
            base_prob *= 1.4

        base_prob = min(base_prob, 0.85)

        if base_prob > 0.55:
            action = ActionType.PARTIAL_WITHDRAW
            amount_pct = 60.0
        elif base_prob > 0.30:
            action = ActionType.PARTIAL_WITHDRAW
            amount_pct = 30.0
        else:
            action = ActionType.HOLD
            amount_pct = 0.0

        return AgentDecision(
            agent_id=self.agent_id,
            action=action,
            probability=base_prob,
            channel=ChannelType.EXECUTIVE,
            reasoning=(
                f"Fallback determinístico: intensidad={intensity:.2f}, "
                f"intervención={state.intervention_active}, prob={base_prob:.3f}"
            ),
            used_llm=False,
            amount_pct=amount_pct,
        )


# ═══════════════════════════════════════════════════════════════════════════
# 3. Millennial Digital
# ═══════════════════════════════════════════════════════════════════════════

class MillennialDigitalAgent(BaseAgent):
    """Joven digital — rápido para actuar, amplifica el rumor.

    Perfil: 31 años, Q15,000 saldo, usa exclusivamente la app.
    Si la app cae, transfiere por otro medio. Comparte noticias en redes
    sociales, amplificando el rumor para otros segmentos.
    Sensibilidad media-alta (65%), umbral de pánico bajo (20%).
    """

    def __init__(
        self,
        population: int = 35_000,
        avg_balance_q: float = 15_000.0,
        **overrides,
    ) -> None:
        defaults = dict(
            agent_id="millennial_digital",
            name="Millennial Digital",
            population=population,
            avg_balance_q=avg_balance_q,
            sensitivity=0.65,
            panic_threshold=0.20,
            preferred_channel=ChannelType.APP,
            latency_periods=0,
            panic_multiplier=1.0,
            age=31,
        )
        defaults.update(overrides)
        super().__init__(**defaults)
        self.rumor_amplification: float = 0.3  # Incremento adicional al rumor

    def persona_description(self) -> str:
        return (
            f"Tengo {self.age} años. Mi saldo en G&T Continental es "
            f"Q{self.avg_balance_q:,.0f} — no es mucho pero es lo que tengo. "
            f"Hago todo por la app. Si veo algo raro en Twitter o TikTok "
            f"sobre el banco, lo comparto y busco mover mi dinero rápido. "
            f"Si la app del banco se cae, eso me confirma que hay problemas "
            f"y busco transferir por otro canal. No espero — actúo rápido. "
            f"Prefiero equivocarme por precavido que perder mi dinero."
        )

    def get_effective_channel(self, state: ScenarioState) -> ChannelType:
        """Si la app está caída, usa canal alternativo."""
        if state.app_state == AppState.DOWN:
            return ChannelType.CALL_CENTER
        if state.app_state == AppState.SLOW:
            return ChannelType.APP  # Intenta de todos modos
        return ChannelType.APP

    def fallback_decision(self, state: ScenarioState) -> AgentDecision:
        """Heurística: reacción rápida, amplifica si app cae."""
        intensity = state.rumor_intensity / 10.0
        base_prob = intensity * self.sensitivity

        # App caída amplifica su miedo
        if state.app_state == AppState.DOWN:
            base_prob *= 1.5
        elif state.app_state == AppState.SLOW:
            base_prob *= 1.2

        # Umbral de pánico bajo
        if state.pct_population_acted > self.panic_threshold:
            base_prob *= 1.3

        # Comunicado oficial tiene efecto moderado (desconfía de instituciones)
        if state.intervention_active == "comunicado_oficial":
            base_prob *= 0.75

        base_prob = min(base_prob, 0.95)
        channel = self.get_effective_channel(state)

        if base_prob > 0.40:
            action = ActionType.TRANSFER_OUT
            amount_pct = 90.0
        elif base_prob > 0.20:
            action = ActionType.PARTIAL_WITHDRAW
            amount_pct = 50.0
        else:
            action = ActionType.HOLD
            amount_pct = 0.0

        return AgentDecision(
            agent_id=self.agent_id,
            action=action,
            probability=base_prob,
            channel=channel,
            reasoning=(
                f"Fallback determinístico: intensidad={intensity:.2f}, "
                f"app={state.app_state.value}, prob={base_prob:.3f}"
            ),
            used_llm=False,
            amount_pct=amount_pct,
        )


# ═══════════════════════════════════════════════════════════════════════════
# 4. Cliente Rural
# ═══════════════════════════════════════════════════════════════════════════

class ClienteRuralAgent(BaseAgent):
    """Cliente rural — latencia alta, pero cuando actúa retira todo.

    Perfil: 48 años, Q7,500 saldo, vive lejos de la agencia.
    Se entera tarde (2 períodos de latencia). Baja sensibilidad (40%)
    pero umbral de pánico alto (70%) — cuando decide, retira el 100%.
    """

    def __init__(
        self,
        population: int = 22_000,
        avg_balance_q: float = 7_500.0,
        **overrides,
    ) -> None:
        defaults = dict(
            agent_id="cliente_rural",
            name="Cliente Rural",
            population=population,
            avg_balance_q=avg_balance_q,
            sensitivity=0.40,
            panic_threshold=0.70,
            preferred_channel=ChannelType.BRANCH,
            latency_periods=2,
            panic_multiplier=1.0,
            age=48,
        )
        defaults.update(overrides)
        super().__init__(**defaults)

    def persona_description(self) -> str:
        return (
            f"Tengo {self.age} años y vivo en un área rural de Guatemala. "
            f"Tengo Q{self.avg_balance_q:,.0f} ahorrados en G&T Continental. "
            f"La agencia más cercana está a una hora de camino. "
            f"No uso smartphone ni redes sociales. Me entero de las "
            f"noticias por la radio o por vecinos, generalmente con uno o "
            f"dos días de retraso. Si me entero de que el banco tiene "
            f"problemas graves, hago el viaje a la agencia y retiro todo "
            f"mi dinero — no me arriesgo con mis ahorros."
        )

    def fallback_decision(self, state: ScenarioState) -> AgentDecision:
        """Heurística: llega tarde pero retira todo."""
        # Respeta latencia
        if not self.can_act_in_period(state.period):
            return AgentDecision(
                agent_id=self.agent_id,
                action=ActionType.HOLD,
                probability=0.0,
                channel=ChannelType.BRANCH,
                reasoning=f"Latencia: no se ha enterado aún (período {state.period} < {self.latency_periods + 1})",
                used_llm=False,
                amount_pct=0.0,
            )

        intensity = state.rumor_intensity / 10.0
        base_prob = intensity * self.sensitivity

        # Solo actúa si la situación es realmente grave
        if state.pct_population_acted > self.panic_threshold:
            base_prob *= 1.5

        if state.intervention_active == "comunicado_oficial":
            base_prob *= 0.50  # La radio lo calma bastante

        base_prob = min(base_prob, 0.90)

        # Cuando decide, retira todo
        if base_prob > 0.35:
            action = ActionType.FULL_WITHDRAW
            amount_pct = 100.0
        else:
            action = ActionType.HOLD
            amount_pct = 0.0

        return AgentDecision(
            agent_id=self.agent_id,
            action=action,
            probability=base_prob,
            channel=ChannelType.BRANCH,
            reasoning=(
                f"Fallback determinístico: intensidad={intensity:.2f}, "
                f"pct_acted={state.pct_population_acted:.3f}, prob={base_prob:.3f}"
            ),
            used_llm=False,
            amount_pct=amount_pct,
        )


# ═══════════════════════════════════════════════════════════════════════════
# 5. Empleado de Agencia (impacto indirecto)
# ═══════════════════════════════════════════════════════════════════════════

class EmpleadoAgenciaAgent(BaseAgent):
    """Empleado del banco — no retira, pero amplifica el pánico.

    Perfil: 450 personas, saldo 0 (impacto indirecto).
    Su nerviosismo, comentarios y lenguaje corporal amplifican el miedo
    de los clientes que están en la agencia. Multiplicador ×1.4.
    """

    def __init__(
        self,
        population: int = 450,
        avg_balance_q: float = 0.0,
        **overrides,
    ) -> None:
        defaults = dict(
            agent_id="empleado_agencia",
            name="Empleado de Agencia",
            population=population,
            avg_balance_q=avg_balance_q,
            sensitivity=0.50,
            panic_threshold=0.40,
            preferred_channel=ChannelType.BRANCH,
            latency_periods=0,
            panic_multiplier=1.4,
            age=32,
        )
        defaults.update(overrides)
        super().__init__(**defaults)

    def persona_description(self) -> str:
        return (
            f"Tengo {self.age} años y trabajo como cajero en una agencia "
            f"de G&T Continental. Si empiezo a ver filas largas y clientes "
            f"nerviosos retirando todo, me pongo ansioso. Mi nerviosismo "
            f"se nota y los clientes lo perciben. Si la situación se pone "
            f"grave, empiezo a comentar con compañeros y eso se filtra "
            f"a los clientes. No retiro dinero del banco, pero mi actitud "
            f"puede acelerar o calmar la situación."
        )

    def fallback_decision(self, state: ScenarioState) -> AgentDecision:
        """Heurística: genera multiplicador de pánico, no retira."""
        intensity = state.rumor_intensity / 10.0
        base_prob = intensity * self.sensitivity

        if state.queue_state == QueueState.CRITICAL:
            base_prob *= 1.4
        elif state.queue_state == QueueState.LONG:
            base_prob *= 1.2

        base_prob = min(base_prob, 0.90)

        # No retira dinero — su "acción" es amplificar el pánico
        return AgentDecision(
            agent_id=self.agent_id,
            action=ActionType.HOLD,
            probability=base_prob,
            channel=ChannelType.BRANCH,
            reasoning=(
                f"Empleado no retira; pánico amplificado ×{self.panic_multiplier}. "
                f"Intensidad percibida={intensity:.2f}, filas={state.queue_state.value}"
            ),
            used_llm=False,
            amount_pct=0.0,
        )


# ═══════════════════════════════════════════════════════════════════════════
# Agente Genérico (para arquetipos generados por data_processor.py)
# ═══════════════════════════════════════════════════════════════════════════

class GenericDepositAgent(BaseAgent):
    """Agente genérico que funciona con cualquier arquetipo calibrado.

    Usa los parámetros del dict de calibración para definir su comportamiento.
    El fallback_decision es una heurística universal basada en sensibilidad,
    umbral de pánico, y el patrón de retiro configurado.
    """

    def __init__(self, config: dict) -> None:
        channel_map = {
            "branch": ChannelType.BRANCH,
            "app": ChannelType.APP,
            "call_center": ChannelType.CALL_CENTER,
            "executive": ChannelType.EXECUTIVE,
            "atm": ChannelType.ATM,
            "agencia": ChannelType.BRANCH,
            "ejecutivo": ChannelType.EXECUTIVE,
        }
        ch = channel_map.get(
            config.get("preferred_channel", "branch"), ChannelType.BRANCH
        )

        super().__init__(
            agent_id=config["id"],
            name=config.get("name", config["id"]),
            population=config.get("population", 100),
            avg_balance_q=config.get("avg_balance_q", 0),
            sensitivity=config.get("sensitivity", 0.5),
            panic_threshold=config.get("panic_threshold", 0.4),
            preferred_channel=ch,
            latency_periods=config.get("latency_periods", 0),
            panic_multiplier=config.get("panic_multiplier", 1.0),
            age=config.get("age", 40),
        )
        self._withdrawal_pattern = config.get("withdrawal_pattern", "partial_withdraw")
        self._info_channel = config.get("info_channel", "redes")
        self.rumor_amplification = config.get("rumor_amplification", 0.0)
        self._config = config

    def persona_description(self) -> str:
        return (
            f"Soy un cliente de {self.name} en G&T Continental. "
            f"Mi saldo es de Q{self.avg_balance_q:,.0f}. "
            f"Opero principalmente por {self.preferred_channel.value}. "
            f"Me informo por canales {self._info_channel}."
        )

    def fallback_decision(self, state: ScenarioState) -> AgentDecision:
        """Heurística universal basada en parámetros calibrados."""
        # Respetar latencia
        if not self.can_act_in_period(state.period):
            return AgentDecision(
                agent_id=self.agent_id,
                action=ActionType.HOLD,
                probability=0.0,
                channel=self.preferred_channel,
                reasoning=f"En latencia hasta período {self.latency_periods + 1}",
                used_llm=False,
                amount_pct=0.0,
            )

        # Empleados no retiran
        if self._withdrawal_pattern == "amplify_panic":
            intensity = state.rumor_intensity / 10.0
            prob = intensity * self.sensitivity
            if state.queue_state == QueueState.CRITICAL:
                prob *= 1.4
            return AgentDecision(
                agent_id=self.agent_id,
                action=ActionType.HOLD,
                probability=min(prob, 0.95),
                channel=self.preferred_channel,
                reasoning=f"Amplificador: prob={prob:.3f}, mult={self.panic_multiplier}",
                used_llm=False,
                amount_pct=0.0,
            )

        # Probabilidad base
        intensity = state.rumor_intensity / 10.0
        base_prob = intensity * self.sensitivity

        # Efecto de canal de información sobre la sensibilidad
        if self._info_channel == "redes" and state.app_state == AppState.DOWN:
            base_prob *= 1.4
        elif self._info_channel == "redes" and state.app_state == AppState.SLOW:
            base_prob *= 1.15

        # Efecto de filas
        if state.queue_state == QueueState.CRITICAL:
            base_prob *= 1.25
        elif state.queue_state == QueueState.LONG:
            base_prob *= 1.1

        # Umbral de pánico colectivo
        if state.pct_population_acted > self.panic_threshold:
            overflow = (state.pct_population_acted - self.panic_threshold)
            base_prob *= (1.0 + overflow * 0.5)

        # Efecto de intervenciones
        if state.intervention_active == "comunicado_oficial":
            if self._info_channel in ("institucional", "ejecutivo"):
                base_prob *= 0.45
            elif self._info_channel == "gremial":
                base_prob *= 0.60
            else:
                base_prob *= 0.75
        elif state.intervention_active == "ejecutivos_llaman":
            if self.preferred_channel == ChannelType.EXECUTIVE:
                base_prob *= 0.30
            else:
                base_prob *= 0.80

        base_prob = min(base_prob, 0.95)

        # Patrón de retiro → acción y monto
        # No hay umbral mínimo — la probabilidad baja produce pocos retiros
        # vía muestreo binomial en el agregador. Eso es realista.
        if base_prob < 0.005:
            # Menos de 0.5% → nadie actúa
            action = ActionType.HOLD
            amount_pct = 0.0
        elif self._withdrawal_pattern == "full_withdraw":
            action = ActionType.FULL_WITHDRAW
            amount_pct = 100.0
        elif self._withdrawal_pattern == "transfer_out":
            action = ActionType.TRANSFER_OUT
            amount_pct = 90.0
        elif self._withdrawal_pattern == "partial_withdraw":
            # El monto varía con la probabilidad: más miedo → más retiro
            if base_prob > 0.30:
                action = ActionType.PARTIAL_WITHDRAW
                amount_pct = 60.0
            elif base_prob > 0.10:
                action = ActionType.PARTIAL_WITHDRAW
                amount_pct = 40.0
            else:
                action = ActionType.PARTIAL_WITHDRAW
                amount_pct = 25.0
        else:
            action = ActionType.PARTIAL_WITHDRAW
            amount_pct = 30.0

        # Canal con spillover si app caída
        channel = self.preferred_channel
        if channel == ChannelType.APP and state.app_state == AppState.DOWN:
            channel = ChannelType.CALL_CENTER

        return AgentDecision(
            agent_id=self.agent_id,
            action=action,
            probability=base_prob,
            channel=channel,
            reasoning=(
                f"Genérico: int={intensity:.2f}, sens={self.sensitivity}, "
                f"prob={base_prob:.3f}, patrón={self._withdrawal_pattern}"
            ),
            used_llm=False,
            amount_pct=amount_pct,
        )


# ═══════════════════════════════════════════════════════════════════════════
# Factories
# ═══════════════════════════════════════════════════════════════════════════

def create_all_depositor_agents() -> list[BaseAgent]:
    """Crea los 5 arquetipos sintéticos por defecto.

    Returns:
        Lista de agentes instanciados listos para simulación.
    """
    agents: list[BaseAgent] = [
        ConservadorMayorAgent(),
        EmpresarioCreditoAgent(),
        MillennialDigitalAgent(),
        ClienteRuralAgent(),
        EmpleadoAgenciaAgent(),
    ]
    logger.info(
        "Creados %d arquetipos de depositantes (pop total=%d)",
        len(agents),
        sum(a.population for a in agents),
    )
    return agents


def create_agents_from_calibration(segments: list[dict]) -> list[BaseAgent]:
    """Crea agentes genéricos a partir de datos calibrados (data_processor.py).

    Args:
        segments: Lista de dicts con parámetros de cada arquetipo.

    Returns:
        Lista de GenericDepositAgent instanciados.
    """
    agents: list[BaseAgent] = []
    for seg in segments:
        agent = GenericDepositAgent(seg)
        agents.append(agent)

    total_pop = sum(a.population for a in agents)
    total_balance = sum(a.avg_balance_q * a.population for a in agents)
    logger.info(
        "Creados %d arquetipos desde calibración (pop=%d, saldo=Q%.0fM)",
        len(agents), total_pop, total_balance / 1_000_000,
    )
    return agents
