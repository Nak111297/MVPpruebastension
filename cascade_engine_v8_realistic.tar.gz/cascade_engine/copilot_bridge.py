"""
Puente Copilot — Pre-genera decisiones de arquetipos usando M365 Copilot.

FLUJO DE TRABAJO:
  1. Correr: python copilot_bridge.py --generate
     → Genera archivos de texto con prompts listos para copiar a Copilot
  2. Copiar cada prompt a Copilot, pegar la respuesta en el archivo correspondiente
  3. Correr: python copilot_bridge.py --parse
     → Lee las respuestas y genera decision_matrix.json
  4. Correr: python run.py --liquidity
     → El motor usa la matriz pre-generada en vez de Ollama

Esto te da calidad de GPT-4 sin necesidad de API ni Ollama.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

# Asegurar imports
ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from agents.base_agent import ScenarioState, AppState, QueueState


# ═══════════════════════════════════════════════════════════════════
# CONFIGURACIÓN DE ESTADOS DE ESCENARIO
# ═══════════════════════════════════════════════════════════════════

def get_scenario_progression(scenario_id: str = "liq_001") -> list[dict[str, Any]]:
    """Define la progresión de estados hora a hora para un escenario.

    Estos son los estados que el motor genera internamente.
    Cada estado representa lo que el agente "ve" en esa hora.
    """
    progressions = {
        "liq_001": [  # Corrida sin intervención
            {"period": 1, "rumor": 5.0, "pct_acted": 0.0, "app": "normal", "queue": "normal", "intervention": None},
            {"period": 2, "rumor": 6.5, "pct_acted": 0.10, "app": "normal", "queue": "normal", "intervention": None},
            {"period": 3, "rumor": 7.5, "pct_acted": 0.25, "app": "slow", "queue": "normal", "intervention": None},
            {"period": 4, "rumor": 8.5, "pct_acted": 0.40, "app": "slow", "queue": "long", "intervention": None},
            {"period": 5, "rumor": 9.0, "pct_acted": 0.55, "app": "down", "queue": "long", "intervention": None},
            {"period": 6, "rumor": 9.5, "pct_acted": 0.70, "app": "down", "queue": "critical", "intervention": None},
            {"period": 7, "rumor": 10.0, "pct_acted": 0.85, "app": "down", "queue": "critical", "intervention": None},
            {"period": 8, "rumor": 10.0, "pct_acted": 0.92, "app": "down", "queue": "critical", "intervention": None},
        ],
        "liq_002": [  # Corrida con comunicado hora 2
            {"period": 1, "rumor": 5.0, "pct_acted": 0.0, "app": "normal", "queue": "normal", "intervention": None},
            {"period": 2, "rumor": 3.5, "pct_acted": 0.10, "app": "normal", "queue": "normal", "intervention": "comunicado_oficial"},
            {"period": 3, "rumor": 4.5, "pct_acted": 0.15, "app": "normal", "queue": "normal", "intervention": None},
            {"period": 4, "rumor": 5.5, "pct_acted": 0.22, "app": "normal", "queue": "normal", "intervention": None},
            {"period": 5, "rumor": 7.0, "pct_acted": 0.35, "app": "slow", "queue": "normal", "intervention": None},
            {"period": 6, "rumor": 8.0, "pct_acted": 0.50, "app": "slow", "queue": "long", "intervention": None},
            {"period": 7, "rumor": 9.0, "pct_acted": 0.70, "app": "down", "queue": "long", "intervention": None},
            {"period": 8, "rumor": 9.5, "pct_acted": 0.85, "app": "down", "queue": "critical", "intervention": None},
        ],
        "liq_003": [  # Corrida con ejecutivos hora 5
            {"period": 1, "rumor": 7.0, "pct_acted": 0.0, "app": "normal", "queue": "normal", "intervention": None},
            {"period": 2, "rumor": 8.0, "pct_acted": 0.15, "app": "normal", "queue": "normal", "intervention": None},
            {"period": 3, "rumor": 9.0, "pct_acted": 0.35, "app": "slow", "queue": "long", "intervention": None},
            {"period": 4, "rumor": 9.5, "pct_acted": 0.55, "app": "slow", "queue": "long", "intervention": None},
            {"period": 5, "rumor": 8.5, "pct_acted": 0.65, "app": "down", "queue": "critical", "intervention": "ejecutivos_llaman"},
            {"period": 6, "rumor": 9.0, "pct_acted": 0.75, "app": "down", "queue": "critical", "intervention": None},
            {"period": 7, "rumor": 9.5, "pct_acted": 0.85, "app": "down", "queue": "critical", "intervention": None},
            {"period": 8, "rumor": 10.0, "pct_acted": 0.92, "app": "down", "queue": "critical", "intervention": None},
        ],
        "liq_004": [  # Corrida severa - app caída desde hora 1
            {"period": 1, "rumor": 9.0, "pct_acted": 0.0, "app": "down", "queue": "normal", "intervention": None},
            {"period": 2, "rumor": 9.5, "pct_acted": 0.25, "app": "down", "queue": "critical", "intervention": None},
            {"period": 3, "rumor": 10.0, "pct_acted": 0.45, "app": "down", "queue": "critical", "intervention": None},
            {"period": 4, "rumor": 10.0, "pct_acted": 0.65, "app": "down", "queue": "critical", "intervention": None},
            {"period": 5, "rumor": 10.0, "pct_acted": 0.80, "app": "down", "queue": "critical", "intervention": None},
            {"period": 6, "rumor": 10.0, "pct_acted": 0.88, "app": "down", "queue": "critical", "intervention": None},
            {"period": 7, "rumor": 10.0, "pct_acted": 0.93, "app": "down", "queue": "critical", "intervention": None},
            {"period": 8, "rumor": 10.0, "pct_acted": 0.96, "app": "down", "queue": "critical", "intervention": None},
        ],
    }
    return progressions.get(scenario_id, progressions["liq_001"])


# ═══════════════════════════════════════════════════════════════════
# ARQUETIPOS (las personas para el LLM)
# ═══════════════════════════════════════════════════════════════════

ARCHETYPES = {
    "corporativo_aaa": {
        "persona": (
            "Soy el director financiero de una de las empresas más grandes del país. "
            "Tengo Q400 millones depositados en G&T Continental — es la posición de "
            "tesorería de la empresa. También tenemos una línea de crédito sindicada "
            "de Q200 millones con el banco. Me informo por Bloomberg, por otros CFOs "
            "que conozco, y por nuestro ejecutivo de cuenta que es el VP de Banca "
            "Corporativa. No uso redes sociales para decisiones financieras. "
            "Mover nuestra relación crediticia a otro banco tomaría meses y costaría "
            "comisiones significativas. Pero si creo que el banco está en riesgo real, "
            "la obligación fiduciaria con mis accionistas me obliga a proteger el capital "
            "sin importar el costo de mudanza."
        ),
    },
    "empresa_mediana_credito": {
        "persona": (
            "Soy dueño de una empresa mediana de distribución de alimentos. Tengo "
            "Q25 millones en mi cuenta empresarial en G&T Continental y una línea "
            "de crédito revolvente de Q15 millones que uso para capital de trabajo. "
            "Mi ejecutivo de cuenta me atiende directamente — nos conocemos hace 8 años. "
            "Me entero de las noticias por el grupo de WhatsApp de la Cámara de Comercio "
            "y por otros empresarios de mi gremio. Si me preocupo, lo primero que hago "
            "es llamar a mi ejecutivo. Si él me convence, me quedo. Si no, empiezo a "
            "desviar la facturación nueva a otro banco — no retiro de golpe porque "
            "necesito la línea de crédito activa para seguir operando."
        ),
    },
    "institucional_gobierno": {
        "persona": (
            "Soy el director financiero de un fondo de pensiones público. Tenemos "
            "Q150 millones depositados en G&T Continental como parte de nuestra "
            "cartera de inversiones de renta fija. Cualquier movimiento de fondos "
            "requiere aprobación de la junta directiva, lo que toma mínimo 2-3 días "
            "hábiles. No reacciono a rumores de redes sociales — solo actúo si hay "
            "una comunicación oficial de la Superintendencia de Bancos o si la "
            "calificadora baja el rating del banco. Si la junta aprueba mover los "
            "fondos, se mueve el 100% porque es una decisión institucional."
        ),
    },
    "pyme_comerciante": {
        "persona": (
            "Tengo una cadena de 3 ferreterías en zona 12, 18 y Mixco. Mi cuenta "
            "empresarial en G&T Continental tiene entre Q2 y Q5 millones dependiendo "
            "de la semana — es flujo de caja, no ahorro. No tengo crédito con el banco. "
            "Me entero de todo por WhatsApp — el grupo de la cámara, otros ferreteros, "
            "mi contador. Si me dicen que el banco tiene problemas, mi primer instinto "
            "es sacar al menos la mitad. No voy a arriesgar la planilla de mis 45 "
            "empleados. Si la app del banco no funciona, eso me confirma que algo anda mal."
        ),
    },
    "pyme_credito": {
        "persona": (
            "Tengo una fábrica de plásticos con 80 empleados. En G&T Continental tengo "
            "Q8 millones en cuenta corriente y un préstamo de Q12 millones para la "
            "maquinaria nueva. Si me voy del banco pierdo las condiciones del préstamo "
            "— la tasa es preferencial porque tengo 12 años de ser cliente. Mi ejecutivo "
            "me conoce bien. Si él me dice que todo está bajo control, le creo. Pero "
            "si veo que otros empresarios que conozco están sacando su plata, me empiezo "
            "a preocupar porque ellos saben cosas que yo no sé."
        ),
    },
    "asalariado_nomina": {
        "persona": (
            "Trabajo como contador en una empresa privada. Mi sueldo se deposita en "
            "G&T Continental cada quincena — unos Q12,000. Tengo Q35,000 ahorrados "
            "en la cuenta. No tengo ejecutivo de cuenta ni nadie que me llame. Me "
            "entero de las noticias por Facebook y TikTok, y por lo que me cuentan "
            "en la oficina. Si escucho que el banco tiene problemas, me asusto porque "
            "es todo lo que tengo. Mi primera reacción es abrir la app para ver mi "
            "saldo — si la app no funciona, me confirma que hay problema y voy a la "
            "agencia más cercana. No me importa hacer fila 2 horas si es para proteger "
            "mis Q35,000."
        ),
    },
    "depositante_alto_valor": {
        "persona": (
            "Soy médico especialista con 52 años. Tengo Q1.2 millones entre cuenta "
            "de ahorro y un plazo fijo a 6 meses en G&T Continental. Mi ejecutivo de "
            "banca premium me atiende. Me informo por medios serios — Prensa Libre, "
            "elPeriódico, y por conversaciones con otros profesionales. No tomo "
            "decisiones impulsivas — primero llamo a mi ejecutivo, luego analizo. "
            "Pero si la situación se pone realmente grave, prefiero pagar la penalización "
            "por romper el plazo fijo antes que arriesgar Q1.2 millones. El dinero "
            "representa 15 años de ahorro."
        ),
    },
    "digital_joven": {
        "persona": (
            "Tengo 26 años, trabajo en marketing digital. Mi cuenta en G&T Continental "
            "tiene Q8,000 — no es mucho. Hago todo por la app, nunca voy a agencia. "
            "Si veo algo raro sobre el banco en Twitter o TikTok, inmediatamente lo "
            "comparto y busco transferir a mi cuenta de Banrural por si acaso. "
            "No espero — actúo primero, pregunto después. Si la app del banco se cae, "
            "eso es la confirmación definitiva de que algo está mal y lo publico "
            "inmediatamente. Sé que Q8,000 no es nada para el banco, pero es mi "
            "salario de medio mes."
        ),
    },
    "empleado_agencia": {
        "persona": (
            "Tengo 29 años y trabajo como cajero en la agencia de zona 10 de G&T Continental. "
            "Si empiezo a ver más clientes de lo normal retirando montos grandes, me pongo "
            "nervioso. Si la fila crece y la gente se ve asustada, mi ansiedad se nota — "
            "mis manos tiemblan, tardo más en cada transacción, y los clientes lo perciben. "
            "Si un compañero me dice al oído 'esto se está poniendo feo', probablemente se "
            "me escape un comentario con un cliente. No retiro dinero del banco porque me "
            "descubren, pero mi actitud puede calmar o acelerar el pánico de los clientes "
            "que están en la agencia."
        ),
    },
}


# ═══════════════════════════════════════════════════════════════════
# GENERACIÓN DE PROMPTS
# ═══════════════════════════════════════════════════════════════════

def generate_prompts(output_dir: str = "copilot_prompts") -> None:
    """Genera archivos de texto con prompts listos para Copilot.

    Cada archivo contiene UN prompt por arquetipo por escenario.
    El prompt incluye las 8 horas de la corrida para que el LLM
    genere todas las decisiones de una vez, manteniendo coherencia
    narrativa a lo largo de la crisis.
    """
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)

    scenarios = ["liq_001", "liq_002", "liq_003", "liq_004"]
    scenario_names = {
        "liq_001": "Corrida sin intervención del banco",
        "liq_002": "Corrida con comunicado oficial en hora 2",
        "liq_003": "Corrida con ejecutivos llamando en hora 5",
        "liq_004": "Corrida severa — app caída desde hora 1, filas críticas desde hora 2",
    }

    intervention_descriptions = {
        "comunicado_oficial": "El banco acaba de emitir un comunicado oficial en medios diciendo que es financieramente sólido y que los rumores son falsos.",
        "ejecutivos_llaman": "Los ejecutivos de cuenta del banco están llamando personalmente a clientes importantes para tranquilizarlos.",
    }

    file_count = 0
    for scenario_id in scenarios:
        progression = get_scenario_progression(scenario_id)

        for arch_id, arch_data in ARCHETYPES.items():
            prompt = _build_full_prompt(
                arch_id, arch_data, scenario_id,
                scenario_names[scenario_id],
                progression, intervention_descriptions,
            )

            filename = f"{scenario_id}__{arch_id}.txt"
            filepath = out / filename

            # Escribir prompt
            with open(filepath, "w", encoding="utf-8") as f:
                f.write("=" * 70 + "\n")
                f.write(f"PROMPT PARA COPILOT\n")
                f.write(f"Escenario: {scenario_id} — {scenario_names[scenario_id]}\n")
                f.write(f"Arquetipo: {arch_id}\n")
                f.write("=" * 70 + "\n\n")
                f.write("INSTRUCCIONES: Copiar todo lo de abajo y pegarlo en Copilot.\n")
                f.write("Luego copiar la respuesta de Copilot y pegarla debajo de la línea '--- RESPUESTA DE COPILOT ---'\n\n")
                f.write("-" * 70 + "\n\n")
                f.write(prompt)
                f.write("\n\n" + "-" * 70 + "\n")
                f.write("--- RESPUESTA DE COPILOT ---\n")
                f.write("(Pegar aquí la respuesta completa de Copilot)\n\n\n")

            file_count += 1

    print(f"\n  ✓ {file_count} archivos de prompt generados en: {output_dir}/")
    print(f"  → {len(ARCHETYPES)} arquetipos × {len(scenarios)} escenarios")
    print(f"\n  SIGUIENTE PASO:")
    print(f"  1. Abrí cada archivo .txt")
    print(f"  2. Copiá el prompt (todo entre las líneas de guiones)")
    print(f"  3. Pegalo en Copilot")
    print(f"  4. Copiá la respuesta de Copilot")
    print(f"  5. Pegala debajo de '--- RESPUESTA DE COPILOT ---'")
    print(f"  6. Guardá el archivo")
    print(f"  7. Cuando tengas todos, corré: python copilot_bridge.py --parse")
    print()
    print(f"  TIP: Empezá con liq_001 (sin intervención) — son {len(ARCHETYPES)} prompts.")
    print(f"  Si ves que las respuestas son buenas, hacé los otros 3 escenarios.")
    print()


def _build_full_prompt(
    arch_id: str,
    arch_data: dict,
    scenario_id: str,
    scenario_name: str,
    progression: list[dict],
    interventions: dict,
) -> str:
    """Construye el prompt completo para un arquetipo en un escenario.

    El prompt pide al LLM que viva las 8 horas como una experiencia
    continua, generando una decisión por hora con razonamiento.
    """
    prompt = f"""Necesito que simules ser una persona específica durante una crisis bancaria en Guatemala. Vas a vivir 8 horas de esta crisis y en cada hora vas a decidir qué harías con tu dinero.

IMPORTANTE: Mantené la coherencia emocional. Lo que viviste en hora 1 afecta cómo te sentís en hora 2. Si te asustaste antes, ahora estás más nervioso. Si el banco te calmó, tal vez estés más tranquilo. Sos una persona real con emociones que se acumulan.

--- TU PERFIL ---
{arch_data['persona']}

--- ESCENARIO ---
{scenario_name}

--- LAS 8 HORAS DE LA CRISIS ---
Voy a describir qué pasa cada hora. Para cada hora, respondé con un JSON.

"""
    for state in progression:
        period = state["period"]
        prompt += f"\n{'='*50}\nHORA {period}\n{'='*50}\n"
        prompt += f"Intensidad del rumor en redes: {state['rumor']}/10\n"
        prompt += f"Porcentaje de clientes que ya retiró: {state['pct_acted']*100:.0f}%\n"

        if state["app"] != "normal":
            app_labels = {"slow": "La app del banco va lenta y con errores", "down": "La app del banco está completamente caída"}
            prompt += f"{app_labels.get(state['app'], '')}\n"

        if state["queue"] != "normal":
            q_labels = {"long": "Las filas en agencias son de 30+ minutos", "critical": "Las filas son de 2+ horas, hay policía afuera"}
            prompt += f"{q_labels.get(state['queue'], '')}\n"

        if state.get("intervention"):
            prompt += f"\n{interventions.get(state['intervention'], state['intervention'])}\n"

        prompt += f"""
Considerando todo lo que ya viviste en las horas anteriores y tu estado emocional acumulado, respondé SOLO con este JSON para hora {period}:

hora_{period}: {{
  "action": "hold" | "partial_withdraw" | "full_withdraw" | "transfer_out" | "increase_deposit" | "redirect_cashflow",
  "probability": 0.0 a 1.0,
  "amount_pct": 0 a 100,
  "channel": "branch" | "app" | "call_center" | "executive" | "atm" | "swift",
  "reasoning": "Tu razonamiento como esta persona, considerando lo que ya pasaste"
}}

"""

    prompt += f"""
{'='*50}
FORMATO DE RESPUESTA FINAL
{'='*50}
Dame las 8 decisiones como un JSON array. Ejemplo:
[
  {{"hour": 1, "action": "hold", "probability": 0.1, "amount_pct": 0, "channel": "executive", "reasoning": "..."}},
  {{"hour": 2, "action": "partial_withdraw", "probability": 0.4, "amount_pct": 30, "channel": "executive", "reasoning": "..."}},
  ...
]

Recordá: sos {arch_id.replace('_', ' ')}. Mantené tu personalidad consistente durante las 8 horas. Tu miedo, confianza y decisiones se acumulan.
"""
    return prompt


# ═══════════════════════════════════════════════════════════════════
# PARSING DE RESPUESTAS
# ═══════════════════════════════════════════════════════════════════

def parse_responses(input_dir: str = "copilot_prompts", output_file: str = "data/decision_matrix.json") -> None:
    """Lee las respuestas de Copilot y genera la matriz de decisiones.

    Busca en cada archivo .txt la sección después de
    '--- RESPUESTA DE COPILOT ---' y extrae el JSON.
    """
    in_dir = Path(input_dir)
    matrix: dict[str, dict[str, list[dict]]] = {}
    parsed = 0
    failed = 0

    for filepath in sorted(in_dir.glob("*.txt")):
        # Extraer scenario_id y arch_id del nombre
        name = filepath.stem  # liq_001__corporativo_aaa
        parts = name.split("__")
        if len(parts) != 2:
            continue
        scenario_id, arch_id = parts

        # Leer archivo
        text = filepath.read_text(encoding="utf-8")

        # Buscar respuesta de Copilot
        marker = "--- RESPUESTA DE COPILOT ---"
        if marker not in text:
            continue

        response_text = text.split(marker)[1].strip()
        if not response_text or response_text.startswith("(Pegar"):
            continue  # No hay respuesta todavía

        # Intentar parsear JSON
        decisions = _extract_json_array(response_text)
        if decisions:
            if scenario_id not in matrix:
                matrix[scenario_id] = {}
            matrix[scenario_id][arch_id] = decisions
            parsed += 1
            print(f"  ✓ {scenario_id} / {arch_id}: {len(decisions)} decisiones")
        else:
            failed += 1
            print(f"  ✗ {scenario_id} / {arch_id}: no se pudo parsear JSON")

    if parsed > 0:
        output_path = Path(output_file)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump({
                "source": "copilot_m365",
                "generated_at": str(Path(input_dir)),
                "scenarios": matrix,
            }, f, indent=2, ensure_ascii=False)

        print(f"\n  ✓ Matriz guardada en: {output_file}")
        print(f"    {parsed} arquetipos parseados, {failed} fallidos")
        print(f"\n  El motor la detecta automáticamente al correr sin --offline.")
    else:
        print(f"\n  ⚠ No se encontraron respuestas de Copilot.")
        print(f"  Verificá que pegaste las respuestas debajo de '--- RESPUESTA DE COPILOT ---'")


def _extract_json_array(text: str) -> list[dict] | None:
    """Extrae un JSON array de texto, manejando markdown y texto extra."""
    import re

    # Limpiar markdown
    text = text.strip()

    # Buscar código JSON en markdown blocks
    match = re.search(r"```(?:json)?\s*\n?(.+?)\n?\s*```", text, re.DOTALL)
    if match:
        text = match.group(1)

    # Buscar array JSON
    match = re.search(r"\[.*\]", text, re.DOTALL)
    if match:
        try:
            data = json.loads(match.group(0))
            if isinstance(data, list):
                return data
        except json.JSONDecodeError:
            pass

    # Intentar parsear todo el texto
    try:
        data = json.loads(text)
        if isinstance(data, list):
            return data
    except json.JSONDecodeError:
        pass

    return None


# ═══════════════════════════════════════════════════════════════════
# CLI
# ═══════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(
        description="Puente Copilot — genera prompts y parsea respuestas",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Flujo:
  1. python copilot_bridge.py --generate
  2. Copiar cada prompt a Copilot, pegar respuesta en el archivo
  3. python copilot_bridge.py --parse
  4. python run.py --liquidity  (usa la matriz automáticamente)
        """,
    )

    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--generate", action="store_true", help="Generar prompts para Copilot")
    group.add_argument("--parse", action="store_true", help="Parsear respuestas de Copilot")
    group.add_argument("--status", action="store_true", help="Ver cuántos prompts faltan por responder")

    parser.add_argument("--dir", default="copilot_prompts", help="Directorio de prompts (default: copilot_prompts/)")
    parser.add_argument("--output", default="data/decision_matrix.json", help="Archivo de salida de la matriz")

    args = parser.parse_args()

    if args.generate:
        generate_prompts(args.dir)
    elif args.parse:
        parse_responses(args.dir, args.output)
    elif args.status:
        _show_status(args.dir)


def _show_status(input_dir: str) -> None:
    """Muestra cuántos prompts tienen respuesta y cuántos faltan."""
    in_dir = Path(input_dir)
    if not in_dir.exists():
        print(f"  Directorio {input_dir}/ no existe. Corré --generate primero.")
        return

    total = 0
    answered = 0
    pending = []

    for filepath in sorted(in_dir.glob("*.txt")):
        total += 1
        text = filepath.read_text(encoding="utf-8")
        marker = "--- RESPUESTA DE COPILOT ---"
        if marker in text:
            response = text.split(marker)[1].strip()
            if response and not response.startswith("(Pegar"):
                answered += 1
                continue
        pending.append(filepath.stem)

    print(f"\n  Respondidos: {answered}/{total}")
    if pending:
        print(f"  Pendientes:")
        for p in pending[:10]:
            print(f"    → {p}")
        if len(pending) > 10:
            print(f"    ... y {len(pending) - 10} más")
    else:
        print(f"  ✓ ¡Todos respondidos! Corré: python copilot_bridge.py --parse")


if __name__ == "__main__":
    main()
