"""
Procesador de datos del DWH → Arquetipos para el motor de cascada.

USO:
    python data/data_processor.py --input tu_archivo.csv --output data/calibrated_segments.json

ESTE SCRIPT:
    1. Lee el CSV que te entregó el equipo de BI
    2. Clasifica cada cuenta en un arquetipo basado en reglas simples
    3. Calcula los parámetros que necesita el motor (población, saldo, etc.)
    4. Exporta un JSON listo para que calibration.py lo consuma
    5. Genera un reporte en consola de lo que encontró

FORMATO DEL CSV ESPERADO:
    Columnas mínimas (los nombres se pueden cambiar abajo en COLUMN_MAP):
    - id_cliente:     Identificador anonimizado
    - saldo:          Saldo disponible en quetzales
    - tipo_cuenta:    Ej: "ahorro", "monetaria", "empresarial", "plazo_fijo"
    - tiene_credito:  "si" / "no" (o 1 / 0)
    - monto_credito:  Monto del crédito si tiene (0 si no)
    - canal_principal: "app", "agencia", "ejecutivo", "banca_empresarial"
    - antiguedad_anios: Años como cliente
    - tipo_persona:   "individual" / "juridica" (persona o empresa)

    Si tu CSV tiene nombres diferentes, cambiá el diccionario COLUMN_MAP abajo.
"""

from __future__ import annotations

import argparse
import json
import logging
import sys
from pathlib import Path
from typing import Any

import pandas as pd
import numpy as np

logging.basicConfig(level=logging.INFO, format="%(message)s")
logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════════
# CONFIGURACIÓN — MODIFICÁ ESTO SEGÚN TU CSV
# ═══════════════════════════════════════════════════════════════════

# Si las columnas de tu CSV tienen nombres diferentes, cambiá el valor
# (derecha) para que coincida con tu archivo. La clave (izquierda) no se toca.
COLUMN_MAP = {
    "id_cliente": "KnCliente",
    "saldo": "TOTAL_PASIVO",
    "tipo_cuenta": "BxProductoXpert",
    "tipo_persona": "TipoPersona",
    # Columnas que no existen en la tabla — se derivan o se asumen
    # "tiene_credito": no disponible (tabla de activos no confiable)
    # "canal_principal": no disponible (se asume por tipo de cuenta/persona)
    # "antiguedad_anios": no disponible
}

# Mapeo de tipos de cuenta del banco a categorías internas
TIPO_CUENTA_MAP = {
    "AHORRO": "ahorro",
    "ODSAHO": "ahorro",
    "MONETA": "monetaria",
    "ODSMON": "monetaria",
    "ODSCDP": "plazo_fijo",     # Certificado de Depósito a Plazo — tiene ancla
    "FOGYT": "fondo_gyt",       # Fondo G&T — tratar como plazo fijo para ancla
}

# Umbrales para clasificar cuentas.
# Estos son los cortes que definen cada arquetipo.
# Ajustalos según lo que veas en la distribución de tu data.
THRESHOLDS = {
    # Capa 1: Corporativo e Institucional
    "corporativo_aaa_min_saldo": 50_000_000,     # Q50M+ → Corporativo AAA
    "empresa_mediana_min_saldo": 5_000_000,       # Q5M-Q50M con crédito → Empresa Mediana
    "institucional_tipos": ["gobierno", "institucional", "fideicomiso", "municipal"],

    # Capa 2: PYME y Comercial
    "pyme_min_saldo": 500_000,                    # Q500K-Q5M empresa → PYME
    "pyme_max_saldo": 5_000_000,

    # Capa 3: Personas
    "alto_valor_min_saldo": 150_000,              # Q150K+ individual → Alto Valor
    "digital_max_edad_cuenta": 5,                 # Menos de 5 años + canal app → Digital Joven
    "digital_canal": "app",
}

# Parámetros de comportamiento por defecto para cada arquetipo.
#
# CALIBRACIÓN REALISTA:
# En un escenario moderado (rumor 5-6), debería actuar ~8-12% de la población.
# En un escenario severo (rumor 8-10), debería actuar ~15-25%.
# Esto produce supuestos de retiro fundamentados para las pruebas de tensión.
#
# sensitivity = probabilidad base de actuar cuando el rumor está en 10/10.
#   No es "probabilidad de pánico" — es la fracción del segmento que
#   consideraría actuar incluso en el peor escenario. La mayoría de la
#   gente no se entera, no le importa, o no tiene alternativa.
#
DEFAULT_BEHAVIOR = {
    "corporativo_aaa": {
        "sensitivity": 0.04,          # ~3-8% actúa en moderado, ~15-20% en severo
        "panic_threshold": 0.30,
        "preferred_channel": "executive",
        "latency_periods": 0,
        "panic_multiplier": 1.5,
        "withdrawal_pattern": "partial_withdraw",
        "info_channel": "institucional",
    },
    "empresa_mediana_credito": {
        "sensitivity": 0.03,          # Ancla fuerte por crédito
        "panic_threshold": 0.40,
        "preferred_channel": "executive",
        "latency_periods": 0,
        "panic_multiplier": 1.0,
        "withdrawal_pattern": "partial_withdraw",
        "info_channel": "gremial",
    },
    "institucional_gobierno": {
        "sensitivity": 0.02,          # Casi no reaccionan a rumores
        "panic_threshold": 0.60,
        "preferred_channel": "executive",
        "latency_periods": 2,
        "panic_multiplier": 1.0,
        "withdrawal_pattern": "full_withdraw",
        "info_channel": "institucional",
    },
    "pyme_comerciante": {
        "sensitivity": 0.07,          # Las más reactivas
        "panic_threshold": 0.20,
        "preferred_channel": "branch",
        "latency_periods": 1,
        "panic_multiplier": 1.1,
        "withdrawal_pattern": "partial_withdraw",
        "info_channel": "gremial",
    },
    "pyme_credito": {
        "sensitivity": 0.03,
        "panic_threshold": 0.45,
        "preferred_channel": "executive",
        "latency_periods": 1,
        "panic_multiplier": 1.0,
        "withdrawal_pattern": "partial_withdraw",
        "info_channel": "ejecutivo",
    },
    "depositante_alto_valor": {
        "sensitivity": 0.04,          # Tiene ejecutivo, no actúa impulsivamente
        "panic_threshold": 0.35,
        "preferred_channel": "executive",
        "latency_periods": 0,
        "panic_multiplier": 1.0,
        "withdrawal_pattern": "partial_withdraw",
        "info_channel": "ejecutivo",
    },
    "retail_general": {
        "sensitivity": 0.015,         # La gran mayoría ni se entera ni actúa
        "panic_threshold": 0.25,
        "preferred_channel": "app",
        "latency_periods": 1,
        "panic_multiplier": 1.0,
        "withdrawal_pattern": "partial_withdraw",
        "info_channel": "redes",
        "rumor_amplification": 0.10,
    },
    "empleado_agencia": {
        "sensitivity": 0.10,
        "panic_threshold": 0.30,
        "preferred_channel": "branch",
        "latency_periods": 0,
        "panic_multiplier": 1.3,
        "withdrawal_pattern": "amplify_panic",
        "info_channel": "interno",
    },
}


# ═══════════════════════════════════════════════════════════════════
# LÓGICA DE CLASIFICACIÓN
# ═══════════════════════════════════════════════════════════════════

def load_csv(path: str) -> pd.DataFrame:
    """Carga el CSV del DWH de G&T Continental.

    Espera columnas: KnCliente, TOTAL_PASIVO, BxProductoXpert, TipoPersona
    (más cualquier otra que venga en el extract).
    """
    logger.info(f"\n{'='*60}")
    logger.info(f"  Cargando: {path}")
    logger.info(f"{'='*60}")

    for sep in [",", ";", "\t", "|"]:
        try:
            df = pd.read_csv(path, sep=sep, encoding="utf-8")
            if len(df.columns) > 2:
                break
        except Exception:
            continue
    else:
        df = pd.read_csv(path, encoding="latin-1")

    logger.info(f"  Filas: {len(df):,}")
    logger.info(f"  Columnas encontradas: {list(df.columns)}")

    # Renombrar a nombres internos
    reverse_map = {v: k for k, v in COLUMN_MAP.items()}
    df = df.rename(columns=reverse_map)

    # Normalizar saldo
    df["saldo"] = pd.to_numeric(df["saldo"], errors="coerce").fillna(0)

    # Normalizar tipo_persona (NULL → Individual)
    df["tipo_persona"] = df["tipo_persona"].fillna("Individual")
    df["tipo_persona"] = df["tipo_persona"].apply(
        lambda x: str(x).strip().lower()
    )
    # Mapear a valores consistentes
    df["tipo_persona"] = df["tipo_persona"].map(
        lambda x: "juridica" if "jur" in x else "individual"
    )

    # Normalizar tipo_cuenta usando el mapeo del banco
    if "tipo_cuenta" in df.columns:
        df["tipo_cuenta_original"] = df["tipo_cuenta"]
        df["tipo_cuenta"] = df["tipo_cuenta"].map(
            lambda x: TIPO_CUENTA_MAP.get(str(x).strip().upper(), "ahorro")
        )

    # Campos que no existen en la tabla — valores por defecto
    df["tiene_credito"] = False  # Se aproxima por reglas en classify_account
    df["monto_credito"] = 0
    df["antiguedad_anios"] = 5   # Default sin dato
    df["canal_principal"] = "agencia"  # Default sin dato

    logger.info(f"  Saldo total: Q{df['saldo'].sum():,.0f}")
    logger.info(f"  Saldo promedio: Q{df['saldo'].mean():,.0f}")
    logger.info(f"  Saldo mediana: Q{df['saldo'].median():,.0f}")
    logger.info(f"  Personas jurídicas: {(df['tipo_persona'] == 'juridica').sum():,}")
    logger.info(f"  Personas individuales: {(df['tipo_persona'] == 'individual').sum():,}")
    logger.info(f"  Tipos de cuenta: {df['tipo_cuenta'].value_counts().to_dict()}")

    return df


def classify_account(row: pd.Series) -> str:
    """Clasifica una cuenta en un arquetipo basado en lo que tenemos.

    Disponible: saldo, tipo_cuenta (ahorro/monetaria/plazo_fijo/fondo_gyt), tipo_persona
    NO disponible: crédito, canal, antigüedad

    Aproximaciones:
    - Crédito: jurídica + saldo > Q5M → probablemente tiene crédito
    - Canal: no se puede derivar sin data transaccional
    - Antigüedad: no disponible
    """
    saldo = row.get("saldo", 0)
    tipo = str(row.get("tipo_cuenta", "")).lower().strip()
    persona = str(row.get("tipo_persona", "individual")).lower().strip()

    T = THRESHOLDS

    # ── Capa 1: Corporativo e Institucional ──

    # Fondo G&T → institucional/fideicomiso
    if tipo == "fondo_gyt":
        return "institucional_gobierno"

    # Corporativo AAA: jurídica + saldo > Q50M
    if persona == "juridica" and saldo >= T["corporativo_aaa_min_saldo"]:
        return "corporativo_aaa"

    # Individual con saldo > Q50M → también corporativo (probable empresa unipersonal)
    if persona == "individual" and saldo >= T["corporativo_aaa_min_saldo"]:
        return "corporativo_aaa"

    # Empresa mediana: jurídica + Q5M-Q50M
    # Sin dato de crédito, asumimos que jurídica > Q5M probablemente tiene crédito
    if persona == "juridica" and saldo >= T["empresa_mediana_min_saldo"]:
        return "empresa_mediana_credito"

    # ── Capa 2: PYME ──

    # Jurídica Q500K-Q5M
    if (persona == "juridica"
            and T["pyme_min_saldo"] <= saldo < T["pyme_max_saldo"]):
        return "pyme_comerciante"

    # Jurídica < Q500K → PYME pequeña, tratar como comerciante
    if persona == "juridica":
        return "pyme_comerciante"

    # ── Capa 3: Personas (individual) ──

    # Plazo fijo con saldo alto → depositante alto valor (tiene ancla por el plazo)
    if tipo == "plazo_fijo" and saldo >= T["alto_valor_min_saldo"]:
        return "depositante_alto_valor"

    # Saldo alto individual → alto valor
    if saldo >= T["alto_valor_min_saldo"]:
        return "depositante_alto_valor"

    # Saldo bajo → retail general
    # Sin data de canal no podemos distinguir digital de presencial
    return "retail_general"


def process_data(df: pd.DataFrame) -> list[dict[str, Any]]:
    """Procesa el DataFrame y genera la lista de arquetipos calibrados."""

    logger.info(f"\n{'='*60}")
    logger.info("  Clasificando cuentas en arquetipos...")
    logger.info(f"{'='*60}")

    # Clasificar cada cuenta
    df["archetype"] = df.apply(classify_account, axis=1)

    # Agregar por arquetipo
    segments = []
    total_saldo = df["saldo"].sum()

    for arch_id, group in df.groupby("archetype"):
        pop = len(group)
        saldo_total = group["saldo"].sum()
        saldo_avg = group["saldo"].mean()
        pct_depositos = saldo_total / total_saldo if total_saldo > 0 else 0

        # Ancla relacional (0-1) — sin dato de crédito, aproximar por arquetipo
        # Corporativos/empresas medianas probablemente tienen crédito → ancla alta
        # PYMEs → ancla media
        # Retail → depende si tiene plazo fijo
        ancla_by_archetype = {
            "corporativo_aaa": 0.85,
            "empresa_mediana_credito": 0.80,
            "institucional_gobierno": 0.70,
            "pyme_comerciante": 0.25,
            "depositante_alto_valor": 0.45,
            "retail_general": 0.15,
        }
        ancla = ancla_by_archetype.get(arch_id, 0.30)

        # Ajustar ancla si hay proporción alta de plazo fijo en el segmento
        if "tipo_cuenta" in group.columns:
            pct_plazo = (group["tipo_cuenta"] == "plazo_fijo").mean()
            ancla = min(1.0, ancla + pct_plazo * 0.3)

        # Obtener comportamiento por defecto
        behavior = DEFAULT_BEHAVIOR.get(arch_id, DEFAULT_BEHAVIOR["retail_general"])

        seg = {
            "id": arch_id,
            "name": arch_id.replace("_", " ").title(),
            "population": pop,
            "avg_balance_q": round(saldo_avg, 2),
            "total_balance_q": round(saldo_total, 2),
            "pct_of_total_deposits": round(pct_depositos, 4),
            "anchor_index": round(ancla, 3),
            # Parámetros de comportamiento
            "sensitivity": behavior["sensitivity"],
            "panic_threshold": behavior["panic_threshold"],
            "preferred_channel": behavior["preferred_channel"],
            "latency_periods": behavior["latency_periods"],
            "panic_multiplier": behavior["panic_multiplier"],
            "withdrawal_pattern": behavior["withdrawal_pattern"],
            "info_channel": behavior["info_channel"],
        }

        if "rumor_amplification" in behavior:
            seg["rumor_amplification"] = behavior["rumor_amplification"]

        segments.append(seg)

        logger.info(
            f"  {arch_id:30s}  pop={pop:>7,}  saldo_avg=Q{saldo_avg:>14,.0f}  "
            f"total=Q{saldo_total:>16,.0f}  ({pct_depositos*100:5.1f}%)  "
            f"ancla={ancla:.2f}"
        )

    # Ordenar por saldo total descendente
    segments.sort(key=lambda s: s["total_balance_q"], reverse=True)

    # Agregar empleados del banco (siempre)
    emp_exists = any(s["id"] == "empleado_agencia" for s in segments)
    if not emp_exists:
        segments.append({
            "id": "empleado_agencia",
            "name": "Empleado Agencia",
            "population": 450,
            "avg_balance_q": 0,
            "total_balance_q": 0,
            "pct_of_total_deposits": 0,
            "pct_with_credit": 0,
            "dominant_channel": "branch",
            "anchor_index": 0.9,
            "avg_tenure_years": 5,
            **DEFAULT_BEHAVIOR["empleado_agencia"],
        })

    logger.info(f"\n  Total arquetipos: {len(segments)}")
    logger.info(f"  Cuentas clasificadas: {len(df):,}")
    logger.info(f"  Saldo total cubierto: Q{sum(s['total_balance_q'] for s in segments):,.0f}")

    return segments


def print_summary(segments: list[dict], bank_params: dict) -> None:
    """Imprime resumen ejecutivo de la calibración."""
    total_dep = bank_params.get("total_depositos_q", sum(s["total_balance_q"] for s in segments))

    logger.info(f"\n{'='*60}")
    logger.info("  RESUMEN DE CALIBRACIÓN")
    logger.info(f"{'='*60}")
    logger.info(f"\n  Depósitos totales: Q{total_dep:,.0f}")
    logger.info(f"  Arquetipos: {len(segments)}")
    logger.info(f"\n  {'Arquetipo':<30s} {'Pop':>8s} {'Saldo Tot':>16s} {'%Dep':>6s} {'Sens':>5s} {'Umbral':>7s}")
    logger.info(f"  {'-'*75}")

    for s in segments:
        logger.info(
            f"  {s['id']:<30s} {s['population']:>8,} "
            f"Q{s['total_balance_q']:>14,.0f} "
            f"{s['pct_of_total_deposits']*100:>5.1f}% "
            f"{s['sensitivity']:>5.2f} "
            f"{s['panic_threshold']:>6.2f}"
        )

    # Concentración
    top3 = sorted(segments, key=lambda s: s["total_balance_q"], reverse=True)[:3]
    top3_pct = sum(s["pct_of_total_deposits"] for s in top3) * 100
    logger.info(f"\n  Top 3 arquetipos concentran: {top3_pct:.1f}% de depósitos")

    # Validación
    covered = sum(s["total_balance_q"] for s in segments)
    coverage = covered / total_dep * 100 if total_dep > 0 else 0
    logger.info(f"  Cobertura vs depósitos totales: {coverage:.1f}%")
    if coverage < 90:
        logger.warning(f"  ⚠ Cobertura < 90% — puede haber cuentas faltantes en el CSV")
    if coverage > 105:
        logger.warning(f"  ⚠ Cobertura > 105% — verificar que no hay duplicados")

    logger.info(f"\n{'='*60}")


def save_output(segments: list[dict], bank_params: dict, output_path: str) -> None:
    """Guarda la calibración como JSON."""
    output = {
        "generated_at": str(pd.Timestamp.now()),
        "bank_params": bank_params,
        "depositor_segments": segments,
    }
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    logger.info(f"\n  ✓ Calibración guardada en: {output_path}")
    logger.info(f"    Para usarla, corre: python run.py --all --offline")
    logger.info(f"    El motor detecta automáticamente el archivo JSON.\n")


# ═══════════════════════════════════════════════════════════════════
# PARÁMETROS DEL BANCO — ACTUALIZÁ CON DATOS REALES
# ═══════════════════════════════════════════════════════════════════

def get_bank_params() -> dict[str, Any]:
    """Parámetros globales del banco.

    INSTRUCCIONES:
    Reemplazá los valores abajo con los datos reales de Tesorería/ALM.
    Estos 4 números los podés conseguir del último reporte de LCR
    o pidiéndolos directamente a Tesorería.
    """
    return {
        "nombre_banco": "G&T Continental",
        "pais": "Guatemala",
        "moneda": "GTQ",
        # ── REEMPLAZAR CON DATOS REALES ──
        "total_depositos_q": 18_000_000_000.0,      # Total depósitos (Q)
        "hqla_inicial_q": 26_100_000_000.0,          # HQLA (Q)
        "lcr_actual": 1.45,                           # LCR reportado
        "tipo_cambio_gtq_usd": 7.80,                 # TC Banguat
        "depositos_usd": 1_200_000_000.0,             # Depósitos en USD
    }


# ═══════════════════════════════════════════════════════════════════
# CLI
# ═══════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(
        description="Procesa CSV del DWH → Arquetipos calibrados para el motor de cascada",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Ejemplo:
  python data/data_processor.py --input depositos_gt.csv
  python data/data_processor.py --input depositos_gt.csv --output mis_arquetipos.json
        """,
    )
    parser.add_argument("--input", "-i", required=True, help="Ruta al CSV del DWH")
    parser.add_argument("--output", "-o", default="data/calibrated_segments.json",
                        help="Ruta de salida del JSON (default: data/calibrated_segments.json)")

    args = parser.parse_args()

    if not Path(args.input).exists():
        logger.error(f"Archivo no encontrado: {args.input}")
        sys.exit(1)

    # Cargar y procesar
    df = load_csv(args.input)
    segments = process_data(df)
    bank_params = get_bank_params()

    # Resumen
    print_summary(segments, bank_params)

    # Guardar
    save_output(segments, bank_params, args.output)


if __name__ == "__main__":
    main()
