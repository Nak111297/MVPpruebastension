#!/usr/bin/env python3
"""
Dashboard — Cascade Engine
Para usar en Jupyter: %run dashboard.py

Corre los 4 escenarios de liquidez y muestra los gráficos inline.
"""

import sys
from pathlib import Path

# Asegurar imports
ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

# ═══════════════════════════════════════════════════════════════════
# PASO 1: Correr simulación
# ═══════════════════════════════════════════════════════════════════

print("=" * 60)
print("  CASCADE ENGINE — Dashboard de Liquidez")
print("  G&T Continental — Gerencia de Riesgos Financieros")
print("=" * 60)

from config.scenarios import ALL_SCENARIOS, get_scenario
from config.settings import get_default_configs
from data.calibration import get_calibration
from engine.cascade_engine import CascadeEngine, SimulationResult
from outputs.results_writer import ResultsWriter

import json
import logging
logging.basicConfig(level=logging.WARNING)

# Solo liquidez
scenario_ids = ["liq_001", "liq_002", "liq_003", "liq_004"]

llm_cfg, sim_cfg, out_cfg = get_default_configs(offline=True, formats=["json"])
bank_params = get_calibration()
engine = CascadeEngine(llm_cfg, sim_cfg, out_cfg, bank_params)

scenarios = {sid: get_scenario(sid) for sid in scenario_ids}
results = engine.run_all_scenarios(scenarios)

# Guardar JSON para visualizador
result_dicts = []
for r in results:
    result_dicts.append({
        "scenario_id": r.scenario_id,
        "success": r.success,
        "summary": r.summary,
        "snapshots": r.snapshots,
        "metadata": r.metadata,
        "execution_time_seconds": r.execution_time_seconds,
        "llm_calls_made": r.llm_calls_made,
        "llm_fallbacks_used": r.llm_fallbacks_used,
    })

# Guardar también los resultados
output_dir = Path("results")
output_dir.mkdir(exist_ok=True)
json_path = output_dir / "latest_results.json"
with open(json_path, "w", encoding="utf-8") as f:
    json.dump({"results": result_dicts}, f, indent=2, ensure_ascii=False, default=str)

# Resumen en consola
print(f"\n{'─' * 60}")
print(f"  RESULTADOS DE LIQUIDEZ")
print(f"{'─' * 60}")
labels = {
    "liq_001": "Sin intervención",
    "liq_002": "Comunicado hora 2",
    "liq_003": "Ejecutivos hora 5",
    "liq_004": "App caída + filas",
}
for r in results:
    s = r.summary
    print(f"\n  {labels.get(r.scenario_id, r.scenario_id)}:")
    print(f"    Retiros:   Q{s.get('total_withdrawals_qm', 0):>10,.1f}M")
    print(f"    LCR final: {s.get('final_lcr', 0):>10.3f}")
    print(f"    Actuó:     {s.get('pct_population_acted', 0) * 100:>9.1f}%")

# Comparativo de efecto de intervenciones
w_base = results[0].summary.get("total_withdrawals_qm", 0)
w_com = results[1].summary.get("total_withdrawals_qm", 0)
w_ej = results[2].summary.get("total_withdrawals_qm", 0)
print(f"\n{'─' * 60}")
print(f"  EFECTO DE INTERVENCIONES")
print(f"{'─' * 60}")
print(f"  Comunicado hora 2:   Q{w_base - w_com:>8,.1f}M menos retiros vs base")
print(f"  Ejecutivos hora 5:   Q{w_base - w_ej:>8,.1f}M {'menos' if w_ej < w_base else 'MÁS'} retiros vs base")
print(f"{'─' * 60}")


# ═══════════════════════════════════════════════════════════════════
# PASO 2: Visualizaciones
# ═══════════════════════════════════════════════════════════════════

print("\n  Generando gráficos...\n")

try:
    import matplotlib
    # Si estamos en Jupyter, usar backend inline
    try:
        get_ipython()
        matplotlib.use("module://matplotlib_inline.backend_inline")
    except NameError:
        pass  # No estamos en Jupyter, usar default

    from outputs.visualizer import (
        plot_executive_summary,
        plot_lcr_comparison,
        plot_withdrawals_comparison,
        plot_scenario_timeline,
        plot_archetype_breakdown,
        plot_cascade_effect,
    )

    # 1. Resumen ejecutivo
    plot_executive_summary(result_dicts)

    # 2. Curvas de LCR
    plot_lcr_comparison(result_dicts)

    # 3. Retiros acumulados
    plot_withdrawals_comparison(result_dicts)

    # 4. Timeline de cada escenario
    for sid in scenario_ids:
        plot_scenario_timeline(result_dicts, sid)

    # 5. Desglose por arquetipo (escenario base)
    plot_archetype_breakdown(result_dicts, "liq_001")

    # 6. Efecto cascada (escenario base)
    plot_cascade_effect(result_dicts, "liq_001")

    print("\n  ✓ Todos los gráficos generados.")

except ImportError:
    print("  ⚠ matplotlib no instalado. Instalar con: pip install matplotlib")
    print("    Los resultados están en: results/latest_results.json")
    print("    Y en el Excel: python run.py --liquidity --offline")

except Exception as e:
    print(f"  ⚠ Error generando gráficos: {e}")
    print("    Los resultados numéricos están arriba y en results/latest_results.json")
