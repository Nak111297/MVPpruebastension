"""
Configuraciones centrales del motor de simulación de cascada.

Contiene dataclasses inmutables para LLM, simulación y exportación.
Todos los parámetros son configurables; ninguno depende de datos hardcodeados.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


class LogLevel(str, Enum):
    """Niveles de logging soportados."""
    DEBUG = "DEBUG"
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"


@dataclass(frozen=True)
class LLMConfig:
    """Configuración del cliente LLM (Ollama local).

    Attributes:
        base_url: URL del servidor Ollama.
        model: Nombre del modelo a usar.
        temperature: Temperatura de muestreo (0.0-1.0).
        max_retries: Intentos máximos antes de fallback.
        retry_base_wait: Espera base (segundos) para backoff exponencial.
        retry_max_wait: Espera máxima (segundos) entre reintentos.
        timeout_seconds: Timeout por request HTTP.
        enabled: Si False, usa fallback determinístico directamente.
    """
    base_url: str = "http://localhost:11434"
    model: str = "llama3.2"
    temperature: float = 0.3
    max_retries: int = 3
    retry_base_wait: float = 1.0
    retry_max_wait: float = 10.0
    timeout_seconds: float = 30.0
    enabled: bool = True


@dataclass(frozen=True)
class SimulationConfig:
    """Parámetros globales de la simulación.

    Attributes:
        random_seed: Semilla para reproducibilidad.
        cascade_amplification_rate: Factor de amplificación cuando se supera
            el umbral de pánico colectivo.
        panic_threshold_pct: Porcentaje de población que debe haber actuado
            para disparar amplificación de cascada.
        max_probability_cap: Tope máximo de probabilidad efectiva post-cascada.
        app_degradation_thresholds: Dict con umbrales de % retiros digitales
            para degradar la app (lenta, caída).
        queue_thresholds: Dict con umbrales de % retiros en agencia para
            estado de filas (largas, críticas).
        log_level: Nivel de logging del sistema.
    """
    random_seed: int = 42
    cascade_amplification_rate: float = 1.35
    panic_threshold_pct: float = 0.10
    max_probability_cap: float = 0.95
    app_degradation_thresholds: dict[str, float] = field(
        default_factory=lambda: {"slow": 0.15, "down": 0.35}
    )
    queue_thresholds: dict[str, float] = field(
        default_factory=lambda: {"long": 0.10, "critical": 0.25}
    )
    log_level: LogLevel = LogLevel.INFO


@dataclass(frozen=True)
class OutputConfig:
    """Configuración de exportación de resultados.

    Attributes:
        output_dir: Directorio de salida.
        formats: Formatos de exportación habilitados.
        include_agent_reasoning: Si incluir el razonamiento LLM en la salida.
        include_period_snapshots: Si incluir snapshots por período.
        excel_sheet_per_scenario: En Excel, crear una hoja por escenario.
        timestamp_filenames: Agregar timestamp a nombres de archivo.
    """
    output_dir: Path = field(default_factory=lambda: Path("./results"))
    formats: list[str] = field(default_factory=lambda: ["json", "csv", "excel"])
    include_agent_reasoning: bool = True
    include_period_snapshots: bool = True
    excel_sheet_per_scenario: bool = True
    timestamp_filenames: bool = True


def get_default_configs(
    offline: bool = False,
    seed: Optional[int] = None,
    output_dir: Optional[str] = None,
    formats: Optional[list[str]] = None,
) -> tuple[LLMConfig, SimulationConfig, OutputConfig]:
    """Retorna configuraciones por defecto, opcionalmente sobreescritas.

    Args:
        offline: Si True, deshabilita el LLM.
        seed: Semilla aleatoria personalizada.
        output_dir: Directorio de salida personalizado.
        formats: Formatos de exportación personalizados.

    Returns:
        Tupla (LLMConfig, SimulationConfig, OutputConfig).
    """
    llm_cfg = LLMConfig(enabled=not offline)

    sim_kwargs: dict = {}
    if seed is not None:
        sim_kwargs["random_seed"] = seed
    sim_cfg = SimulationConfig(**sim_kwargs)

    out_kwargs: dict = {}
    if output_dir is not None:
        out_kwargs["output_dir"] = Path(output_dir)
    if formats is not None:
        out_kwargs["formats"] = formats
    out_cfg = OutputConfig(**out_kwargs)

    logger.info(
        "Configs inicializados — LLM=%s, seed=%d, formatos=%s",
        "ON" if llm_cfg.enabled else "OFF",
        sim_cfg.random_seed,
        out_cfg.formats,
    )
    return llm_cfg, sim_cfg, out_cfg
