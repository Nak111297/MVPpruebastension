"""
Definición de los 10 escenarios de stress testing.

Cada escenario incluye tipo, parámetros de shock, intervenciones con timing,
y metadatos descriptivos para la Gerencia de Riesgos.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional

logger = logging.getLogger(__name__)


class ScenarioType(str, Enum):
    """Tipo de módulo de simulación."""
    LIQUIDITY = "liquidity"
    CREDIT = "credit"
    FX = "fx"


class InterventionType(str, Enum):
    """Tipos de intervención disponibles."""
    # Liquidez
    COMUNICADO_OFICIAL = "comunicado_oficial"
    EJECUTIVOS_LLAMAN = "ejecutivos_llaman"
    # Crédito
    REFINANCIAMIENTO_MASIVO = "refinanciamiento_masivo"
    # FX
    INTERVENCION_BANGUAT = "intervencion_banguat"


@dataclass(frozen=True)
class Intervention:
    """Una intervención aplicada en un período específico.

    Attributes:
        type: Tipo de intervención.
        period: Período en que se activa (hora o mes según módulo).
        params: Parámetros adicionales de la intervención.
    """
    type: InterventionType
    period: int
    params: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class ScenarioDefinition:
    """Definición completa de un escenario de stress testing.

    Attributes:
        id: Identificador único (e.g. liq_001).
        name: Nombre descriptivo.
        description: Descripción para reportes.
        scenario_type: Módulo de simulación.
        periods: Número de períodos a simular.
        period_unit: Unidad temporal (horas, meses).
        shock_params: Parámetros del shock inicial.
        interventions: Lista de intervenciones programadas.
        severity: Severidad cualitativa (mild, moderate, severe).
    """
    id: str
    name: str
    description: str
    scenario_type: ScenarioType
    periods: int
    period_unit: str
    shock_params: dict[str, Any]
    interventions: list[Intervention] = field(default_factory=list)
    severity: str = "moderate"

    def has_intervention_at(self, period: int) -> Optional[Intervention]:
        """Retorna la intervención activa en un período, si existe."""
        for intervention in self.interventions:
            if intervention.period == period:
                return intervention
        return None

    def get_interventions_up_to(self, period: int) -> list[Intervention]:
        """Retorna todas las intervenciones activas hasta un período dado."""
        return [i for i in self.interventions if i.period <= period]


# ═══════════════════════════════════════════════════════════════════════════
# ESCENARIOS DE LIQUIDEZ (liq_001 a liq_004)
# ═══════════════════════════════════════════════════════════════════════════

_LIQ_001 = ScenarioDefinition(
    id="liq_001",
    name="Corrida base sin intervención",
    description=(
        "Rumor en redes sociales sobre problemas de solvencia. "
        "Intensidad inicial 5/10. Sin intervención del banco. "
        "Mide la dinámica natural de una corrida no contenida."
    ),
    scenario_type=ScenarioType.LIQUIDITY,
    periods=8,
    period_unit="horas",
    shock_params={
        "initial_rumor_intensity": 5,
        "rumor_growth_rate": 0.4,
        "app_initial_state": "normal",
    },
    interventions=[],
    severity="moderate",
)

_LIQ_002 = ScenarioDefinition(
    id="liq_002",
    name="Corrida con comunicado hora 2",
    description=(
        "Mismo rumor que liq_001, pero el banco emite comunicado oficial "
        "en hora 2 reduciendo la intensidad percibida en 3 puntos."
    ),
    scenario_type=ScenarioType.LIQUIDITY,
    periods=8,
    period_unit="horas",
    shock_params={
        "initial_rumor_intensity": 5,
        "rumor_growth_rate": 0.4,
        "app_initial_state": "normal",
    },
    interventions=[
        Intervention(
            type=InterventionType.COMUNICADO_OFICIAL,
            period=2,
            params={"intensity_reduction": 3.0},
        ),
    ],
    severity="moderate",
)

_LIQ_003 = ScenarioDefinition(
    id="liq_003",
    name="Corrida con ejecutivos hora 5",
    description=(
        "Rumor intenso (7/10). Ejecutivos de cuenta llaman a clientes "
        "empresariales en hora 5 para contener retiros grandes."
    ),
    scenario_type=ScenarioType.LIQUIDITY,
    periods=8,
    period_unit="horas",
    shock_params={
        "initial_rumor_intensity": 7,
        "rumor_growth_rate": 0.5,
        "app_initial_state": "normal",
    },
    interventions=[
        Intervention(
            type=InterventionType.EJECUTIVOS_LLAMAN,
            period=5,
            params={"intensity_reduction": 1.5, "target_archetype": "empresario"},
        ),
    ],
    severity="severe",
)

_LIQ_004 = ScenarioDefinition(
    id="liq_004",
    name="Corrida severa — app caída + filas",
    description=(
        "Rumor 9/10, app cae desde hora 1, filas desde hora 2. "
        "Escenario extremo sin intervención. Mide resiliencia máxima."
    ),
    scenario_type=ScenarioType.LIQUIDITY,
    periods=8,
    period_unit="horas",
    shock_params={
        "initial_rumor_intensity": 9,
        "rumor_growth_rate": 0.6,
        "app_initial_state": "down",
        "force_queue_critical_from": 2,
    },
    interventions=[],
    severity="severe",
)

# ═══════════════════════════════════════════════════════════════════════════
# ESCENARIOS DE CRÉDITO (cred_001 a cred_003)
# ═══════════════════════════════════════════════════════════════════════════

_CRED_001 = ScenarioDefinition(
    id="cred_001",
    name="Shock macro leve",
    description=(
        "Desempleo sube 2pp, inflación sube 1.5pp en 12 meses. "
        "Escenario de desaceleración moderada sin intervención."
    ),
    scenario_type=ScenarioType.CREDIT,
    periods=12,
    period_unit="meses",
    shock_params={
        "delta_unemployment_pp": 2.0,
        "delta_inflation_pp": 1.5,
    },
    interventions=[],
    severity="mild",
)

_CRED_002 = ScenarioDefinition(
    id="cred_002",
    name="Shock macro severo",
    description=(
        "Desempleo sube 5pp, inflación sube 4pp. "
        "Escenario de crisis económica profunda sin refinanciamiento."
    ),
    scenario_type=ScenarioType.CREDIT,
    periods=12,
    period_unit="meses",
    shock_params={
        "delta_unemployment_pp": 5.0,
        "delta_inflation_pp": 4.0,
    },
    interventions=[],
    severity="severe",
)

_CRED_003 = ScenarioDefinition(
    id="cred_003",
    name="Shock severo + refinanciamiento mes 3",
    description=(
        "Mismo shock que cred_002, pero el banco activa programa de "
        "refinanciamiento masivo en mes 3, reduciendo PD efectiva a 62%."
    ),
    scenario_type=ScenarioType.CREDIT,
    periods=12,
    period_unit="meses",
    shock_params={
        "delta_unemployment_pp": 5.0,
        "delta_inflation_pp": 4.0,
    },
    interventions=[
        Intervention(
            type=InterventionType.REFINANCIAMIENTO_MASIVO,
            period=3,
            params={"pd_multiplier": 0.62},
        ),
    ],
    severity="severe",
)

# ═══════════════════════════════════════════════════════════════════════════
# ESCENARIOS FX (fx_001 a fx_003)
# ═══════════════════════════════════════════════════════════════════════════

_FX_001 = ScenarioDefinition(
    id="fx_001",
    name="Depreciación 8% gradual",
    description=(
        "El quetzal se deprecia 8% frente al USD en 12 meses de forma "
        "gradual y predecible. Escenario base FX."
    ),
    scenario_type=ScenarioType.FX,
    periods=12,
    period_unit="meses",
    shock_params={
        "depreciation_pct": 8.0,
        "speed": "gradual",
    },
    interventions=[],
    severity="mild",
)

_FX_002 = ScenarioDefinition(
    id="fx_002",
    name="Depreciación 18% shock + rumor",
    description=(
        "Shock abrupto de 18% concentrado en primeros 3 meses. "
        "Genera rumor adicional que afecta depósitos en USD."
    ),
    scenario_type=ScenarioType.FX,
    periods=12,
    period_unit="meses",
    shock_params={
        "depreciation_pct": 18.0,
        "speed": "shock",
        "triggers_deposit_rumor": True,
    },
    interventions=[],
    severity="severe",
)

_FX_003 = ScenarioDefinition(
    id="fx_003",
    name="Depreciación 18% + intervención Banguat mes 2",
    description=(
        "Mismo shock que fx_002, pero Banguat interviene en mes 2 "
        "reduciendo la depreciación efectiva a 55% de la proyectada."
    ),
    scenario_type=ScenarioType.FX,
    periods=12,
    period_unit="meses",
    shock_params={
        "depreciation_pct": 18.0,
        "speed": "shock",
        "triggers_deposit_rumor": True,
    },
    interventions=[
        Intervention(
            type=InterventionType.INTERVENCION_BANGUAT,
            period=2,
            params={"depreciation_multiplier": 0.55},
        ),
    ],
    severity="severe",
)

# ═══════════════════════════════════════════════════════════════════════════
# REGISTRO GLOBAL
# ═══════════════════════════════════════════════════════════════════════════

ALL_SCENARIOS: dict[str, ScenarioDefinition] = {
    s.id: s
    for s in [
        _LIQ_001, _LIQ_002, _LIQ_003, _LIQ_004,
        _CRED_001, _CRED_002, _CRED_003,
        _FX_001, _FX_002, _FX_003,
    ]
}


def get_scenario(scenario_id: str) -> ScenarioDefinition:
    """Obtiene un escenario por ID.

    Args:
        scenario_id: Identificador del escenario.

    Returns:
        ScenarioDefinition correspondiente.

    Raises:
        KeyError: Si el escenario no existe.
    """
    if scenario_id not in ALL_SCENARIOS:
        available = ", ".join(sorted(ALL_SCENARIOS.keys()))
        raise KeyError(
            f"Escenario '{scenario_id}' no encontrado. Disponibles: {available}"
        )
    return ALL_SCENARIOS[scenario_id]


def get_scenarios_by_type(scenario_type: ScenarioType) -> list[ScenarioDefinition]:
    """Retorna todos los escenarios de un tipo dado."""
    return [s for s in ALL_SCENARIOS.values() if s.scenario_type == scenario_type]
