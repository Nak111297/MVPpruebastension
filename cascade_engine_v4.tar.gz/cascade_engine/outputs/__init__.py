"""Output module — export results to JSON, CSV, Excel."""

from outputs.results_writer import ResultsWriter

__all__ = ["ResultsWriter"]
