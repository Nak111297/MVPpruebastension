"""
Exportador de resultados de simulación — reporte completo.

Genera archivos en JSON, CSV y Excel con visibilidad total:
  - Cómo reaccionó cada arquetipo en cada período
  - Evolución temporal de métricas clave
  - Efecto cascada y amplificación
  - Presión por canal
  - Detalle de crédito y FX por segmento
"""

from __future__ import annotations

import csv
import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Any

from config.settings import OutputConfig

logger = logging.getLogger(__name__)


class ResultsWriter:
    """Exporta resultados de simulación en múltiples formatos.

    Attributes:
        config: Configuración de salida.
    """

    def __init__(self, config: OutputConfig) -> None:
        self.config = config
        self._ensure_output_dir()

    def _ensure_output_dir(self) -> None:
        """Crea el directorio de salida si no existe."""
        self.config.output_dir.mkdir(parents=True, exist_ok=True)

    def _get_filename(self, base: str, ext: str) -> Path:
        """Genera nombre de archivo con timestamp opcional."""
        if self.config.timestamp_filenames:
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            return self.config.output_dir / f"{base}_{ts}.{ext}"
        return self.config.output_dir / f"{base}.{ext}"

    def write_results(
        self,
        results: list[dict[str, Any]],
        run_metadata: dict[str, Any] | None = None,
    ) -> list[Path]:
        """Escribe resultados en todos los formatos configurados."""
        generated: list[Path] = []
        payload = {
            "run_metadata": run_metadata or {},
            "results": results,
            "generated_at": datetime.now().isoformat(),
        }
        for fmt in self.config.formats:
            try:
                if fmt == "json":
                    generated.append(self._write_json(payload))
                elif fmt == "csv":
                    generated.extend(self._write_csv(results))
                elif fmt == "excel":
                    generated.append(self._write_excel(results, run_metadata))
                else:
                    logger.warning("Formato no soportado: %s", fmt)
            except Exception as e:
                logger.error("Error exportando formato '%s': %s", fmt, str(e))
        logger.info("Archivos generados: %s", [str(p) for p in generated])
        return generated

    # ═══════════════════════════════════════════════════════════════════
    # JSON
    # ═══════════════════════════════════════════════════════════════════

    def _write_json(self, payload: dict[str, Any]) -> Path:
        """Exporta resultados completos a JSON."""
        path = self._get_filename("cascade_results", "json")
        with open(path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, ensure_ascii=False, default=str)
        logger.info("JSON exportado: %s", path)
        return path

    # ═══════════════════════════════════════════════════════════════════
    # CSV (3 archivos)
    # ═══════════════════════════════════════════════════════════════════

    def _write_csv(self, results: list[dict[str, Any]]) -> list[Path]:
        """Genera 3 CSVs: resumen, timeline y arquetipos."""
        paths: list[Path] = []
        paths.extend(self._csv_summary(results))
        paths.extend(self._csv_timeline(results))
        paths.extend(self._csv_archetypes(results))
        return paths

    def _csv_summary(self, results: list[dict[str, Any]]) -> list[Path]:
        path = self._get_filename("cascade_summary", "csv")
        rows = []
        for r in results:
            s = r.get("summary", {})
            rows.append({
                "scenario_id": r.get("scenario_id", ""),
                "scenario_type": s.get("scenario_type", ""),
                "scenario_name": s.get("scenario_name", ""),
                "periods": s.get("periods_simulated", 0),
                "withdrawals_qm": round(s.get("total_withdrawals_qm", 0), 2),
                "final_lcr": round(s.get("final_lcr", 0), 4),
                "lcr_breached": s.get("lcr_breached", False),
                "pct_acted": round(s.get("pct_population_acted", 0) * 100, 2),
                "peak_rumor": s.get("peak_rumor_intensity", 0),
                "credit_loss_qm": round(s.get("cumulative_credit_loss_qm", 0), 2),
                "fx_loss_qm": round(s.get("cumulative_fx_loss_qm", 0), 2),
            })
        if rows:
            with open(path, "w", newline="", encoding="utf-8") as f:
                w = csv.DictWriter(f, fieldnames=rows[0].keys())
                w.writeheader()
                w.writerows(rows)
            logger.info("CSV resumen: %s", path)
            return [path]
        return []

    def _csv_timeline(self, results: list[dict[str, Any]]) -> list[Path]:
        path = self._get_filename("cascade_timeline", "csv")
        rows = []
        for r in results:
            sid = r.get("scenario_id", "")
            for snap in r.get("snapshots", []):
                rows.append({
                    "scenario_id": sid,
                    "period": snap.get("period", 0),
                    "rumor": snap.get("rumor_intensity", 0),
                    "app": snap.get("app_state", ""),
                    "filas": snap.get("queue_state", ""),
                    "retiros_qm": round(snap.get("period_withdrawals_qm", 0), 2),
                    "acum_qm": round(snap.get("cumulative_withdrawals_qm", 0), 2),
                    "lcr": round(snap.get("lcr_projected", 0), 4),
                    "pct_acted": round(snap.get("pct_population_acted", 0) * 100, 2),
                    "intervention": snap.get("intervention_active", ""),
                    "dep_pct": round(snap.get("depreciation_pct", 0), 2),
                    "credit_loss_qm": round(snap.get("cumulative_expected_loss_qm", 0), 2),
                })
        if rows:
            with open(path, "w", newline="", encoding="utf-8") as f:
                w = csv.DictWriter(f, fieldnames=rows[0].keys())
                w.writeheader()
                w.writerows(rows)
            logger.info("CSV timeline: %s", path)
            return [path]
        return []

    def _csv_archetypes(self, results: list[dict[str, Any]]) -> list[Path]:
        path = self._get_filename("cascade_archetypes", "csv")
        rows = []
        for r in results:
            sid = r.get("scenario_id", "")
            for snap in r.get("snapshots", []):
                period = snap.get("period", 0)
                for ad in snap.get("agent_decisions", []):
                    rows.append({
                        "scenario": sid,
                        "period": period,
                        "agent_id": ad.get("agent_id", ""),
                        "agent_name": ad.get("agent_name", ""),
                        "action": ad.get("action", ""),
                        "n_acted": ad.get("n_acted", 0),
                        "amount_qm": round(ad.get("total_amount_qm", 0), 4),
                        "cumul_qm": round(ad.get("cumulative_amount_qm", 0), 4),
                        "prob_orig": ad.get("original_probability", 0),
                        "prob_eff": ad.get("effective_probability", 0),
                        "cascade_x": ad.get("cascade_modifier", 1.0),
                        "pop_total": ad.get("population_total", 0),
                        "pop_remain": ad.get("population_remaining", 0),
                        "pct_seg": round(ad.get("pct_acted_of_segment", 0) * 100, 2),
                        "llm": ad.get("used_llm", False),
                        "reasoning": ad.get("reasoning", ""),
                    })
        if rows:
            with open(path, "w", newline="", encoding="utf-8") as f:
                w = csv.DictWriter(f, fieldnames=rows[0].keys())
                w.writeheader()
                w.writerows(rows)
            logger.info("CSV arquetipos: %s", path)
            return [path]
        return []

    # ═══════════════════════════════════════════════════════════════════
    # EXCEL — REPORTE COMPLETO MULTI-HOJA
    # ═══════════════════════════════════════════════════════════════════

    def _write_excel(
        self,
        results: list[dict[str, Any]],
        run_metadata: dict[str, Any] | None = None,
    ) -> Path:
        """Genera reporte Excel completo con múltiples hojas analíticas.

        Hojas generadas:
          1. Resumen Ejecutivo
          2. Config Agentes
          Por cada escenario de liquidez:
            - {id}_timeline
            - {id}_arquetipos (la clave: comportamiento por arquetipo × período)
            - {id}_cascada
            - {id}_canales
          Por cada escenario de crédito:
            - {id}_credito
          Por cada escenario de FX:
            - {id}_fx
        """
        path = self._get_filename("cascade_report", "xlsx")
        try:
            from openpyxl import Workbook
            from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
            from openpyxl.utils import get_column_letter

            wb = Workbook()
            S = self._build_styles()

            # Hoja 1: Resumen Ejecutivo
            ws = wb.active
            ws.title = "Resumen Ejecutivo"
            self._xl_resumen(ws, results, run_metadata, S)

            # Hoja 2: Config Agentes
            ws_ag = wb.create_sheet(title="Config Agentes")
            self._xl_agent_config(ws_ag, results, S)

            # Hojas por escenario
            for r in results:
                sid = r.get("scenario_id", "")
                stype = r.get("summary", {}).get("scenario_type", "")

                if stype == "liquidity":
                    self._xl_timeline(wb.create_sheet(f"{sid[:25]}_timeline"), r, S)
                    self._xl_archetypes(wb.create_sheet(f"{sid[:22]}_arquetipos"), r, S)
                    self._xl_cascade(wb.create_sheet(f"{sid[:24]}_cascada"), r, S)
                    self._xl_channels(wb.create_sheet(f"{sid[:25]}_canales"), r, S)
                elif stype == "credit":
                    self._xl_timeline(wb.create_sheet(f"{sid[:25]}_timeline"), r, S)
                    self._xl_credit(wb.create_sheet(f"{sid[:24]}_credito"), r, S)
                elif stype == "fx":
                    self._xl_timeline(wb.create_sheet(f"{sid[:25]}_timeline"), r, S)
                    self._xl_fx(wb.create_sheet(f"{sid[:28]}_fx"), r, S)

            wb.save(path)
            logger.info("Excel reporte completo: %s", path)
            return path

        except ImportError:
            logger.warning("openpyxl no disponible")
            csv_paths = self._write_csv(results)
            return csv_paths[0] if csv_paths else path

    # ─── Estilos ─────────────────────────────────────────────────────

    @staticmethod
    def _build_styles() -> dict[str, Any]:
        from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
        thin = Border(
            left=Side(style="thin"), right=Side(style="thin"),
            top=Side(style="thin"), bottom=Side(style="thin"),
        )
        return {
            "title": Font(bold=True, size=14, color="1F4E79"),
            "subtitle": Font(bold=True, size=11, color="2E75B6"),
            "meta": Font(size=9, italic=True, color="666666"),
            "hdr_font": Font(bold=True, size=10, color="FFFFFF"),
            "hdr_fill": PatternFill("solid", fgColor="1F4E79"),
            "sub_fill": PatternFill("solid", fgColor="2E75B6"),
            "alert": PatternFill("solid", fgColor="FF6B6B"),
            "warn": PatternFill("solid", fgColor="FFD93D"),
            "good": PatternFill("solid", fgColor="6BCB77"),
            "blue": PatternFill("solid", fgColor="D6EAF8"),
            "grey": PatternFill("solid", fgColor="F2F3F4"),
            "yellow": PatternFill("solid", fgColor="FEF9E7"),
            "green": PatternFill("solid", fgColor="EAFAF1"),
            "red": PatternFill("solid", fgColor="FDEDEC"),
            "purple": PatternFill("solid", fgColor="F4ECF7"),
            "ctr": Alignment(horizontal="center", vertical="center"),
            "wrap": Alignment(wrap_text=True, vertical="top"),
            "border": thin,
            "font": Font(size=10),
            "bold": Font(bold=True, size=10),
            "pct": "0.0%",
            "num": "#,##0.0",
            "int": "#,##0",
        }

    # ─── Helpers ─────────────────────────────────────────────────────

    def _hdr(self, ws, row: int, headers: list[str], S: dict, c0: int = 1, fill: str = "hdr_fill") -> None:
        for i, h in enumerate(headers, c0):
            cell = ws.cell(row=row, column=i, value=h)
            cell.font = S["hdr_font"]
            cell.fill = S[fill]
            cell.alignment = S["ctr"]
            cell.border = S["border"]

    def _cel(self, ws, r: int, c: int, v, S: dict, fmt=None, fill=None) -> None:
        cell = ws.cell(row=r, column=c, value=v)
        cell.font = S["font"]
        cell.border = S["border"]
        if fmt:
            cell.number_format = fmt
        if fill:
            cell.fill = S[fill]

    def _autofit(self, ws, lo: int = 12, hi: int = 28) -> None:
        from openpyxl.utils import get_column_letter
        for col_cells in ws.columns:
            ml = lo
            cl = get_column_letter(col_cells[0].column)
            for cell in col_cells:
                if cell.value:
                    ml = max(ml, min(len(str(cell.value)) + 2, hi))
            ws.column_dimensions[cl].width = ml

    def _agents_from_snapshots(self, snapshots: list[dict]) -> tuple[list[str], dict[str, str]]:
        """Extrae IDs y nombres de agentes de los snapshots."""
        ids, names = [], {}
        for snap in snapshots:
            for ad in snap.get("agent_decisions", []):
                aid = ad.get("agent_id", "")
                if aid and aid not in ids:
                    ids.append(aid)
                    names[aid] = ad.get("agent_name", aid)
        return ids, names

    # ═══════════════════════════════════════════════════════════════════
    # HOJA: RESUMEN EJECUTIVO
    # ═══════════════════════════════════════════════════════════════════

    def _xl_resumen(self, ws, results: list[dict], meta: dict | None, S: dict) -> None:
        from openpyxl.styles import Alignment, Font

        ws.merge_cells("A1:M1")
        ws["A1"].value = "G&T Continental — Stress Testing: Motor de Cascada"
        ws["A1"].font = S["title"]
        ws["A1"].alignment = Alignment(horizontal="center")

        ws.merge_cells("A2:M2")
        m = meta or {}
        ws["A2"].value = (
            f"Generado: {m.get('timestamp', datetime.now().isoformat())}  |  "
            f"Modo: {'Offline' if m.get('offline') else 'LLM'}  |  "
            f"Seed: {m.get('seed', 42)}  |  "
            f"Escenarios: {len(results)}"
        )
        ws["A2"].font = S["meta"]
        ws["A2"].alignment = Alignment(horizontal="center")

        headers = [
            "ID", "Tipo", "Nombre", "Severidad", "Períodos",
            "Retiros (QM)", "LCR Final", "LCR?",
            "% Población", "Pico Rumor",
            "Pérd Crédito (QM)", "Pérd FX (QM)", "Tiempo (s)",
        ]
        self._hdr(ws, 4, headers, S)

        for ri, r in enumerate(results, 5):
            s = r.get("summary", {})
            mtd = r.get("metadata", {})
            lcr = s.get("final_lcr", 0)
            breach = s.get("lcr_breached", False)

            vals = [
                (r.get("scenario_id"), None, None),
                (s.get("scenario_type"), None, None),
                (s.get("scenario_name"), None, None),
                (mtd.get("severity"), None, None),
                (s.get("periods_simulated"), S["int"], None),
                (round(s.get("total_withdrawals_qm", 0), 1), S["num"], None),
                (round(lcr, 3), "0.000", "alert" if lcr < 1.0 else ("warn" if lcr < 1.2 else "good")),
                ("⚠ BREACH" if breach else "✓ OK", None, "alert" if breach else "good"),
                (s.get("pct_population_acted", 0), S["pct"], None),
                (s.get("peak_rumor_intensity", 0), "0.0", "red" if s.get("peak_rumor_intensity", 0) >= 8 else None),
                (round(s.get("cumulative_credit_loss_qm", 0), 1), S["num"], None),
                (round(s.get("cumulative_fx_loss_qm", 0), 1), S["num"], None),
                (r.get("execution_time_seconds", 0), "0.00", None),
            ]
            for ci, (v, fmt, fill) in enumerate(vals, 1):
                self._cel(ws, ri, ci, v, S, fmt=fmt, fill=fill)

        self._autofit(ws)

    # ═══════════════════════════════════════════════════════════════════
    # HOJA: CONFIG AGENTES
    # ═══════════════════════════════════════════════════════════════════

    def _xl_agent_config(self, ws, results: list[dict], S: dict) -> None:
        from openpyxl.styles import Alignment

        ws.merge_cells("A1:L1")
        ws["A1"].value = "Configuración de Arquetipos de Agentes"
        ws["A1"].font = S["title"]

        headers = [
            "ID", "Nombre", "Población", "Saldo Prom (Q)", "Saldo Total (QM)",
            "Sensibilidad", "Umbral Pánico", "Canal", "Latencia",
            "Mult Pánico", "Retiros Totales (QM)", "% Seg Actuó",
        ]
        self._hdr(ws, 3, headers, S)

        agents_data, tracker = [], {}
        for r in results:
            mtd = r.get("metadata", {})
            if mtd.get("agents"):
                agents_data = mtd["agents"]
                tracker = mtd.get("agent_tracker_final", {})
                break

        for ri, ag in enumerate(agents_data, 4):
            aid = ag.get("id", "")
            tk = tracker.get(aid, {})
            pop = ag.get("population", 0)
            bal = ag.get("avg_balance_q", 0)
            cum_q = tk.get("cumulative_amount_q", 0)
            cum_n = tk.get("cumulative_acted", 0)

            vals = [
                (aid, None, None),
                (ag.get("name"), None, None),
                (pop, S["int"], None),
                (bal, "#,##0", None),
                (round(pop * bal / 1e6, 1), S["num"], None),
                (ag.get("sensitivity", 0), S["pct"], "red" if ag.get("sensitivity", 0) > 0.7 else None),
                (ag.get("panic_threshold", 0), S["pct"], None),
                (ag.get("preferred_channel", ""), None, None),
                (ag.get("latency_periods", 0), S["int"], None),
                (ag.get("panic_multiplier", 1.0), "0.0", "warn" if ag.get("panic_multiplier", 1) > 1 else None),
                (round(cum_q / 1e6, 2), S["num"], None),
                (round(cum_n / pop * 100, 1) if pop > 0 else 0, "0.0", None),
            ]
            for ci, (v, fmt, fill) in enumerate(vals, 1):
                self._cel(ws, ri, ci, v, S, fmt=fmt, fill=fill)

        self._autofit(ws)

    # ═══════════════════════════════════════════════════════════════════
    # HOJA: TIMELINE
    # ═══════════════════════════════════════════════════════════════════

    def _xl_timeline(self, ws, result: dict, S: dict) -> None:
        sid = result.get("scenario_id", "")
        stype = result.get("summary", {}).get("scenario_type", "")
        snaps = result.get("snapshots", [])

        ws.merge_cells("A1:L1")
        ws["A1"].value = f"Timeline: {sid} — {result.get('summary', {}).get('scenario_name', '')}"
        ws["A1"].font = S["title"]
        ws.merge_cells("A2:L2")
        ws["A2"].value = result.get("metadata", {}).get("scenario_description", "")
        ws["A2"].font = S["meta"]

        if stype == "liquidity":
            hdrs = ["Período", "Rumor", "App", "Filas", "Ret Per (QM)", "Ret Acum (QM)",
                     "LCR", "% Actuó", "Intervención"]
            self._hdr(ws, 4, hdrs, S)
            for ri, sn in enumerate(snaps, 5):
                lcr = sn.get("lcr_projected", 99)
                rumor = sn.get("rumor_intensity", 0)
                vals = [
                    (sn["period"], S["int"], None),
                    (rumor, "0.0", "red" if rumor >= 8 else ("warn" if rumor >= 5 else None)),
                    (sn.get("app_state", ""), None, "alert" if sn.get("app_state") == "down" else None),
                    (sn.get("queue_state", ""), None, "alert" if sn.get("queue_state") == "critical" else None),
                    (sn.get("period_withdrawals_qm", 0), S["num"], None),
                    (sn.get("cumulative_withdrawals_qm", 0), S["num"], None),
                    (lcr, "0.000", "alert" if lcr < 1.0 else ("warn" if lcr < 1.2 else "good")),
                    (sn.get("pct_population_acted", 0), S["pct"], None),
                    (sn.get("intervention_active") or "", None, "green" if sn.get("intervention_active") else None),
                ]
                for ci, (v, fmt, fill) in enumerate(vals, 1):
                    self._cel(ws, ri, ci, v, S, fmt=fmt, fill=fill)

        elif stype == "credit":
            seg_keys = sorted(snaps[0].get("pd_by_segment", {}).keys()) if snaps else []
            hdrs = ["Mes", "Pérd Acum (QM)", "Intervención"]
            for sk in seg_keys:
                hdrs.append(f"PD {sk.replace('_',' ').title()[:18]}")
            self._hdr(ws, 4, hdrs, S)
            for ri, sn in enumerate(snaps, 5):
                self._cel(ws, ri, 1, sn["period"], S, S["int"])
                self._cel(ws, ri, 2, sn.get("cumulative_expected_loss_qm", 0), S, S["num"])
                self._cel(ws, ri, 3, sn.get("intervention_active") or "", S,
                          fill="green" if sn.get("intervention_active") else None)
                pds = sn.get("pd_by_segment", {})
                for ci, sk in enumerate(seg_keys, 4):
                    pd = pds.get(sk, 0)
                    self._cel(ws, ri, ci, pd, S, "0.00%",
                              fill="alert" if pd > 0.12 else ("warn" if pd > 0.08 else None))

        elif stype == "fx":
            fx_keys = sorted(snaps[0].get("fx_loss_by_segment", {}).keys()) if snaps else []
            hdrs = ["Mes", "Dep (%)", "Pérd FX Acum (QM)", "Salida USD (QM)", "Intervención"]
            for fk in fx_keys:
                hdrs.append(f"{fk.replace('_',' ').title()[:18]}")
            self._hdr(ws, 4, hdrs, S)
            for ri, sn in enumerate(snaps, 5):
                dep = sn.get("depreciation_pct", 0)
                self._cel(ws, ri, 1, sn["period"], S, S["int"])
                self._cel(ws, ri, 2, dep, S, "0.0",
                          fill="alert" if dep > 15 else ("warn" if dep > 8 else None))
                self._cel(ws, ri, 3, sum(sn.get("fx_loss_by_segment", {}).values()), S, S["num"])
                self._cel(ws, ri, 4, sn.get("usd_deposit_outflow_qm", 0), S, S["num"])
                self._cel(ws, ri, 5, sn.get("intervention_active") or "", S,
                          fill="green" if sn.get("intervention_active") else None)
                fx = sn.get("fx_loss_by_segment", {})
                for ci, fk in enumerate(fx_keys, 6):
                    self._cel(ws, ri, ci, fx.get(fk, 0), S, S["num"])

        self._autofit(ws)
        ws.freeze_panes = "B5"

    # ═══════════════════════════════════════════════════════════════════
    # HOJA: ARQUETIPOS × PERÍODO (la clave del reporte)
    # ═══════════════════════════════════════════════════════════════════

    def _xl_archetypes(self, ws, result: dict, S: dict) -> None:
        """Matriz detallada: filas=períodos, bloques de columnas=arquetipos.

        Cada arquetipo tiene 9 columnas:
          Acción | Prob Orig | Prob Efect | Cascada× | N Actuaron |
          Retiro QM | Acum QM | % Segmento | Restantes
        """
        from openpyxl.utils import get_column_letter

        sid = result.get("scenario_id", "")
        snaps = result.get("snapshots", [])
        if not snaps:
            return

        ws.merge_cells("A1:AE1")
        ws["A1"].value = f"Comportamiento por Arquetipo × Período: {sid}"
        ws["A1"].font = S["title"]
        ws.merge_cells("A2:AE2")
        ws["A2"].value = (
            "Cada bloque de columnas muestra cómo reaccionó un arquetipo en cada período. "
            "Prob = probabilidad de actuar. Cascada× = amplificación por efecto manada."
        )
        ws["A2"].font = S["meta"]

        agent_ids, agent_names = self._agents_from_snapshots(snaps)
        if not agent_ids:
            ws["A4"] = "No hay datos de agentes."
            return

        metrics = [
            ("Acción", "action", None),
            ("P.Orig", "original_probability", S["pct"]),
            ("P.Efect", "effective_probability", S["pct"]),
            ("Cascada×", "cascade_modifier", "0.00"),
            ("N Actuaron", "n_acted", S["int"]),
            ("Ret QM", "total_amount_qm", "#,##0.00"),
            ("Acum QM", "cumulative_amount_qm", "#,##0.00"),
            ("% Seg", "pct_acted_of_segment", S["pct"]),
            ("Restantes", "population_remaining", S["int"]),
        ]
        nm = len(metrics)

        r_names = 3  # fila de nombres de agente
        r_hdrs = 4   # fila de métricas
        r_data = 5   # inicio de datos

        # Col A headers
        ws.cell(row=r_names, column=1, value="").border = S["border"]
        c = ws.cell(row=r_hdrs, column=1, value="Período")
        c.font = S["hdr_font"]; c.fill = S["hdr_fill"]; c.border = S["border"]

        fills = ["blue", "yellow", "green", "red", "grey", "purple"]

        for ai, aid in enumerate(agent_ids):
            cs = 2 + ai * nm
            ce = cs + nm - 1
            fl = fills[ai % len(fills)]

            # Buscar población
            pop = 0
            for sn in snaps:
                for ad in sn.get("agent_decisions", []):
                    if ad.get("agent_id") == aid:
                        pop = ad.get("population_total", 0)
                        break
                if pop:
                    break

            # Merge nombre
            ws.merge_cells(
                start_row=r_names, start_column=cs,
                end_row=r_names, end_column=ce,
            )
            nc = ws.cell(row=r_names, column=cs)
            nc.value = f"{agent_names.get(aid, aid)}  (n={pop:,})"
            nc.font = S["subtitle"]; nc.alignment = S["ctr"]; nc.fill = S[fl]

            # Sub-headers
            for mi, (mname, _, _) in enumerate(metrics):
                hc = ws.cell(row=r_hdrs, column=cs + mi, value=mname)
                hc.font = S["hdr_font"]; hc.fill = S["sub_fill"]
                hc.alignment = S["ctr"]; hc.border = S["border"]

        # Datos
        for pi, sn in enumerate(snaps):
            row = r_data + pi
            pc = ws.cell(row=row, column=1, value=sn.get("period", 0))
            pc.font = S["bold"]; pc.border = S["border"]; pc.alignment = S["ctr"]

            decs = {ad["agent_id"]: ad for ad in sn.get("agent_decisions", [])}

            for ai, aid in enumerate(agent_ids):
                cs = 2 + ai * nm
                ad = decs.get(aid, {})
                fl = fills[ai % len(fills)]

                for mi, (_, key, fmt) in enumerate(metrics):
                    v = ad.get(key, "")
                    col = cs + mi

                    # Condicional para cascada
                    cell_fill = fl
                    if key == "cascade_modifier" and isinstance(v, (int, float)) and v > 1.1:
                        cell_fill = "red"
                    elif key == "effective_probability" and isinstance(v, (int, float)) and v > 0.7:
                        cell_fill = "red"
                    elif key == "action" and v in ("full_withdraw", "transfer_out"):
                        cell_fill = "red"
                    elif key == "action" and v == "latencia":
                        cell_fill = "grey"

                    self._cel(ws, row, col, v, S, fmt=fmt, fill=cell_fill)

        # Ancho y freeze
        ws.column_dimensions["A"].width = 10
        total = 1 + len(agent_ids) * nm
        for c in range(2, total + 1):
            ws.column_dimensions[get_column_letter(c)].width = 12
        ws.freeze_panes = "B5"

    # ═══════════════════════════════════════════════════════════════════
    # HOJA: CASCADA Y AMPLIFICACIÓN
    # ═══════════════════════════════════════════════════════════════════

    def _xl_cascade(self, ws, result: dict, S: dict) -> None:
        """Efecto cascada detallado: prob original vs efectiva por agente."""
        sid = result.get("scenario_id", "")
        snaps = result.get("snapshots", [])

        ws.merge_cells("A1:P1")
        ws["A1"].value = f"Efecto Cascada: {sid}"
        ws["A1"].font = S["title"]
        ws.merge_cells("A2:P2")
        ws["A2"].value = (
            "Compara probabilidad original (del agente) vs efectiva (post-cascada). "
            "Cascada× > 1.0 indica amplificación por pánico colectivo."
        )
        ws["A2"].font = S["meta"]

        agent_ids, agent_names = self._agents_from_snapshots(snaps)

        hdrs = ["Per", "Rumor", "% Actuó", "App", "Filas", "Interv"]
        for aid in agent_ids:
            short = agent_names.get(aid, aid)[:15]
            hdrs.extend([f"{short} Orig", f"{short} Efect", f"{short} ×"])

        self._hdr(ws, 4, hdrs, S)

        for ri, sn in enumerate(snaps, 5):
            c = 1
            self._cel(ws, ri, c, sn.get("period"), S, S["int"]); c += 1
            rumor = sn.get("rumor_intensity", 0)
            self._cel(ws, ri, c, rumor, S, "0.0",
                      fill="red" if rumor >= 8 else ("warn" if rumor >= 5 else None)); c += 1
            self._cel(ws, ri, c, sn.get("pct_population_acted", 0), S, S["pct"]); c += 1
            self._cel(ws, ri, c, sn.get("app_state", ""), S); c += 1
            self._cel(ws, ri, c, sn.get("queue_state", ""), S); c += 1
            self._cel(ws, ri, c, sn.get("intervention_active") or "", S); c += 1

            decs = {ad["agent_id"]: ad for ad in sn.get("agent_decisions", [])}
            for aid in agent_ids:
                ad = decs.get(aid, {})
                po = ad.get("original_probability", 0)
                pe = ad.get("effective_probability", 0)
                cx = ad.get("cascade_modifier", 1.0)
                cf = "red" if isinstance(cx, (int, float)) and cx > 1.1 else None
                self._cel(ws, ri, c, po, S, S["pct"]); c += 1
                self._cel(ws, ri, c, pe, S, S["pct"], fill=cf); c += 1
                self._cel(ws, ri, c, cx, S, "0.00", fill=cf); c += 1

        self._autofit(ws, lo=10, hi=18)
        ws.freeze_panes = "G5"

    # ═══════════════════════════════════════════════════════════════════
    # HOJA: PRESIÓN POR CANAL
    # ═══════════════════════════════════════════════════════════════════

    def _xl_channels(self, ws, result: dict, S: dict) -> None:
        """Distribución de retiros por canal × período."""
        sid = result.get("scenario_id", "")
        snaps = result.get("snapshots", [])

        ws.merge_cells("A1:L1")
        ws["A1"].value = f"Presión por Canal: {sid}"
        ws["A1"].font = S["title"]

        ch_set: set[str] = set()
        for sn in snaps:
            for ad in sn.get("agent_decisions", []):
                ch_set.update(ad.get("channel_distribution", {}).keys())
        channels = sorted(ch_set)

        ch_labels = {"branch": "Agencia", "app": "App", "call_center": "Call Center",
                     "executive": "Ejecutivo", "atm": "ATM"}

        hdrs = ["Período", "Total Per QM"]
        for ch in channels:
            lbl = ch_labels.get(ch, ch)
            hdrs.extend([f"{lbl} (#)", f"{lbl} (QM)"])
        hdrs.append("% Digital")

        self._hdr(ws, 3, hdrs, S)

        for ri, sn in enumerate(snaps, 4):
            c = 1
            self._cel(ws, ri, c, sn.get("period"), S, S["int"]); c += 1
            self._cel(ws, ri, c, sn.get("period_withdrawals_qm", 0), S, S["num"]); c += 1

            ch_agg: dict[str, dict[str, float]] = {ch: {"n": 0, "qm": 0.0} for ch in channels}
            for ad in sn.get("agent_decisions", []):
                n = ad.get("n_acted", 0)
                qm = ad.get("total_amount_qm", 0)
                dist = ad.get("channel_distribution", {})
                if n > 0 and dist:
                    for ch, cnt in dist.items():
                        if ch in ch_agg:
                            ch_agg[ch]["n"] += cnt
                            ch_agg[ch]["qm"] += qm * cnt / n

            for ch in channels:
                self._cel(ws, ri, c, ch_agg[ch]["n"], S, S["int"]); c += 1
                self._cel(ws, ri, c, round(ch_agg[ch]["qm"], 2), S, S["num"]); c += 1

            total_n = sum(v["n"] for v in ch_agg.values())
            dig_n = sum(v["n"] for k, v in ch_agg.items() if k in ("app", "call_center"))
            pct_dig = dig_n / total_n if total_n else 0
            self._cel(ws, ri, c, pct_dig, S, S["pct"])

        self._autofit(ws)

    # ═══════════════════════════════════════════════════════════════════
    # HOJA: CRÉDITO DETALLE
    # ═══════════════════════════════════════════════════════════════════

    def _xl_credit(self, ws, result: dict, S: dict) -> None:
        sid = result.get("scenario_id", "")
        snaps = result.get("snapshots", [])

        ws.merge_cells("A1:L1")
        ws["A1"].value = f"Deterioro Portafolio Crédito: {sid}"
        ws["A1"].font = S["title"]
        ws.merge_cells("A2:L2")
        ws["A2"].value = result.get("metadata", {}).get("scenario_description", "")
        ws["A2"].font = S["meta"]

        seg_keys = sorted(snaps[0].get("pd_by_segment", {}).keys()) if snaps else []
        hdrs = ["Mes", "Pérd Acum (QM)", "Pérd Per (QM)", "Interv"]
        for sk in seg_keys:
            hdrs.append(f"PD {sk.replace('_',' ').title()[:18]}")

        self._hdr(ws, 4, hdrs, S)

        prev_loss = 0.0
        for ri, sn in enumerate(snaps, 5):
            cum = sn.get("cumulative_expected_loss_qm", 0)
            per = cum - prev_loss
            prev_loss = cum
            self._cel(ws, ri, 1, sn["period"], S, S["int"])
            self._cel(ws, ri, 2, cum, S, S["num"])
            self._cel(ws, ri, 3, round(per, 2), S, S["num"])
            self._cel(ws, ri, 4, sn.get("intervention_active") or "", S,
                      fill="green" if sn.get("intervention_active") else None)
            pds = sn.get("pd_by_segment", {})
            for ci, sk in enumerate(seg_keys, 5):
                pd = pds.get(sk, 0)
                self._cel(ws, ri, ci, pd, S, "0.00%",
                          fill="alert" if pd > 0.12 else ("warn" if pd > 0.08 else None))

        self._autofit(ws)
        ws.freeze_panes = "B5"

    # ═══════════════════════════════════════════════════════════════════
    # HOJA: FX DETALLE
    # ═══════════════════════════════════════════════════════════════════

    def _xl_fx(self, ws, result: dict, S: dict) -> None:
        sid = result.get("scenario_id", "")
        snaps = result.get("snapshots", [])

        ws.merge_cells("A1:L1")
        ws["A1"].value = f"Impacto Tipo de Cambio: {sid}"
        ws["A1"].font = S["title"]

        fx_keys = sorted(snaps[0].get("fx_loss_by_segment", {}).keys()) if snaps else []
        hdrs = ["Mes", "Dep (%)", "Pérd FX Acum", "Salida USD", "Interv"]
        for fk in fx_keys:
            hdrs.append(fk.replace("_", " ").title()[:18])

        self._hdr(ws, 3, hdrs, S)

        for ri, sn in enumerate(snaps, 4):
            dep = sn.get("depreciation_pct", 0)
            self._cel(ws, ri, 1, sn["period"], S, S["int"])
            self._cel(ws, ri, 2, dep, S, "0.0",
                      fill="alert" if dep > 15 else ("warn" if dep > 8 else None))
            self._cel(ws, ri, 3, sum(sn.get("fx_loss_by_segment", {}).values()), S, S["num"])
            self._cel(ws, ri, 4, sn.get("usd_deposit_outflow_qm", 0), S, S["num"])
            self._cel(ws, ri, 5, sn.get("intervention_active") or "", S,
                      fill="green" if sn.get("intervention_active") else None)
            fx = sn.get("fx_loss_by_segment", {})
            for ci, fk in enumerate(fx_keys, 6):
                self._cel(ws, ri, ci, fx.get(fk, 0), S, S["num"])

        self._autofit(ws)

    # ─── UTILIDAD ────────────────────────────────────────────────────

    def write_single_result(self, result: dict[str, Any], scenario_id: str) -> list[Path]:
        """Escribe un resultado individual."""
        return self.write_results([result], run_metadata={"scenario": scenario_id})
