"""
Visualizador de resultados de simulación.

Genera gráficos inline para Jupyter o los guarda como PNG.
Funciona con matplotlib que viene incluido en la mayoría de
distribuciones de Python (conda, pip).

Uso desde Jupyter:
    from outputs.visualizer import plot_all
    plot_all("results/cascade_results_XXXXX.json")

Uso standalone:
    python outputs/visualizer.py results/cascade_results_XXXXX.json
"""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

import matplotlib
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import numpy as np


# ── Estilo ────────────────────────────────────────────────────────
COLORS = {
    "corporativo_aaa": "#E74C3C",
    "empresa_mediana_credito": "#E67E22",
    "institucional_gobierno": "#F39C12",
    "mayorista_interbancario": "#C0392B",
    "pyme_comerciante": "#3498DB",
    "pyme_credito": "#2980B9",
    "asalariado_nomina": "#27AE60",
    "depositante_alto_valor": "#8E44AD",
    "digital_joven": "#1ABC9C",
    "empleado_agencia": "#95A5A6",
    "otros_retail": "#BDC3C7",
    # Legacy archetypes
    "conservador_mayor": "#E74C3C",
    "empresario_credito": "#E67E22",
    "millennial_digital": "#1ABC9C",
    "cliente_rural": "#27AE60",
}

SCENARIO_COLORS = {
    "liq_001": "#E74C3C",
    "liq_002": "#27AE60",
    "liq_003": "#3498DB",
    "liq_004": "#8E44AD",
}

SCENARIO_LABELS = {
    "liq_001": "Sin intervención",
    "liq_002": "Comunicado hora 2",
    "liq_003": "Ejecutivos hora 5",
    "liq_004": "App caída + filas",
}


def _setup_style():
    """Configura estilo de gráficos."""
    plt.rcParams.update({
        "figure.figsize": (12, 5),
        "figure.dpi": 100,
        "font.family": "sans-serif",
        "font.size": 10,
        "axes.titlesize": 13,
        "axes.titleweight": "bold",
        "axes.labelsize": 11,
        "axes.grid": True,
        "grid.alpha": 0.3,
        "legend.fontsize": 9,
        "legend.framealpha": 0.9,
    })


def load_results(path: str) -> list[dict[str, Any]]:
    """Carga resultados desde JSON."""
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    return data.get("results", data if isinstance(data, list) else [])


def _get_color(agent_id: str) -> str:
    return COLORS.get(agent_id, "#95A5A6")


# ═══════════════════════════════════════════════════════════════════
# GRÁFICO 1: CURVA DE LCR POR ESCENARIO (el chart principal)
# ═══════════════════════════════════════════════════════════════════

def plot_lcr_comparison(results: list[dict], save_path: str | None = None) -> None:
    """Curva de LCR hora a hora comparando todos los escenarios."""
    _setup_style()
    fig, ax = plt.subplots(figsize=(12, 5.5))

    liq_results = [r for r in results if r.get("summary", {}).get("scenario_type") == "liquidity"]
    if not liq_results:
        print("No hay resultados de liquidez para graficar.")
        return

    for r in liq_results:
        sid = r.get("scenario_id", "")
        snaps = r.get("snapshots", [])
        periods = [s["period"] for s in snaps]
        lcrs = [s["lcr_projected"] for s in snaps]

        color = SCENARIO_COLORS.get(sid, "#333333")
        label = SCENARIO_LABELS.get(sid, sid)

        # Cap LCR display at 30 for readability
        lcrs_display = [min(l, 30) for l in lcrs]
        ax.plot(periods, lcrs_display, "-o", color=color, linewidth=2.5,
                markersize=6, label=label, zorder=3)

    # Línea de LCR = 1.0 (umbral regulatorio)
    ax.axhline(y=1.0, color="#E74C3C", linestyle="--", linewidth=2, alpha=0.8,
               label="LCR = 1.0 (mínimo regulatorio)", zorder=2)

    ax.set_xlabel("Hora")
    ax.set_ylabel("LCR Proyectado")
    ax.set_title("Proyección de LCR Hora a Hora — Comparativo de Escenarios")
    ax.legend(loc="upper right")
    ax.set_xlim(0.5, max(periods) + 0.5)
    ax.set_ylim(bottom=0)

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.show()


# ═══════════════════════════════════════════════════════════════════
# GRÁFICO 2: RETIROS ACUMULADOS POR ESCENARIO
# ═══════════════════════════════════════════════════════════════════

def plot_withdrawals_comparison(results: list[dict], save_path: str | None = None) -> None:
    """Retiros acumulados comparando escenarios."""
    _setup_style()
    fig, ax = plt.subplots(figsize=(12, 5.5))

    liq_results = [r for r in results if r.get("summary", {}).get("scenario_type") == "liquidity"]

    for r in liq_results:
        sid = r.get("scenario_id", "")
        snaps = r.get("snapshots", [])
        periods = [s["period"] for s in snaps]
        withdrawals = [s["cumulative_withdrawals_qm"] for s in snaps]

        color = SCENARIO_COLORS.get(sid, "#333333")
        label = SCENARIO_LABELS.get(sid, sid)

        ax.plot(periods, withdrawals, "-o", color=color, linewidth=2.5,
                markersize=6, label=label)

        # Annotate final value
        if withdrawals:
            ax.annotate(f"Q{withdrawals[-1]:,.0f}M",
                        xy=(periods[-1], withdrawals[-1]),
                        xytext=(10, 5), textcoords="offset points",
                        fontsize=9, fontweight="bold", color=color)

    ax.set_xlabel("Hora")
    ax.set_ylabel("Retiros Acumulados (QM)")
    ax.set_title("Retiros Acumulados — Impacto de Intervenciones")
    ax.legend(loc="upper left")
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"Q{x:,.0f}M"))

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.show()


# ═══════════════════════════════════════════════════════════════════
# GRÁFICO 3: RETIROS POR ARQUETIPO (stacked bar) — un escenario
# ═══════════════════════════════════════════════════════════════════

def plot_archetype_breakdown(results: list[dict], scenario_id: str = "liq_001",
                              save_path: str | None = None) -> None:
    """Retiros por período desglosados por arquetipo (stacked bar)."""
    _setup_style()

    r = next((x for x in results if x.get("scenario_id") == scenario_id), None)
    if not r:
        print(f"Escenario '{scenario_id}' no encontrado.")
        return

    snaps = r.get("snapshots", [])
    if not snaps:
        return

    # Recopilar agentes
    agent_ids = []
    for snap in snaps:
        for ad in snap.get("agent_decisions", []):
            aid = ad.get("agent_id", "")
            if aid and aid not in agent_ids and ad.get("total_amount_qm", 0) > 0:
                agent_ids.append(aid)

    periods = [s["period"] for s in snaps]
    data = {aid: [] for aid in agent_ids}

    for snap in snaps:
        decs = {ad["agent_id"]: ad for ad in snap.get("agent_decisions", [])}
        for aid in agent_ids:
            ad = decs.get(aid, {})
            data[aid].append(ad.get("total_amount_qm", 0))

    fig, ax = plt.subplots(figsize=(12, 6))
    bottom = np.zeros(len(periods))

    for aid in agent_ids:
        values = np.array(data[aid])
        color = _get_color(aid)
        label = aid.replace("_", " ").title()
        ax.bar(periods, values, bottom=bottom, color=color, label=label,
               width=0.7, edgecolor="white", linewidth=0.5)
        bottom += values

    ax.set_xlabel("Hora")
    ax.set_ylabel("Retiros del Período (QM)")
    ax.set_title(f"Retiros por Arquetipo × Hora — {SCENARIO_LABELS.get(scenario_id, scenario_id)}")
    ax.legend(loc="upper left", ncol=2)
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"Q{x:,.0f}M"))

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.show()


# ═══════════════════════════════════════════════════════════════════
# GRÁFICO 4: CASCADA — PROBABILIDAD ORIGINAL VS EFECTIVA
# ═══════════════════════════════════════════════════════════════════

def plot_cascade_effect(results: list[dict], scenario_id: str = "liq_001",
                         save_path: str | None = None) -> None:
    """Muestra cómo la cascada amplifica la probabilidad de cada arquetipo."""
    _setup_style()

    r = next((x for x in results if x.get("scenario_id") == scenario_id), None)
    if not r:
        return

    snaps = r.get("snapshots", [])
    agent_ids = []
    for snap in snaps:
        for ad in snap.get("agent_decisions", []):
            aid = ad.get("agent_id", "")
            if aid and aid not in agent_ids and aid != "empleado_agencia":
                agent_ids.append(aid)

    if not agent_ids:
        return

    n_agents = min(len(agent_ids), 6)
    fig, axes = plt.subplots(1, n_agents, figsize=(4 * n_agents, 4), sharey=True)
    if n_agents == 1:
        axes = [axes]

    for idx, aid in enumerate(agent_ids[:n_agents]):
        ax = axes[idx]
        periods = []
        orig, eff = [], []

        for snap in snaps:
            decs = {ad["agent_id"]: ad for ad in snap.get("agent_decisions", [])}
            ad = decs.get(aid, {})
            if ad:
                periods.append(snap["period"])
                orig.append(ad.get("original_probability", 0))
                eff.append(ad.get("effective_probability", 0))

        color = _get_color(aid)
        ax.fill_between(periods, orig, eff, alpha=0.3, color=color, label="Amplificación")
        ax.plot(periods, orig, "--", color=color, alpha=0.6, linewidth=1.5, label="Original")
        ax.plot(periods, eff, "-", color=color, linewidth=2.5, label="Efectiva")

        ax.set_title(aid.replace("_", " ").title()[:20], fontsize=10)
        ax.set_xlabel("Hora")
        if idx == 0:
            ax.set_ylabel("Probabilidad")
        ax.set_ylim(0, 1.05)
        ax.yaxis.set_major_formatter(mticker.PercentFormatter(1.0))

    axes[0].legend(loc="upper left", fontsize=8)
    fig.suptitle(f"Efecto Cascada — {SCENARIO_LABELS.get(scenario_id, scenario_id)}",
                 fontsize=13, fontweight="bold", y=1.02)

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.show()


# ═══════════════════════════════════════════════════════════════════
# GRÁFICO 5: RUMOR + % ACTUÓ + INTERVENCIONES
# ═══════════════════════════════════════════════════════════════════

def plot_scenario_timeline(results: list[dict], scenario_id: str = "liq_001",
                            save_path: str | None = None) -> None:
    """Timeline de un escenario: rumor, % actuó, intervenciones."""
    _setup_style()

    r = next((x for x in results if x.get("scenario_id") == scenario_id), None)
    if not r:
        return

    snaps = r.get("snapshots", [])
    periods = [s["period"] for s in snaps]
    rumor = [s["rumor_intensity"] for s in snaps]
    pct_acted = [s["pct_population_acted"] * 100 for s in snaps]

    fig, ax1 = plt.subplots(figsize=(12, 5))

    color_rumor = "#E74C3C"
    color_pct = "#2E86C1"

    ax1.fill_between(periods, rumor, alpha=0.15, color=color_rumor)
    ax1.plot(periods, rumor, "-s", color=color_rumor, linewidth=2.5, markersize=7,
             label="Intensidad del Rumor (/10)")
    ax1.set_xlabel("Hora")
    ax1.set_ylabel("Intensidad del Rumor", color=color_rumor)
    ax1.tick_params(axis="y", labelcolor=color_rumor)
    ax1.set_ylim(0, 11)

    ax2 = ax1.twinx()
    ax2.plot(periods, pct_acted, "-o", color=color_pct, linewidth=2.5, markersize=7,
             label="% Población Actuó")
    ax2.set_ylabel("% Población que Retiró", color=color_pct)
    ax2.tick_params(axis="y", labelcolor=color_pct)
    ax2.set_ylim(0, 110)
    ax2.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"{x:.0f}%"))

    # Intervenciones como líneas verticales
    for snap in snaps:
        intv = snap.get("intervention_active")
        if intv:
            label_map = {
                "comunicado_oficial": "Comunicado",
                "ejecutivos_llaman": "Ejecutivos llaman",
            }
            ax1.axvline(x=snap["period"], color="#27AE60", linestyle="-.", linewidth=2, alpha=0.8)
            ax1.annotate(label_map.get(intv, intv),
                         xy=(snap["period"], 10.5), fontsize=9,
                         color="#27AE60", fontweight="bold", ha="center")

    lines1, labels1 = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    ax1.legend(lines1 + lines2, labels1 + labels2, loc="center right")

    ax1.set_title(f"Timeline: {SCENARIO_LABELS.get(scenario_id, scenario_id)}")

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.show()


# ═══════════════════════════════════════════════════════════════════
# GRÁFICO 6: RESUMEN EJECUTIVO (bar chart comparativo)
# ═══════════════════════════════════════════════════════════════════

def plot_executive_summary(results: list[dict], save_path: str | None = None) -> None:
    """Bar chart comparando retiros totales y LCR final por escenario."""
    _setup_style()

    liq = [r for r in results if r.get("summary", {}).get("scenario_type") == "liquidity"]
    if not liq:
        return

    sids = [r["scenario_id"] for r in liq]
    labels = [SCENARIO_LABELS.get(s, s) for s in sids]
    withdrawals = [r["summary"]["total_withdrawals_qm"] for r in liq]
    lcrs = [r["summary"]["final_lcr"] for r in liq]
    colors = [SCENARIO_COLORS.get(s, "#333") for s in sids]

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))

    # Retiros
    bars1 = ax1.barh(labels, withdrawals, color=colors, edgecolor="white", height=0.6)
    ax1.set_xlabel("Retiros Totales (QM)")
    ax1.set_title("Retiros Acumulados por Escenario")
    for bar, val in zip(bars1, withdrawals):
        ax1.text(bar.get_width() + max(withdrawals) * 0.01, bar.get_y() + bar.get_height() / 2,
                 f"Q{val:,.0f}M", va="center", fontweight="bold", fontsize=10)
    ax1.xaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"Q{x:,.0f}M"))

    # LCR
    bars2 = ax2.barh(labels, lcrs, color=colors, edgecolor="white", height=0.6)
    ax2.axvline(x=1.0, color="#E74C3C", linestyle="--", linewidth=2, alpha=0.8, label="LCR = 1.0")
    ax2.set_xlabel("LCR Final")
    ax2.set_title("LCR Proyectado Final")
    for bar, val in zip(bars2, lcrs):
        ax2.text(bar.get_width() + max(lcrs) * 0.01, bar.get_y() + bar.get_height() / 2,
                 f"{val:.2f}", va="center", fontweight="bold", fontsize=10)
    ax2.legend()

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.show()


# ═══════════════════════════════════════════════════════════════════
# PLOT ALL
# ═══════════════════════════════════════════════════════════════════

def plot_all(json_path: str, save_dir: str | None = None) -> None:
    """Genera todos los gráficos a partir del JSON de resultados.

    Args:
        json_path: Ruta al archivo cascade_results_*.json
        save_dir: Si se provee, guarda PNGs en ese directorio.
    """
    results = load_results(json_path)
    if not results:
        print(f"No se encontraron resultados en {json_path}")
        return

    liq = [r for r in results if r.get("summary", {}).get("scenario_type") == "liquidity"]
    print(f"\n  Cargados {len(results)} escenarios ({len(liq)} de liquidez)")
    print(f"  Generando visualizaciones...\n")

    sd = None
    if save_dir:
        sd = Path(save_dir)
        sd.mkdir(parents=True, exist_ok=True)

    # 1. Resumen ejecutivo
    plot_executive_summary(results, save_path=str(sd / "01_resumen.png") if sd else None)

    # 2. LCR comparativo
    plot_lcr_comparison(results, save_path=str(sd / "02_lcr.png") if sd else None)

    # 3. Retiros comparativo
    plot_withdrawals_comparison(results, save_path=str(sd / "03_retiros.png") if sd else None)

    # 4-6. Por escenario
    for r in liq:
        sid = r["scenario_id"]
        plot_scenario_timeline(results, sid, save_path=str(sd / f"04_timeline_{sid}.png") if sd else None)
        plot_archetype_breakdown(results, sid, save_path=str(sd / f"05_arquetipos_{sid}.png") if sd else None)
        plot_cascade_effect(results, sid, save_path=str(sd / f"06_cascada_{sid}.png") if sd else None)


# ═══════════════════════════════════════════════════════════════════
# CLI
# ═══════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    if len(sys.argv) < 2:
        # Auto-find latest results
        results_dir = Path("results")
        if results_dir.exists():
            # Try latest_results.json first, then timestamped
            latest = results_dir / "latest_results.json"
            if latest.exists():
                print(f"  Usando: {latest}")
                plot_all(str(latest))
            else:
                jsons = sorted(results_dir.glob("cascade_results_*.json"))
                if jsons:
                    path = str(jsons[-1])
                    print(f"  Usando: {path}")
                    plot_all(path)
                else:
                    print("No hay archivos JSON en results/. Corre primero: python run.py --liquidity --offline")
        else:
            print("Directorio results/ no existe. Corre primero: python run.py --liquidity --offline")
    else:
        plot_all(sys.argv[1], save_dir=sys.argv[2] if len(sys.argv) > 2 else None)
