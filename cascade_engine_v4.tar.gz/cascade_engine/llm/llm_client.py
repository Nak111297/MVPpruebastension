"""
Cliente LLM para Ollama local.

Maneja la comunicación con el servidor Ollama, incluyendo:
  - Retry con backoff exponencial (tenacity).
  - Parsing robusto de JSON desde respuestas del modelo.
  - Fallback transparente cuando Ollama no está disponible.

NUNCA envía datos fuera del banco — todo corre en localhost.
"""

from __future__ import annotations

import json
import logging
import re
import time
from typing import Any, Optional

from config.settings import LLMConfig

logger = logging.getLogger(__name__)


class LLMClient:
    """Cliente para consultar modelos LLM vía Ollama.

    Si Ollama no está disponible o la respuesta no es parseable,
    retorna None y el motor usa el fallback determinístico del agente.

    Attributes:
        config: Configuración del LLM.
        _available: Cache de disponibilidad del servidor.
        _call_count: Contador de llamadas realizadas.
        _fail_count: Contador de fallos.
    """

    def __init__(self, config: LLMConfig) -> None:
        self.config = config
        self._available: Optional[bool] = None
        self._call_count: int = 0
        self._fail_count: int = 0
        self._session: Optional[Any] = None

        if config.enabled:
            self._check_availability()

    def _check_availability(self) -> bool:
        """Verifica si Ollama está corriendo y accesible.

        Returns:
            True si el servidor responde.
        """
        try:
            import requests
            resp = requests.get(
                f"{self.config.base_url}/api/tags",
                timeout=5,
            )
            self._available = resp.status_code == 200
            if self._available:
                models = resp.json().get("models", [])
                model_names = [m.get("name", "") for m in models]
                if any(self.config.model in n for n in model_names):
                    logger.info(
                        "Ollama disponible en %s — modelo '%s' encontrado",
                        self.config.base_url, self.config.model,
                    )
                else:
                    logger.warning(
                        "Ollama disponible pero modelo '%s' no encontrado. "
                        "Modelos disponibles: %s. Se usará fallback.",
                        self.config.model, model_names,
                    )
                    self._available = False
            return self._available
        except Exception as e:
            logger.info(
                "Ollama no disponible en %s: %s. Se usará fallback determinístico.",
                self.config.base_url, str(e),
            )
            self._available = False
            return False

    def query(self, prompt: str) -> Optional[dict[str, Any]]:
        """Envía un prompt al LLM y retorna la respuesta parseada.

        Args:
            prompt: Prompt completo a enviar.

        Returns:
            Dict con la respuesta parseada del LLM, o None si falla.
            Esperado: {action, probability, amount_pct, channel, reasoning}.
        """
        if not self.config.enabled or self._available is False:
            return None

        self._call_count += 1

        for attempt in range(1, self.config.max_retries + 1):
            try:
                response_text = self._send_request(prompt)
                if response_text is None:
                    continue

                parsed = self._parse_json_response(response_text)
                if parsed is not None:
                    return parsed

                logger.warning(
                    "Intento %d/%d: respuesta no parseable del LLM",
                    attempt, self.config.max_retries,
                )

            except Exception as e:
                wait_time = min(
                    self.config.retry_base_wait * (2 ** (attempt - 1)),
                    self.config.retry_max_wait,
                )
                logger.warning(
                    "Intento %d/%d falló: %s. Reintentando en %.1fs...",
                    attempt, self.config.max_retries, str(e), wait_time,
                )
                time.sleep(wait_time)

        self._fail_count += 1
        logger.debug(
            "LLM falló después de %d intentos. Fallback determinístico.",
            self.config.max_retries,
        )
        return None

    def _send_request(self, prompt: str) -> Optional[str]:
        """Envía request HTTP a Ollama.

        Args:
            prompt: Texto del prompt.

        Returns:
            Texto de respuesta del modelo, o None si falla.
        """
        try:
            import requests

            payload = {
                "model": self.config.model,
                "prompt": prompt,
                "stream": False,
                "options": {
                    "temperature": self.config.temperature,
                    "num_predict": 512,
                },
                "format": "json",
            }

            resp = requests.post(
                f"{self.config.base_url}/api/generate",
                json=payload,
                timeout=self.config.timeout_seconds,
            )

            if resp.status_code != 200:
                logger.warning("Ollama respondió con status %d", resp.status_code)
                return None

            data = resp.json()
            return data.get("response", "")

        except ImportError:
            logger.warning("Módulo 'requests' no disponible")
            self._available = False
            return None
        except Exception as e:
            logger.debug("Error en request a Ollama: %s", str(e))
            return None

    def _parse_json_response(self, text: str) -> Optional[dict[str, Any]]:
        """Parsea la respuesta del LLM extrayendo JSON válido.

        Maneja múltiples formatos: JSON puro, markdown code blocks,
        o JSON embebido en texto.

        Args:
            text: Texto crudo de la respuesta.

        Returns:
            Dict parseado o None si no se pudo extraer.
        """
        text = text.strip()

        # Intento 1: JSON directo
        try:
            parsed = json.loads(text)
            if self._validate_response(parsed):
                return parsed
        except json.JSONDecodeError:
            pass

        # Intento 2: Extraer JSON de markdown code block
        json_match = re.search(r"```(?:json)?\s*\n?(.+?)\n?\s*```", text, re.DOTALL)
        if json_match:
            try:
                parsed = json.loads(json_match.group(1))
                if self._validate_response(parsed):
                    return parsed
            except json.JSONDecodeError:
                pass

        # Intento 3: Buscar primer { ... } en el texto
        brace_match = re.search(r"\{[^{}]*\}", text, re.DOTALL)
        if brace_match:
            try:
                parsed = json.loads(brace_match.group(0))
                if self._validate_response(parsed):
                    return parsed
            except json.JSONDecodeError:
                pass

        logger.debug("No se pudo extraer JSON válido de: %.200s...", text)
        return None

    @staticmethod
    def _validate_response(data: dict[str, Any]) -> bool:
        """Valida que la respuesta tenga los campos requeridos."""
        required = {"action", "probability"}
        return required.issubset(data.keys())

    @property
    def stats(self) -> dict[str, int]:
        """Estadísticas del cliente."""
        return {
            "calls": self._call_count,
            "failures": self._fail_count,
            "available": self._available or False,
        }
