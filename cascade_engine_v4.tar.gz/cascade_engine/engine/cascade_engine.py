"""
Motor principal de simulación de cascada.

Orquesta el flujo completo:
  1. Inicializa agentes y estado global.
  2. Para cada período: avanza estado → consulta agentes → agrega → registra.
  3. Retorna resultados consolidados.

Nunca lanza excepciones hacia arriba — siempre retorna un resultado.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Any, Optional

from agents.base_agent import BaseAgent, ChannelType
from agents.depositor_agents import create_all_depositor_agents, create_agents_from_calibration
from config.scenarios import ScenarioDefinition, ScenarioType
from config.settings import LLMConfig, OutputConfig, SimulationConfig
from engine.aggregator import AggregatedResult, Aggregator
from engine.state_manager import PeriodSnapshot, StateManager
from llm.llm_client import LLMClient

logger = logging.getLogger(__name__)


@dataclass
class SimulationResult:
    """Resultado completo de una simulación.

    Attributes:
        scenario_id: ID del escenario ejecutado.
        success: Si la simulación completó sin error fatal.
        error_message: Mensaje de error si success=False.
        summary: Resumen ejecutivo.
        snapshots: Snapshots por período.
        execution_time_seconds: Tiempo de ejecución.
        llm_calls_made: Número de llamadas al LLM.
        llm_fallbacks_used: Número de veces que se usó fallback.
        metadata: Metadata adicional.
    """
    scenario_id: str
    success: bool = True
    error_message: Optional[str] = None
    summary: dict[str, Any] = field(default_factory=dict)
    snapshots: list[dict[str, Any]] = field(default_factory=list)
    execution_time_seconds: float = 0.0
    llm_calls_made: int = 0
    llm_fallbacks_used: int = 0
    metadata: dict[str, Any] = field(default_factory=dict)


class CascadeEngine:
    """Motor de simulación de comportamiento en cascada.

    Coordina agentes, LLM, estado y agregación para ejecutar
    escenarios de stress testing con comportamiento emergente.

    Attributes:
        llm_config: Configuración del LLM.
        sim_config: Configuración de simulación.
        output_config: Configuración de salida.
        bank_params: Parámetros del banco (de calibration).
    """

    def __init__(
        self,
        llm_config: LLMConfig,
        sim_config: SimulationConfig,
        output_config: OutputConfig,
        bank_params: dict[str, Any],
    ) -> None:
        self.llm_config = llm_config
        self.sim_config = sim_config
        self.output_config = output_config
        self.bank_params = bank_params

        self._llm_client = LLMClient(llm_config)
        self._aggregator = Aggregator(sim_config)
        self._agents: list[BaseAgent] = []
        self._llm_calls: int = 0
        self._llm_fallbacks: int = 0

        logger.info(
            "CascadeEngine inicializado — LLM=%s, seed=%d",
            "ON" if llm_config.enabled else "OFF",
            sim_config.random_seed,
        )

    def run_scenario(self, scenario: ScenarioDefinition) -> SimulationResult:
        """Ejecuta un escenario completo.

        Args:
            scenario: Definición del escenario a ejecutar.

        Returns:
            SimulationResult con todos los resultados.
            Nunca lanza excepciones.
        """
        start = time.time()
        self._llm_calls = 0
        self._llm_fallbacks = 0
        self._agent_tracker: dict[str, dict[str, Any]] = {}

        try:
            logger.info(
                "═══ Iniciando escenario '%s' (%s, %d %s) ═══",
                scenario.id,
                scenario.scenario_type.value,
                scenario.periods,
                scenario.period_unit,
            )

            # Inicializar agentes según tipo de escenario
            self._agents = self._create_agents(scenario)
            total_pop = sum(a.population for a in self._agents)

            # Tracker acumulativo por agente (para reportes detallados)
            self._agent_tracker = {
                a.agent_id: {
                    "name": a.name,
                    "population": a.population,
                    "avg_balance_q": a.avg_balance_q,
                    "cumulative_amount_q": 0.0,
                    "cumulative_acted": 0,
                }
                for a in self._agents
            }

            # Inicializar state manager
            state_mgr = StateManager(scenario, self.sim_config, self.bank_params)
            state_mgr.set_total_population(total_pop)

            # Ejecutar períodos
            for period in range(1, scenario.periods + 1):
                self._run_period(period, scenario, state_mgr)

            # Compilar resultado
            elapsed = time.time() - start
            result = SimulationResult(
                scenario_id=scenario.id,
                success=True,
                summary=state_mgr.get_summary(),
                snapshots=[self._snapshot_to_dict(s) for s in state_mgr.snapshots],
                execution_time_seconds=round(elapsed, 2),
                llm_calls_made=self._llm_calls,
                llm_fallbacks_used=self._llm_fallbacks,
                metadata={
                    "total_population": total_pop,
                    "agents": [
                        {
                            "id": a.agent_id,
                            "name": a.name,
                            "population": a.population,
                            "avg_balance_q": a.avg_balance_q,
                            "sensitivity": a.sensitivity,
                            "panic_threshold": a.panic_threshold,
                            "preferred_channel": a.preferred_channel.value,
                            "latency_periods": a.latency_periods,
                            "panic_multiplier": a.panic_multiplier,
                        }
                        for a in self._agents
                    ],
                    "agent_tracker_final": dict(self._agent_tracker),
                    "scenario_description": scenario.description,
                    "severity": scenario.severity,
                },
            )

            self._log_summary(result)
            return result

        except Exception as e:
            elapsed = time.time() - start
            logger.error(
                "Error fatal en escenario '%s': %s", scenario.id, str(e), exc_info=True
            )
            return SimulationResult(
                scenario_id=scenario.id,
                success=False,
                error_message=str(e),
                execution_time_seconds=round(elapsed, 2),
                llm_calls_made=self._llm_calls,
                llm_fallbacks_used=self._llm_fallbacks,
            )

    def _create_agents(self, scenario: ScenarioDefinition) -> list[BaseAgent]:
        """Crea agentes según el tipo de escenario.

        Si hay datos calibrados (de data_processor.py), usa GenericDepositAgent.
        Si no, usa los 5 arquetipos sintéticos por defecto.
        """
        if scenario.scenario_type == ScenarioType.LIQUIDITY:
            # Intentar crear desde calibración
            cal_segments = self.bank_params.get("depositor_segments", [])
            source = self.bank_params.get("_calibration_sources", {})

            if source.get("depositor_segments") == "real" and cal_segments:
                agents = create_agents_from_calibration(cal_segments)
            else:
                agents = create_all_depositor_agents()

            for a in agents:
                a.reset()
            return agents
        elif scenario.scenario_type == ScenarioType.CREDIT:
            return self._create_credit_agents()
        elif scenario.scenario_type == ScenarioType.FX:
            return self._create_fx_agents()
        return []

    def _create_credit_agents(self) -> list[BaseAgent]:
        """Crea agentes proxy para módulo de crédito (sin LLM)."""
        # El módulo de crédito opera con fórmulas determinísticas,
        # no necesita agentes LLM. Retorna lista vacía.
        return []

    def _create_fx_agents(self) -> list[BaseAgent]:
        """Crea agentes proxy para módulo FX (sin LLM por ahora)."""
        # Similar a crédito — opera con fórmulas.
        return []

    def _run_period(
        self,
        period: int,
        scenario: ScenarioDefinition,
        state_mgr: StateManager,
    ) -> None:
        """Ejecuta un período completo de la simulación.

        Args:
            period: Número de período.
            scenario: Definición del escenario.
            state_mgr: Gestor de estado.
        """
        # 1. Avanzar estado
        state = state_mgr.advance_period(period)

        logger.info(
            "─── Período %d/%d — rumor=%.1f, app=%s, filas=%s, actuados=%.1f%% ───",
            period,
            scenario.periods,
            state.rumor_intensity,
            state.app_state.value,
            state.queue_state.value,
            state.pct_population_acted * 100,
        )

        if scenario.scenario_type == ScenarioType.LIQUIDITY:
            self._run_liquidity_period(period, state_mgr)
        elif scenario.scenario_type == ScenarioType.CREDIT:
            self._run_credit_period(period, state_mgr)
        elif scenario.scenario_type == ScenarioType.FX:
            self._run_fx_period(period, state_mgr)

    def _run_liquidity_period(self, period: int, state_mgr: StateManager) -> None:
        """Ejecuta un período del módulo de liquidez con tracking completo."""
        state = state_mgr.current_state
        period_decisions: list[dict[str, Any]] = []

        # ── Calcular multiplicador externo de empleados ──
        employee_multiplier = 1.0
        employee_panic_prob = 0.0
        employee_agent = None
        for agent in self._agents:
            if agent.agent_id == "empleado_agencia":
                employee_agent = agent
                emp_decision = agent.fallback_decision(state)
                employee_panic_prob = emp_decision.probability
                if emp_decision.probability > 0.3:
                    employee_multiplier = agent.panic_multiplier
                break

        # ── Registrar decisión del empleado (no retira, pero se reporta) ──
        if employee_agent is not None:
            tracker = self._agent_tracker.get(employee_agent.agent_id, {})
            period_decisions.append({
                "agent_id": employee_agent.agent_id,
                "agent_name": employee_agent.name,
                "n_acted": 0,
                "total_amount_qm": 0.0,
                "channel_distribution": {},
                "effective_probability": round(employee_panic_prob, 4),
                "original_probability": round(employee_panic_prob, 4),
                "cascade_modifier": 1.0,
                "action": "amplify_panic",
                "amount_pct": 0.0,
                "reasoning": (
                    f"Nivel de pánico empleados: {employee_panic_prob:.1%}. "
                    f"Multiplicador activo: ×{employee_multiplier:.1f}"
                ),
                "used_llm": False,
                "population_total": employee_agent.population,
                "population_remaining": employee_agent.population,
                "population_acted_cumulative": 0,
                "pct_acted_of_segment": 0.0,
                "avg_balance_q": 0.0,
                "cumulative_amount_qm": 0.0,
                "sensitivity": employee_agent.sensitivity,
                "panic_threshold": employee_agent.panic_threshold,
                "employee_multiplier_applied": employee_multiplier,
            })

        # ── Cada agente depositor toma decisión y se agrega ──
        for agent in self._agents:
            if agent.agent_id == "empleado_agencia":
                continue

            tracker = self._agent_tracker.setdefault(agent.agent_id, {
                "name": agent.name,
                "population": agent.population,
                "avg_balance_q": agent.avg_balance_q,
                "cumulative_amount_q": 0.0,
                "cumulative_acted": 0,
            })

            # Agente en latencia — registrar pero no actúa
            if not agent.can_act_in_period(period):
                period_decisions.append({
                    "agent_id": agent.agent_id,
                    "agent_name": agent.name,
                    "n_acted": 0,
                    "total_amount_qm": 0.0,
                    "channel_distribution": {},
                    "effective_probability": 0.0,
                    "original_probability": 0.0,
                    "cascade_modifier": 1.0,
                    "action": "latencia",
                    "amount_pct": 0.0,
                    "reasoning": f"En latencia hasta período {agent.latency_periods + 1}",
                    "used_llm": False,
                    "population_total": agent.population,
                    "population_remaining": agent.remaining_population,
                    "population_acted_cumulative": tracker["cumulative_acted"],
                    "pct_acted_of_segment": 0.0,
                    "avg_balance_q": agent.avg_balance_q,
                    "cumulative_amount_qm": round(tracker["cumulative_amount_q"] / 1_000_000.0, 4),
                    "sensitivity": agent.sensitivity,
                    "panic_threshold": agent.panic_threshold,
                })
                continue

            # Obtener decisión (LLM o fallback)
            decision = self._get_agent_decision(agent, state)

            # Agregar a nivel poblacional
            ext_mult = employee_multiplier if agent.preferred_channel == ChannelType.BRANCH else 1.0
            result = self._aggregator.aggregate(agent, decision, state, ext_mult)

            # Registrar en state manager
            if result.n_acted > 0:
                agent.record_actions(result.n_acted)
                state_mgr.record_acted(result.n_acted)

                for ch_str, count in result.channel_distribution.items():
                    channel = ChannelType(ch_str)
                    amount = result.total_amount_q * (count / result.n_acted) if result.n_acted > 0 else 0.0
                    state_mgr.record_period_withdrawals(amount, channel, count)

            # Actualizar tracker acumulativo
            tracker["cumulative_amount_q"] += result.total_amount_q
            tracker["cumulative_acted"] += result.n_acted

            # Construir dict enriquecido con datos del agente
            period_decisions.append(self._aggregator.to_dict(
                result,
                agent=agent,
                cumulative_amount_q=tracker["cumulative_amount_q"],
                cumulative_acted=tracker["cumulative_acted"],
            ))

            # Amplificación de rumor por millennials
            if (
                agent.agent_id == "millennial_digital"
                and hasattr(agent, "rumor_amplification")
                and result.n_acted > 0
            ):
                amp = getattr(agent, "rumor_amplification", 0.3)
                acted_pct = result.n_acted / agent.population if agent.population > 0 else 0
                rumor_boost = amp * acted_pct
                state_mgr._current_state.rumor_intensity = min(
                    10.0,
                    state_mgr._current_state.rumor_intensity + rumor_boost,
                )
                logger.debug(
                    "Millennial amplifica rumor en +%.2f (acted_pct=%.3f)",
                    rumor_boost, acted_pct,
                )

        # Snapshot al final del período
        state_mgr.take_snapshot(period_decisions)

    def _run_credit_period(self, period: int, state_mgr: StateManager) -> None:
        """Ejecuta un período del módulo de crédito (determinístico)."""
        # El avance del crédito ya se hizo en advance_period
        state_mgr.take_snapshot([])

    def _run_fx_period(self, period: int, state_mgr: StateManager) -> None:
        """Ejecuta un período del módulo FX (determinístico)."""
        # El avance FX ya se hizo en advance_period
        state_mgr.take_snapshot([])

    def _get_agent_decision(self, agent: BaseAgent, state: Any) -> Any:
        """Obtiene decisión del agente vía LLM o fallback.

        Args:
            agent: Agente a consultar.
            state: Estado actual del escenario.

        Returns:
            AgentDecision del agente.
        """
        if not self.llm_config.enabled:
            self._llm_fallbacks += 1
            return agent.fallback_decision(state)

        # Intentar LLM
        prompt = agent.build_prompt(state)
        self._llm_calls += 1

        llm_response = self._llm_client.query(prompt)

        if llm_response is not None:
            # Parsear respuesta LLM
            from agents.base_agent import ActionType, AgentDecision, ChannelType

            try:
                action = ActionType(llm_response.get("action", "hold"))
                probability = float(llm_response.get("probability", 0.0))
                amount_pct = float(llm_response.get("amount_pct", 0.0))
                channel_str = llm_response.get("channel", agent.preferred_channel.value)
                channel = ChannelType(channel_str)
                reasoning = llm_response.get("reasoning", "Sin razonamiento")

                return AgentDecision(
                    agent_id=agent.agent_id,
                    action=action,
                    probability=probability,
                    channel=channel,
                    reasoning=reasoning,
                    used_llm=True,
                    raw_llm_response=str(llm_response),
                    amount_pct=amount_pct,
                )
            except (ValueError, KeyError) as e:
                logger.warning(
                    "Error parseando respuesta LLM para %s: %s. Usando fallback.",
                    agent.agent_id, str(e),
                )
                self._llm_fallbacks += 1
                return agent.fallback_decision(state)
        else:
            self._llm_fallbacks += 1
            return agent.fallback_decision(state)

    def _snapshot_to_dict(self, snap: PeriodSnapshot) -> dict[str, Any]:
        """Convierte PeriodSnapshot a dict serializable."""
        return {
            "period": snap.period,
            "rumor_intensity": round(snap.rumor_intensity, 2),
            "app_state": snap.app_state,
            "queue_state": snap.queue_state,
            "cumulative_withdrawals_qm": round(snap.cumulative_withdrawals_qm, 2),
            "period_withdrawals_qm": round(snap.period_withdrawals_qm, 2),
            "lcr_projected": round(snap.lcr_projected, 4),
            "pct_population_acted": round(snap.pct_population_acted, 4),
            "channel_pressure": snap.channel_pressure,
            "intervention_active": snap.intervention_active,
            "agent_decisions": snap.agent_decisions,
            "pd_by_segment": {k: round(v, 6) for k, v in snap.pd_by_segment.items()},
            "cumulative_expected_loss_qm": round(snap.cumulative_expected_loss_qm, 2),
            "depreciation_pct": round(snap.depreciation_pct, 2),
            "fx_loss_by_segment": {k: round(v, 2) for k, v in snap.fx_loss_by_segment.items()},
            "usd_deposit_outflow_qm": round(snap.usd_deposit_outflow_qm, 2),
        }

    def _log_summary(self, result: SimulationResult) -> None:
        """Loguea resumen ejecutivo."""
        s = result.summary
        logger.info("═══ RESULTADO: %s ═══", result.scenario_id)
        logger.info("  Éxito: %s", result.success)
        logger.info("  Tiempo: %.2fs", result.execution_time_seconds)
        logger.info("  LLM calls: %d (fallbacks: %d)", result.llm_calls_made, result.llm_fallbacks_used)

        if s.get("total_withdrawals_qm", 0) > 0:
            logger.info("  Retiros totales: Q%.1fM", s["total_withdrawals_qm"])
            logger.info("  LCR final: %.3f %s",
                         s["final_lcr"],
                         "⚠ BREACH" if s.get("lcr_breached") else "✓")
            logger.info("  Población actuó: %.1f%%", s["pct_population_acted"] * 100)

        if s.get("cumulative_credit_loss_qm", 0) > 0:
            logger.info("  Pérdida crédito: Q%.1fM", s["cumulative_credit_loss_qm"])

        if s.get("cumulative_fx_loss_qm", 0) > 0:
            logger.info("  Pérdida FX: Q%.1fM", s["cumulative_fx_loss_qm"])

    def run_all_scenarios(
        self, scenarios: dict[str, ScenarioDefinition]
    ) -> list[SimulationResult]:
        """Ejecuta múltiples escenarios secuencialmente.

        Args:
            scenarios: Dict de scenario_id → ScenarioDefinition.

        Returns:
            Lista de SimulationResult, uno por escenario.
        """
        results: list[SimulationResult] = []
        total = len(scenarios)

        for idx, (sid, scenario) in enumerate(scenarios.items(), 1):
            logger.info(
                "\n╔══════════════════════════════════════════╗\n"
                "║ Escenario %d/%d: %s\n"
                "╚══════════════════════════════════════════╝",
                idx, total, sid,
            )
            result = self.run_scenario(scenario)
            results.append(result)

            # Re-seed para reproducibilidad entre escenarios
            self._aggregator.rng = __import__("numpy").random.default_rng(
                self.sim_config.random_seed + idx
            )

        return results
