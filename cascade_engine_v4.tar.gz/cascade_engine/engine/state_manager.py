"""
Gestor de estado global de la simulación.

Mantiene el estado observable del escenario, actualiza métricas por período,
aplica efectos de cascada (rumor → retiros → más rumor) y calcula LCR,
pérdida esperada de crédito y exposición FX.
"""

from __future__ import annotations

import logging
import math
from dataclasses import dataclass, field
from typing import Any, Optional

from agents.base_agent import AppState, ChannelType, QueueState, ScenarioState
from config.scenarios import (
    Intervention,
    InterventionType,
    ScenarioDefinition,
    ScenarioType,
)
from config.settings import SimulationConfig

logger = logging.getLogger(__name__)


@dataclass
class ChannelPressure:
    """Presión acumulada por canal."""
    withdrawals_q: float = 0.0
    transactions: int = 0

    @property
    def avg_transaction(self) -> float:
        if self.transactions == 0:
            return 0.0
        return self.withdrawals_q / self.transactions


@dataclass
class PeriodSnapshot:
    """Snapshot de métricas al final de un período."""
    period: int = 0
    rumor_intensity: float = 0.0
    app_state: str = "normal"
    queue_state: str = "normal"
    cumulative_withdrawals_qm: float = 0.0
    period_withdrawals_qm: float = 0.0
    lcr_projected: float = 1.45
    pct_population_acted: float = 0.0
    channel_pressure: dict[str, dict[str, Any]] = field(default_factory=dict)
    intervention_active: Optional[str] = None
    agent_decisions: list[dict[str, Any]] = field(default_factory=list)
    # Crédito
    pd_by_segment: dict[str, float] = field(default_factory=dict)
    cumulative_expected_loss_qm: float = 0.0
    delinquency_ratio: float = 0.0
    # FX
    depreciation_pct: float = 0.0
    fx_loss_by_segment: dict[str, float] = field(default_factory=dict)
    usd_deposit_outflow_qm: float = 0.0


class StateManager:
    """Administra el estado global de la simulación y calcula cascadas.

    Attributes:
        scenario: Definición del escenario activo.
        sim_config: Configuración de simulación.
        bank_params: Parámetros globales del banco (de calibration).
    """

    def __init__(
        self,
        scenario: ScenarioDefinition,
        sim_config: SimulationConfig,
        bank_params: dict[str, Any],
    ) -> None:
        self.scenario = scenario
        self.sim_config = sim_config
        self.bank_params = bank_params

        # Estado mutable
        self._current_state = ScenarioState(
            period=0,
            period_unit=scenario.period_unit,
        )
        self._cumulative_withdrawals: float = 0.0
        self._channel_pressure: dict[ChannelType, ChannelPressure] = {
            ch: ChannelPressure() for ch in ChannelType
        }
        self._snapshots: list[PeriodSnapshot] = []
        self._total_population: int = 0
        self._total_acted: int = 0

        # Crédito
        self._credit_segments: dict[str, dict[str, Any]] = {}
        self._cumulative_credit_loss: float = 0.0
        self._refinancing_active_from: Optional[int] = None
        self._refinancing_multiplier: float = 1.0

        # FX
        self._fx_segments: dict[str, dict[str, Any]] = {}
        self._cumulative_fx_loss: float = 0.0
        self._banguat_active_from: Optional[int] = None
        self._banguat_multiplier: float = 1.0
        self._cumulative_usd_outflow: float = 0.0

        self._initialize_state()
        logger.info(
            "StateManager inicializado para escenario '%s' (%s, %d períodos)",
            scenario.id, scenario.scenario_type.value, scenario.periods,
        )

    def _initialize_state(self) -> None:
        """Configura el estado inicial según el tipo de escenario."""
        params = self.scenario.shock_params

        if self.scenario.scenario_type == ScenarioType.LIQUIDITY:
            self._current_state.rumor_intensity = params.get("initial_rumor_intensity", 5.0)
            app_str = params.get("app_initial_state", "normal")
            self._current_state.app_state = AppState(app_str)
            self._current_state.lcr_current = self.bank_params.get("lcr_actual", 1.45)

        elif self.scenario.scenario_type == ScenarioType.CREDIT:
            self._credit_segments = {
                seg["id"]: {**seg, "pd_current": seg["pd_base"]}
                for seg in self.bank_params.get("credit_segments", [])
            }

        elif self.scenario.scenario_type == ScenarioType.FX:
            self._current_state.depreciation_speed = params.get("speed", "gradual")
            self._fx_segments = {
                seg["id"]: {**seg, "loss_accumulated": 0.0}
                for seg in self.bank_params.get("fx_segments", [])
            }

    @property
    def current_state(self) -> ScenarioState:
        """Estado observable actual (lectura)."""
        return self._current_state

    @property
    def snapshots(self) -> list[PeriodSnapshot]:
        """Historial de snapshots por período."""
        return self._snapshots

    def set_total_population(self, total: int) -> None:
        """Establece la población total de agentes (para cálculos de %)."""
        self._total_population = total

    # ─── AVANCE DE PERÍODO ───────────────────────────────────────────

    def advance_period(self, period: int) -> ScenarioState:
        """Avanza el estado al inicio del período indicado.

        Calcula: intensidad de rumor, estado de app, filas, intervenciones,
        shocks macro y FX según corresponda.

        Args:
            period: Número de período (1-indexed).

        Returns:
            Estado actualizado para consulta de agentes.
        """
        self._current_state.period = period
        intervention = self.scenario.has_intervention_at(period)

        if self.scenario.scenario_type == ScenarioType.LIQUIDITY:
            self._advance_liquidity(period, intervention)
        elif self.scenario.scenario_type == ScenarioType.CREDIT:
            self._advance_credit(period, intervention)
        elif self.scenario.scenario_type == ScenarioType.FX:
            self._advance_fx(period, intervention)

        if intervention:
            self._current_state.intervention_active = intervention.type.value
            if intervention.type.value not in self._current_state.intervention_history:
                self._current_state.intervention_history.append(intervention.type.value)
        else:
            # Mantener efecto de intervenciones pasadas como "history" pero
            # no como "active" si no hay nueva en este período
            self._current_state.intervention_active = None

        return self._current_state

    def _advance_liquidity(self, period: int, intervention: Optional[Intervention]) -> None:
        """Actualiza estado de liquidez: rumor, app, filas."""
        params = self.scenario.shock_params
        growth_rate = params.get("rumor_growth_rate", 0.4)

        # Crecimiento orgánico del rumor
        if period > 1:
            cascade_boost = 0.0
            if self._total_population > 0:
                pct = self._total_acted / self._total_population
                if pct > self.sim_config.panic_threshold_pct:
                    cascade_boost = (pct - self.sim_config.panic_threshold_pct) * 5.0

            new_intensity = (
                self._current_state.rumor_intensity
                + growth_rate
                + cascade_boost
            )

            # Intervención reduce intensidad
            if intervention and intervention.type == InterventionType.COMUNICADO_OFICIAL:
                reduction = intervention.params.get("intensity_reduction", 3.0)
                new_intensity -= reduction
                logger.info(
                    "Período %d: comunicado oficial reduce intensidad en %.1f",
                    period, reduction,
                )
            if intervention and intervention.type == InterventionType.EJECUTIVOS_LLAMAN:
                reduction = intervention.params.get("intensity_reduction", 1.5)
                new_intensity -= reduction
                logger.info(
                    "Período %d: ejecutivos llaman, reducción %.1f", period, reduction
                )

            self._current_state.rumor_intensity = max(0.0, min(10.0, new_intensity))

        # Estado de la app
        force_queue = params.get("force_queue_critical_from", None)
        if params.get("app_initial_state") != "down":
            app_thresholds = self.sim_config.app_degradation_thresholds
            digital_pct = self._get_digital_pressure_pct()
            if digital_pct >= app_thresholds["down"]:
                self._current_state.app_state = AppState.DOWN
            elif digital_pct >= app_thresholds["slow"]:
                self._current_state.app_state = AppState.SLOW
            else:
                self._current_state.app_state = AppState.NORMAL

        # Filas en agencia
        if force_queue and period >= force_queue:
            self._current_state.queue_state = QueueState.CRITICAL
        else:
            q_thresholds = self.sim_config.queue_thresholds
            branch_pct = self._get_branch_pressure_pct()
            if branch_pct >= q_thresholds["critical"]:
                self._current_state.queue_state = QueueState.CRITICAL
            elif branch_pct >= q_thresholds["long"]:
                self._current_state.queue_state = QueueState.LONG
            else:
                self._current_state.queue_state = QueueState.NORMAL

    def _advance_credit(self, period: int, intervention: Optional[Intervention]) -> None:
        """Actualiza PDs por segmento según shock macro."""
        params = self.scenario.shock_params
        delta_ue = params.get("delta_unemployment_pp", 0.0)
        delta_inf = params.get("delta_inflation_pp", 0.0)
        ramp = min(1.0, period / 4.0)

        # Activar refinanciamiento
        if intervention and intervention.type == InterventionType.REFINANCIAMIENTO_MASIVO:
            self._refinancing_active_from = period
            self._refinancing_multiplier = intervention.params.get("pd_multiplier", 0.62)
            logger.info(
                "Período %d: refinanciamiento masivo activado (mult=%.2f)",
                period, self._refinancing_multiplier,
            )

        self._current_state.delta_unemployment = delta_ue * ramp
        self._current_state.delta_inflation = delta_inf * ramp

        period_loss = 0.0
        for seg_id, seg in self._credit_segments.items():
            pd_base = seg["pd_base"]
            sens_ue = seg.get("sensitivity_unemployment", 1.0)
            sens_inf = seg.get("sensitivity_inflation", 0.5)

            pd_new = pd_base + (delta_ue * ramp * sens_ue / 100.0) + (delta_inf * ramp * sens_inf / 100.0)

            # Aplicar refinanciamiento si activo
            if self._refinancing_active_from and period >= self._refinancing_active_from:
                pd_new *= self._refinancing_multiplier

            pd_new = max(0.001, min(pd_new, 1.0))
            seg["pd_current"] = pd_new

            # Pérdida esperada
            exposure = seg.get("exposure_qm", 0.0)
            lgd = seg.get("lgd", 0.50)
            monthly_loss = exposure * pd_new * lgd / 12.0
            period_loss += monthly_loss

        self._cumulative_credit_loss += period_loss

    def _advance_fx(self, period: int, intervention: Optional[Intervention]) -> None:
        """Actualiza depreciación y exposición FX."""
        params = self.scenario.shock_params
        total_dep = params.get("depreciation_pct", 0.0)
        speed = params.get("speed", "gradual")

        # Activar Banguat
        if intervention and intervention.type == InterventionType.INTERVENCION_BANGUAT:
            self._banguat_active_from = period
            self._banguat_multiplier = intervention.params.get("depreciation_multiplier", 0.55)
            logger.info(
                "Período %d: Banguat interviene (mult=%.2f)", period, self._banguat_multiplier,
            )

        # Curva de depreciación
        if speed == "gradual":
            dep_pct = total_dep * (period / self.scenario.periods)
        else:  # shock
            dep_pct = total_dep * min(1.0, period / 3.0)

        # Aplicar Banguat
        if self._banguat_active_from and period >= self._banguat_active_from:
            dep_pct *= self._banguat_multiplier

        self._current_state.depreciation_current_pct = dep_pct
        self._current_state.depreciation_speed = speed

        # Calcular impacto por segmento FX
        period_loss = 0.0
        for seg_id, seg in self._fx_segments.items():
            threshold = seg.get("threshold_pct", 10.0)
            lgd = seg.get("lgd", 0.50)
            exposure = seg.get("exposure_qm", 0.0)
            sens = seg.get("sensitivity", 1.0)

            if dep_pct > threshold:
                excess = dep_pct - threshold
                loss = exposure * (excess / 100.0) * lgd * sens
                # Exportador se beneficia (sens negativa)
                if sens < 0:
                    loss = 0.0  # Beneficio no se suma a pérdidas
                period_loss += max(0.0, loss)
                seg["loss_accumulated"] = seg.get("loss_accumulated", 0.0) + max(0.0, loss)

            # Depositante dolarizado retira
            if seg_id == "depositante_dolarizado" and dep_pct > seg.get("threshold_pct", 5.0):
                outflow_rate = min(0.15, (dep_pct - threshold) / 100.0 * 2)
                deposits_usd_q = self.bank_params.get("depositos_usd_q", 9_360_000_000.0)
                period_outflow = deposits_usd_q * outflow_rate / self.scenario.periods
                self._cumulative_usd_outflow += period_outflow

        self._cumulative_fx_loss += period_loss

    # ─── REGISTRO DE RESULTADOS ──────────────────────────────────────

    def record_period_withdrawals(
        self,
        amount_q: float,
        channel: ChannelType,
        count: int,
    ) -> None:
        """Registra retiros de un período.

        Args:
            amount_q: Monto total en quetzales.
            channel: Canal utilizado.
            count: Número de transacciones.
        """
        self._cumulative_withdrawals += amount_q
        self._current_state.cumulative_withdrawals_qm = self._cumulative_withdrawals / 1_000_000.0
        self._channel_pressure[channel].withdrawals_q += amount_q
        self._channel_pressure[channel].transactions += count

    def record_acted(self, count: int) -> None:
        """Registra individuos que actuaron."""
        self._total_acted += count
        if self._total_population > 0:
            self._current_state.pct_population_acted = self._total_acted / self._total_population

    def take_snapshot(self, agent_decisions: list[dict[str, Any]]) -> PeriodSnapshot:
        """Captura snapshot completo del estado al final del período.

        Args:
            agent_decisions: Lista de decisiones de agentes como dicts.

        Returns:
            PeriodSnapshot con todas las métricas.
        """
        # LCR
        hqla = self.bank_params.get("hqla_inicial_q", 26_100_000_000.0)
        total_deposits = self.bank_params.get("total_depositos_q", 18_000_000_000.0)
        outflows = self._cumulative_withdrawals
        lcr = hqla / outflows if outflows > 0 else 99.0
        self._current_state.lcr_current = lcr

        snap = PeriodSnapshot(
            period=self._current_state.period,
            rumor_intensity=self._current_state.rumor_intensity,
            app_state=self._current_state.app_state.value,
            queue_state=self._current_state.queue_state.value,
            cumulative_withdrawals_qm=self._current_state.cumulative_withdrawals_qm,
            period_withdrawals_qm=0.0,  # Se calcula abajo
            lcr_projected=lcr,
            pct_population_acted=self._current_state.pct_population_acted,
            channel_pressure={
                ch.value: {"withdrawals_qm": cp.withdrawals_q / 1_000_000.0, "transactions": cp.transactions}
                for ch, cp in self._channel_pressure.items()
                if cp.transactions > 0
            },
            intervention_active=self._current_state.intervention_active,
            agent_decisions=agent_decisions,
            # Crédito
            pd_by_segment={
                seg_id: seg["pd_current"]
                for seg_id, seg in self._credit_segments.items()
            },
            cumulative_expected_loss_qm=self._cumulative_credit_loss / 1_000_000.0,
            # FX
            depreciation_pct=self._current_state.depreciation_current_pct,
            fx_loss_by_segment={
                seg_id: seg.get("loss_accumulated", 0.0) / 1_000_000.0
                for seg_id, seg in self._fx_segments.items()
            },
            usd_deposit_outflow_qm=self._cumulative_usd_outflow / 1_000_000.0,
        )

        # Calcular retiros del período
        if len(self._snapshots) > 0:
            snap.period_withdrawals_qm = (
                snap.cumulative_withdrawals_qm - self._snapshots[-1].cumulative_withdrawals_qm
            )
        else:
            snap.period_withdrawals_qm = snap.cumulative_withdrawals_qm

        self._snapshots.append(snap)

        if lcr < 1.0:
            logger.warning(
                "⚠ ALERTA LCR: Período %d — LCR=%.3f (<1.0). Retiros acumulados: Q%.1fM",
                snap.period, lcr, snap.cumulative_withdrawals_qm,
            )

        return snap

    # ─── HELPERS ─────────────────────────────────────────────────────

    def _get_digital_pressure_pct(self) -> float:
        """% de retiros por canales digitales sobre total de depósitos."""
        total_deposits = self.bank_params.get("total_depositos_q", 18_000_000_000.0)
        digital = sum(
            self._channel_pressure[ch].withdrawals_q
            for ch in [ChannelType.APP, ChannelType.CALL_CENTER]
        )
        return digital / total_deposits if total_deposits > 0 else 0.0

    def _get_branch_pressure_pct(self) -> float:
        """% de retiros por agencia sobre total de depósitos."""
        total_deposits = self.bank_params.get("total_depositos_q", 18_000_000_000.0)
        branch = self._channel_pressure[ChannelType.BRANCH].withdrawals_q
        return branch / total_deposits if total_deposits > 0 else 0.0

    def get_summary(self) -> dict[str, Any]:
        """Resumen ejecutivo para el reporte final."""
        return {
            "scenario_id": self.scenario.id,
            "scenario_name": self.scenario.name,
            "scenario_type": self.scenario.scenario_type.value,
            "periods_simulated": len(self._snapshots),
            "total_withdrawals_qm": self._current_state.cumulative_withdrawals_qm,
            "final_lcr": self._current_state.lcr_current,
            "lcr_breached": self._current_state.lcr_current < 1.0,
            "peak_rumor_intensity": max(
                (s.rumor_intensity for s in self._snapshots), default=0.0
            ),
            "pct_population_acted": self._current_state.pct_population_acted,
            "interventions_applied": self._current_state.intervention_history,
            "cumulative_credit_loss_qm": self._cumulative_credit_loss / 1_000_000.0,
            "cumulative_fx_loss_qm": self._cumulative_fx_loss / 1_000_000.0,
            "usd_deposit_outflow_qm": self._cumulative_usd_outflow / 1_000_000.0,
        }
