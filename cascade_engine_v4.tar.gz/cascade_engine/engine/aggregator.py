"""
Agregador: convierte decisiones de agentes en acciones poblacionales.

Toma la probabilidad estimada (LLM o fallback), aplica el modificador de
cascada y usa un muestreo binomial para determinar cuántos individuos
de cada segmento realmente actúan en el período.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

import numpy as np

from agents.base_agent import (
    ActionType,
    AgentDecision,
    BaseAgent,
    ChannelType,
    ScenarioState,
)
from config.settings import SimulationConfig

logger = logging.getLogger(__name__)


@dataclass
class AggregatedResult:
    """Resultado agregado de un agente para un período.

    Attributes:
        agent_id: Identificador del arquetipo.
        n_acted: Número de individuos que actuaron.
        total_amount_q: Monto total retirado en quetzales.
        channel_distribution: Distribución de acciones por canal.
        effective_probability: Probabilidad efectiva post-cascada.
        original_probability: Probabilidad original del agente.
        cascade_modifier: Factor de amplificación aplicado.
        decision: Decisión original del agente.
    """
    agent_id: str
    n_acted: int
    total_amount_q: float
    channel_distribution: dict[str, int] = field(default_factory=dict)
    effective_probability: float = 0.0
    original_probability: float = 0.0
    cascade_modifier: float = 1.0
    decision: AgentDecision | None = None


class Aggregator:
    """Convierte decisiones individuales en movimientos poblacionales.

    Usa muestreo binomial para simular cuántos individuos de un segmento
    actúan dado una probabilidad. Aplica modificadores de cascada cuando
    el porcentaje de actuación supera el umbral de pánico.

    Attributes:
        sim_config: Configuración de simulación.
        rng: Generador de números aleatorios con semilla fija.
    """

    def __init__(self, sim_config: SimulationConfig) -> None:
        self.sim_config = sim_config
        self.rng = np.random.default_rng(sim_config.random_seed)
        logger.debug("Aggregator inicializado con seed=%d", sim_config.random_seed)

    def aggregate(
        self,
        agent: BaseAgent,
        decision: AgentDecision,
        state: ScenarioState,
        panic_multiplier_external: float = 1.0,
    ) -> AggregatedResult:
        """Agrega la decisión de un agente a nivel poblacional.

        Args:
            agent: Agente que tomó la decisión.
            decision: Decisión del agente (LLM o fallback).
            state: Estado actual del escenario.
            panic_multiplier_external: Multiplicador externo (e.g. de empleados).

        Returns:
            AggregatedResult con el número de individuos que actuaron
            y montos retirados.
        """
        # Agentes sin población activa no generan retiros
        remaining = agent.remaining_population
        if remaining == 0 or decision.action == ActionType.HOLD:
            return AggregatedResult(
                agent_id=agent.agent_id,
                n_acted=0,
                total_amount_q=0.0,
                effective_probability=0.0,
                original_probability=decision.probability,
                cascade_modifier=1.0,
                decision=decision,
            )

        # ── Calcular modificador de cascada ──
        cascade_mod = 1.0
        pct_acted = state.pct_population_acted
        threshold = agent.panic_threshold

        if pct_acted > threshold:
            overflow = (pct_acted - threshold) / (1.0 - threshold + 1e-9)
            cascade_mod = 1.0 + overflow * (self.sim_config.cascade_amplification_rate - 1.0)

        # Aplicar multiplicador externo (empleados de agencia)
        cascade_mod *= panic_multiplier_external

        # Probabilidad efectiva
        effective_prob = min(
            decision.probability * cascade_mod,
            self.sim_config.max_probability_cap,
        )

        # ── Muestreo binomial ──
        n_acted = int(self.rng.binomial(remaining, effective_prob))

        # ── Monto retirado ──
        pct_withdraw = decision.amount_pct / 100.0
        total_amount = n_acted * agent.avg_balance_q * pct_withdraw

        # ── Distribución por canal con spillover ──
        channel_dist = self._distribute_channels(
            n_acted=n_acted,
            preferred=decision.channel,
            state=state,
        )

        result = AggregatedResult(
            agent_id=agent.agent_id,
            n_acted=n_acted,
            total_amount_q=total_amount,
            channel_distribution=channel_dist,
            effective_probability=effective_prob,
            original_probability=decision.probability,
            cascade_modifier=cascade_mod,
            decision=decision,
        )

        logger.debug(
            "Agregado %s: prob=%.3f→%.3f (cascade=%.2f), n=%d/%d, Q%.1fM",
            agent.agent_id,
            decision.probability,
            effective_prob,
            cascade_mod,
            n_acted,
            remaining,
            total_amount / 1_000_000,
        )

        return result

    def _distribute_channels(
        self,
        n_acted: int,
        preferred: ChannelType,
        state: ScenarioState,
    ) -> dict[str, int]:
        """Distribuye acciones entre canales con spillover realista.

        Si la app está caída, redirige a call_center y agencia.
        Si las filas son críticas, parte migra a ATM.

        Args:
            n_acted: Total de individuos que actuaron.
            preferred: Canal preferido del agente.
            state: Estado actual (para evaluar degradación).

        Returns:
            Dict con canal -> número de personas.
        """
        if n_acted == 0:
            return {}

        dist: dict[str, int] = {}

        if preferred == ChannelType.APP:
            if state.app_state.value == "down":
                # App caída → 60% call_center, 30% agencia, 10% ATM
                n_cc = int(n_acted * 0.60)
                n_branch = int(n_acted * 0.30)
                n_atm = n_acted - n_cc - n_branch
                dist = {
                    ChannelType.CALL_CENTER.value: n_cc,
                    ChannelType.BRANCH.value: n_branch,
                    ChannelType.ATM.value: n_atm,
                }
            elif state.app_state.value == "slow":
                # App lenta → 70% app, 20% call_center, 10% agencia
                n_app = int(n_acted * 0.70)
                n_cc = int(n_acted * 0.20)
                n_branch = n_acted - n_app - n_cc
                dist = {
                    ChannelType.APP.value: n_app,
                    ChannelType.CALL_CENTER.value: n_cc,
                    ChannelType.BRANCH.value: n_branch,
                }
            else:
                dist = {ChannelType.APP.value: n_acted}

        elif preferred == ChannelType.BRANCH:
            if state.queue_state.value == "critical":
                # Filas críticas → 75% agencia, 15% ATM, 10% call_center
                n_branch = int(n_acted * 0.75)
                n_atm = int(n_acted * 0.15)
                n_cc = n_acted - n_branch - n_atm
                dist = {
                    ChannelType.BRANCH.value: n_branch,
                    ChannelType.ATM.value: n_atm,
                    ChannelType.CALL_CENTER.value: n_cc,
                }
            else:
                dist = {ChannelType.BRANCH.value: n_acted}

        else:
            # Ejecutivo, call_center, ATM → sin spillover
            dist = {preferred.value: n_acted}

        # Limpiar zeros
        return {k: v for k, v in dist.items() if v > 0}

    def to_dict(
        self,
        result: AggregatedResult,
        agent: BaseAgent | None = None,
        cumulative_amount_q: float = 0.0,
        cumulative_acted: int = 0,
    ) -> dict[str, Any]:
        """Convierte AggregatedResult a dict enriquecido para serialización.

        Args:
            result: Resultado agregado.
            agent: Agente fuente (para incluir metadatos de población).
            cumulative_amount_q: Monto acumulado hasta este período.
            cumulative_acted: Individuos acumulados actuados hasta este período.

        Returns:
            Dict con métricas completas por agente y período.
        """
        d: dict[str, Any] = {
            "agent_id": result.agent_id,
            "n_acted": result.n_acted,
            "total_amount_qm": round(result.total_amount_q / 1_000_000.0, 4),
            "channel_distribution": result.channel_distribution,
            "effective_probability": round(result.effective_probability, 4),
            "original_probability": round(result.original_probability, 4),
            "cascade_modifier": round(result.cascade_modifier, 3),
            "action": result.decision.action.value if result.decision else "hold",
            "amount_pct": result.decision.amount_pct if result.decision else 0.0,
            "reasoning": result.decision.reasoning if result.decision else "",
            "used_llm": result.decision.used_llm if result.decision else False,
        }
        if agent is not None:
            d["agent_name"] = agent.name
            d["population_total"] = agent.population
            d["population_remaining"] = agent.remaining_population
            d["population_acted_cumulative"] = cumulative_acted
            d["pct_acted_of_segment"] = round(
                cumulative_acted / agent.population, 4
            ) if agent.population > 0 else 0.0
            d["avg_balance_q"] = agent.avg_balance_q
            d["cumulative_amount_qm"] = round(cumulative_amount_q / 1_000_000.0, 4)
            d["sensitivity"] = agent.sensitivity
            d["panic_threshold"] = agent.panic_threshold
        return d
