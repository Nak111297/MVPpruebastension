"""
Clases abstractas y estructuras de datos del sistema de agentes.

Define el contrato que todo arquetipo de depositante debe implementar,
así como las estructuras de estado y decisión que fluyen por el motor.
"""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional

logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════════════════
# Enumeraciones
# ═══════════════════════════════════════════════════════════════════════════

class ActionType(str, Enum):
    """Acciones posibles de un depositante."""
    HOLD = "hold"
    PARTIAL_WITHDRAW = "partial_withdraw"
    FULL_WITHDRAW = "full_withdraw"
    TRANSFER_OUT = "transfer_out"
    INCREASE_DEPOSIT = "increase_deposit"


class ChannelType(str, Enum):
    """Canales por los que un depositante puede actuar."""
    BRANCH = "branch"
    APP = "app"
    CALL_CENTER = "call_center"
    EXECUTIVE = "executive"
    ATM = "atm"


class AppState(str, Enum):
    """Estado operativo de la app móvil/banca en línea."""
    NORMAL = "normal"
    SLOW = "slow"
    DOWN = "down"


class QueueState(str, Enum):
    """Estado de filas en agencias."""
    NORMAL = "normal"
    LONG = "long"
    CRITICAL = "critical"


# ═══════════════════════════════════════════════════════════════════════════
# Estructuras de datos
# ═══════════════════════════════════════════════════════════════════════════

@dataclass
class ScenarioState:
    """Estado observable del escenario en un período dado.

    Este es el input que recibe cada agente para tomar su decisión.
    Se construye por el StateManager y se pasa al motor LLM.

    Attributes:
        period: Período actual (hora o mes).
        period_unit: Unidad temporal.
        rumor_intensity: Intensidad del rumor (0-10, módulo liquidez).
        app_state: Estado de la app.
        queue_state: Estado de filas en agencia.
        pct_population_acted: Fracción de población que ya retiró.
        cumulative_withdrawals_qm: Retiros acumulados en millones de quetzales.
        lcr_current: Ratio de cobertura de liquidez proyectado.
        intervention_active: Intervención activa en este período.
        intervention_history: Intervenciones ya aplicadas.
        delta_unemployment: Shock acumulado de desempleo (pp, módulo crédito).
        delta_inflation: Shock acumulado de inflación (pp, módulo crédito).
        depreciation_current_pct: Depreciación acumulada (%, módulo FX).
        depreciation_speed: Velocidad de depreciación.
        custom: Datos adicionales específicos del escenario.
    """
    period: int = 0
    period_unit: str = "horas"
    rumor_intensity: float = 0.0
    app_state: AppState = AppState.NORMAL
    queue_state: QueueState = QueueState.NORMAL
    pct_population_acted: float = 0.0
    cumulative_withdrawals_qm: float = 0.0
    lcr_current: float = 1.45
    intervention_active: Optional[str] = None
    intervention_history: list[str] = field(default_factory=list)
    # Módulo crédito
    delta_unemployment: float = 0.0
    delta_inflation: float = 0.0
    # Módulo FX
    depreciation_current_pct: float = 0.0
    depreciation_speed: str = "gradual"
    # Extensible
    custom: dict[str, Any] = field(default_factory=dict)

    def to_prompt_context(self) -> str:
        """Genera texto descriptivo del estado para el prompt del LLM."""
        lines = [
            f"Período actual: {self.period} ({self.period_unit})",
        ]
        if self.rumor_intensity > 0:
            lines.append(
                f"Intensidad del rumor en redes: {self.rumor_intensity:.1f}/10"
            )
        if self.app_state != AppState.NORMAL:
            labels = {AppState.SLOW: "lenta y con errores", AppState.DOWN: "caída completamente"}
            lines.append(f"La aplicación del banco está {labels.get(self.app_state, str(self.app_state.value))}")
        if self.queue_state != QueueState.NORMAL:
            labels = {QueueState.LONG: "largas (30+ minutos)", QueueState.CRITICAL: "críticas (2+ horas, policía presente)"}
            lines.append(f"Las filas en agencias están {labels.get(self.queue_state, str(self.queue_state.value))}")
        if self.pct_population_acted > 0:
            lines.append(
                f"Aproximadamente {self.pct_population_acted * 100:.1f}% de los clientes "
                f"ya han retirado fondos"
            )
        if self.cumulative_withdrawals_qm > 0:
            lines.append(
                f"Retiros acumulados: Q{self.cumulative_withdrawals_qm:,.1f} millones"
            )
        if self.intervention_active:
            labels = {
                "comunicado_oficial": "El banco acaba de emitir un comunicado oficial negando problemas",
                "ejecutivos_llaman": "Los ejecutivos de cuenta están llamando a clientes importantes",
                "refinanciamiento_masivo": "El banco está ofreciendo refinanciamiento masivo",
                "intervencion_banguat": "El Banco de Guatemala ha intervenido en el mercado cambiario",
            }
            lines.append(labels.get(self.intervention_active, f"Intervención activa: {self.intervention_active}"))
        if self.delta_unemployment > 0:
            lines.append(f"El desempleo ha subido {self.delta_unemployment:.1f} puntos porcentuales")
        if self.delta_inflation > 0:
            lines.append(f"La inflación ha subido {self.delta_inflation:.1f} puntos porcentuales")
        if self.depreciation_current_pct > 0:
            lines.append(
                f"El quetzal se ha depreciado {self.depreciation_current_pct:.1f}% frente al dólar"
            )
        return "\n".join(lines)


@dataclass
class AgentDecision:
    """Resultado de la decisión de un agente.

    Attributes:
        agent_id: Identificador del arquetipo.
        action: Acción decidida.
        probability: Probabilidad de ejecución (0.0-1.0).
        channel: Canal preferido.
        reasoning: Razonamiento del LLM o del fallback.
        used_llm: Si la decisión vino del LLM (True) o fallback (False).
        raw_llm_response: Respuesta cruda del LLM para auditoría.
        amount_pct: Porcentaje del saldo a retirar (0-100).
    """
    agent_id: str
    action: ActionType
    probability: float
    channel: ChannelType
    reasoning: str
    used_llm: bool = False
    raw_llm_response: Optional[str] = None
    amount_pct: float = 0.0

    def __post_init__(self) -> None:
        """Valida y acota la probabilidad."""
        self.probability = max(0.0, min(1.0, self.probability))
        self.amount_pct = max(0.0, min(100.0, self.amount_pct))


# ═══════════════════════════════════════════════════════════════════════════
# Agente base abstracto
# ═══════════════════════════════════════════════════════════════════════════

class BaseAgent(ABC):
    """Clase base para todos los arquetipos de agentes simulados.

    Cada agente representa un segmento de depositantes con comportamiento
    propio. Debe implementar la descripción de persona (para el prompt LLM)
    y un fallback determinístico.

    Attributes:
        agent_id: Identificador único del arquetipo.
        name: Nombre descriptivo.
        population: Número de individuos representados.
        avg_balance_q: Saldo promedio en quetzales.
        sensitivity: Sensibilidad al rumor (0.0-1.0).
        panic_threshold: Umbral de pánico colectivo (0.0-1.0).
        preferred_channel: Canal habitual.
        latency_periods: Períodos de latencia antes de actuar.
        panic_multiplier: Multiplicador de pánico sobre otros agentes.
        age: Edad representativa.
    """

    def __init__(
        self,
        agent_id: str,
        name: str,
        population: int,
        avg_balance_q: float,
        sensitivity: float,
        panic_threshold: float,
        preferred_channel: ChannelType,
        latency_periods: int = 0,
        panic_multiplier: float = 1.0,
        age: int = 40,
    ) -> None:
        self.agent_id = agent_id
        self.name = name
        self.population = population
        self.avg_balance_q = avg_balance_q
        self.sensitivity = sensitivity
        self.panic_threshold = panic_threshold
        self.preferred_channel = preferred_channel
        self.latency_periods = latency_periods
        self.panic_multiplier = panic_multiplier
        self.age = age
        self._acted_count: int = 0

        logger.debug(
            "Agente creado: %s (pop=%d, balance=Q%.0f, sens=%.2f)",
            agent_id, population, avg_balance_q, sensitivity,
        )

    @property
    def remaining_population(self) -> int:
        """Individuos que aún no han actuado."""
        return max(0, self.population - self._acted_count)

    @property
    def pct_acted(self) -> float:
        """Fracción de la población que ya actuó."""
        if self.population == 0:
            return 0.0
        return self._acted_count / self.population

    def record_actions(self, count: int) -> None:
        """Registra que `count` individuos actuaron."""
        self._acted_count = min(self.population, self._acted_count + count)

    def reset(self) -> None:
        """Reinicia el agente para una nueva simulación."""
        self._acted_count = 0

    def can_act_in_period(self, period: int) -> bool:
        """Verifica si el agente puede actuar en el período dado.

        Respeta la latencia configurada.
        """
        return period > self.latency_periods

    @abstractmethod
    def persona_description(self) -> str:
        """Retorna la descripción en primera persona para el prompt LLM.

        Debe incluir edad, perfil financiero, relación con el banco,
        preocupaciones y comportamiento habitual.
        """

    @abstractmethod
    def fallback_decision(self, state: ScenarioState) -> AgentDecision:
        """Decisión determinística cuando el LLM no está disponible.

        Esta función SIEMPRE debe retornar un resultado válido.
        Implementa la heurística del arquetipo.

        Args:
            state: Estado actual del escenario.

        Returns:
            AgentDecision con la decisión determinística.
        """

    def build_prompt(self, state: ScenarioState) -> str:
        """Construye el prompt completo para el LLM.

        Combina la persona del agente con el contexto del escenario.

        Args:
            state: Estado actual del escenario.

        Returns:
            Prompt listo para enviar al LLM.
        """
        return (
            f"Eres un cliente de banco en Guatemala. Tu perfil:\n\n"
            f"{self.persona_description()}\n\n"
            f"--- SITUACIÓN ACTUAL ---\n"
            f"{state.to_prompt_context()}\n\n"
            f"--- INSTRUCCIÓN ---\n"
            f"Basándote en tu perfil y la situación actual, decide qué harías.\n"
            f"Responde ÚNICAMENTE con un JSON válido (sin markdown, sin texto adicional):\n"
            f'{{\n'
            f'  "action": "hold" | "partial_withdraw" | "full_withdraw" | "transfer_out",\n'
            f'  "probability": 0.0 a 1.0,\n'
            f'  "amount_pct": 0 a 100,\n'
            f'  "channel": "branch" | "app" | "call_center" | "executive" | "atm",\n'
            f'  "reasoning": "Explicación breve de tu decisión"\n'
            f'}}\n'
        )

    def __repr__(self) -> str:
        return (
            f"{self.__class__.__name__}(id={self.agent_id!r}, "
            f"pop={self.population}, balance=Q{self.avg_balance_q:,.0f})"
        )
