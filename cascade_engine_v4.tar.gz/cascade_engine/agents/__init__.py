"""Agent module — base abstractions and concrete depositor archetypes."""

from agents.base_agent import (
    ActionType,
    ChannelType,
    AgentDecision,
    ScenarioState,
    BaseAgent,
)
from agents.depositor_agents import (
    ConservadorMayorAgent,
    EmpresarioCreditoAgent,
    MillennialDigitalAgent,
    ClienteRuralAgent,
    EmpleadoAgenciaAgent,
    GenericDepositAgent,
    create_all_depositor_agents,
    create_agents_from_calibration,
)

__all__ = [
    "ActionType",
    "ChannelType",
    "AgentDecision",
    "ScenarioState",
    "BaseAgent",
    "ConservadorMayorAgent",
    "EmpresarioCreditoAgent",
    "MillennialDigitalAgent",
    "ClienteRuralAgent",
    "EmpleadoAgenciaAgent",
    "create_all_depositor_agents",
]
