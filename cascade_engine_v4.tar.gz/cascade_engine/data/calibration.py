"""
Módulo de calibración con datos sintéticos y funciones de carga.

Provee datos por defecto para que el sistema funcione out-of-the-box.
Las funciones load_*() están diseñadas para ser reemplazadas con
conexiones a los sistemas internos del banco.

IMPORTANTE: Los datos sintéticos son ESTIMACIONES para desarrollo y demo.
Para producción, conectar con las fuentes reales del banco.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any, Optional

logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════════════════
# DATOS SINTÉTICOS POR DEFECTO
# ═══════════════════════════════════════════════════════════════════════════

SYNTHETIC_BANK_PARAMS: dict[str, Any] = {
    "nombre_banco": "G&T Continental",
    "pais": "Guatemala",
    "moneda": "GTQ",
    # Liquidez
    "total_depositos_q": 18_000_000_000.0,      # Q18,000M
    "hqla_inicial_q": 26_100_000_000.0,          # Q26,100M
    "lcr_actual": 1.45,
    # Crédito
    "cartera_total_credito_q": 14_500_000_000.0,  # Q14,500M
    # FX
    "depositos_usd": 1_200_000_000.0,             # $1,200M
    "cartera_usd": 900_000_000.0,                  # $900M
    "tipo_cambio_gtq_usd": 7.80,
    "depositos_usd_q": 1_200_000_000.0 * 7.80,    # En quetzales
    "cartera_usd_q": 900_000_000.0 * 7.80,
}

SYNTHETIC_DEPOSITOR_SEGMENTS: list[dict[str, Any]] = [
    {
        "id": "conservador_mayor",
        "name": "Conservador Mayor (+55)",
        "population": 18_000,
        "avg_balance_q": 45_000.0,
        "total_balance_q": 18_000 * 45_000.0,  # Q810M
        "sensitivity": 0.85,
        "panic_threshold": 0.30,
        "preferred_channel": "branch",
        "latency_periods": 0,
        "age": 62,
    },
    {
        "id": "empresario_credito",
        "name": "Empresario con Crédito",
        "population": 4_500,
        "avg_balance_q": 200_000.0,
        "total_balance_q": 4_500 * 200_000.0,  # Q900M
        "sensitivity": 0.35,
        "panic_threshold": 0.60,
        "preferred_channel": "executive",
        "latency_periods": 0,
        "age": 45,
    },
    {
        "id": "millennial_digital",
        "name": "Millennial Digital",
        "population": 35_000,
        "avg_balance_q": 15_000.0,
        "total_balance_q": 35_000 * 15_000.0,  # Q525M
        "sensitivity": 0.65,
        "panic_threshold": 0.20,
        "preferred_channel": "app",
        "latency_periods": 0,
        "age": 31,
        "rumor_amplification": 0.3,
    },
    {
        "id": "cliente_rural",
        "name": "Cliente Rural",
        "population": 22_000,
        "avg_balance_q": 7_500.0,
        "total_balance_q": 22_000 * 7_500.0,  # Q165M
        "sensitivity": 0.40,
        "panic_threshold": 0.70,
        "preferred_channel": "branch",
        "latency_periods": 2,
        "age": 48,
    },
    {
        "id": "empleado_agencia",
        "name": "Empleado de Agencia",
        "population": 450,
        "avg_balance_q": 0.0,
        "total_balance_q": 0.0,
        "sensitivity": 0.50,
        "panic_threshold": 0.40,
        "preferred_channel": "branch",
        "latency_periods": 0,
        "panic_multiplier": 1.4,
        "age": 32,
    },
    # ── Arquetipos adicionales para enriquecimiento futuro ──
    {
        "id": "gobierno_institucional",
        "name": "Cuenta Gubernamental",
        "population": 120,
        "avg_balance_q": 2_500_000.0,
        "total_balance_q": 120 * 2_500_000.0,
        "sensitivity": 0.15,
        "panic_threshold": 0.80,
        "preferred_channel": "executive",
        "latency_periods": 3,
        "age": 50,
    },
    {
        "id": "ong_cooperacion",
        "name": "ONG / Cooperación Internacional",
        "population": 80,
        "avg_balance_q": 800_000.0,
        "total_balance_q": 80 * 800_000.0,
        "sensitivity": 0.25,
        "panic_threshold": 0.50,
        "preferred_channel": "executive",
        "latency_periods": 1,
        "age": 42,
    },
    {
        "id": "remesero",
        "name": "Receptor de Remesas",
        "population": 45_000,
        "avg_balance_q": 3_200.0,
        "total_balance_q": 45_000 * 3_200.0,
        "sensitivity": 0.30,
        "panic_threshold": 0.75,
        "preferred_channel": "branch",
        "latency_periods": 1,
        "age": 38,
    },
    {
        "id": "universitario",
        "name": "Universitario Joven (<25)",
        "population": 28_000,
        "avg_balance_q": 4_500.0,
        "total_balance_q": 28_000 * 4_500.0,
        "sensitivity": 0.55,
        "panic_threshold": 0.25,
        "preferred_channel": "app",
        "latency_periods": 0,
        "age": 22,
    },
    {
        "id": "comerciante_mercado",
        "name": "Comerciante de Mercado",
        "population": 12_000,
        "avg_balance_q": 18_000.0,
        "total_balance_q": 12_000 * 18_000.0,
        "sensitivity": 0.60,
        "panic_threshold": 0.35,
        "preferred_channel": "branch",
        "latency_periods": 0,
        "age": 44,
    },
    {
        "id": "profesional_independiente",
        "name": "Profesional Independiente",
        "population": 8_000,
        "avg_balance_q": 85_000.0,
        "total_balance_q": 8_000 * 85_000.0,
        "sensitivity": 0.45,
        "panic_threshold": 0.45,
        "preferred_channel": "app",
        "latency_periods": 0,
        "age": 38,
    },
    {
        "id": "jubilado_clases",
        "name": "Jubilado IGSS",
        "population": 15_000,
        "avg_balance_q": 12_000.0,
        "total_balance_q": 15_000 * 12_000.0,
        "sensitivity": 0.75,
        "panic_threshold": 0.35,
        "preferred_channel": "branch",
        "latency_periods": 1,
        "age": 67,
    },
    {
        "id": "corporativo_grande",
        "name": "Corporativo Grande",
        "population": 50,
        "avg_balance_q": 15_000_000.0,
        "total_balance_q": 50 * 15_000_000.0,
        "sensitivity": 0.20,
        "panic_threshold": 0.70,
        "preferred_channel": "executive",
        "latency_periods": 1,
        "age": 52,
    },
]


SYNTHETIC_CREDIT_SEGMENTS: list[dict[str, Any]] = [
    {
        "id": "consumo_asalariado",
        "name": "Consumo Asalariado",
        "pd_base": 0.04,
        "lgd": 0.65,
        "exposure_qm": 3_800_000_000.0,
        "sensitivity_unemployment": 1.2,
        "sensitivity_inflation": 0.4,
    },
    {
        "id": "consumo_informal",
        "name": "Consumo Informal",
        "pd_base": 0.09,
        "lgd": 0.70,
        "exposure_qm": 1_200_000_000.0,
        "sensitivity_unemployment": 1.8,
        "sensitivity_inflation": 0.8,
    },
    {
        "id": "pyme",
        "name": "PYME",
        "pd_base": 0.06,
        "lgd": 0.45,
        "exposure_qm": 2_500_000_000.0,
        "sensitivity_unemployment": 1.0,
        "sensitivity_inflation": 0.6,
    },
    {
        "id": "hipotecario",
        "name": "Hipotecario",
        "pd_base": 0.02,
        "lgd": 0.25,
        "exposure_qm": 4_200_000_000.0,
        "sensitivity_unemployment": 0.8,
        "sensitivity_inflation": 0.3,
    },
    {
        "id": "empresarial",
        "name": "Empresarial",
        "pd_base": 0.03,
        "lgd": 0.35,
        "exposure_qm": 2_800_000_000.0,
        "sensitivity_unemployment": 0.6,
        "sensitivity_inflation": 0.5,
    },
]


SYNTHETIC_FX_SEGMENTS: list[dict[str, Any]] = [
    {
        "id": "deudor_usd_gtq",
        "name": "Deudor USD que gana en GTQ",
        "threshold_pct": 10.0,
        "lgd": 0.55,
        "exposure_qm": 3_500_000_000.0,
        "sensitivity": 1.0,
    },
    {
        "id": "importador_pyme",
        "name": "Importador PYME",
        "threshold_pct": 8.0,
        "lgd": 0.42,
        "exposure_qm": 1_800_000_000.0,
        "sensitivity": 1.0,
    },
    {
        "id": "exportador",
        "name": "Exportador (se beneficia)",
        "threshold_pct": 25.0,
        "lgd": 0.30,
        "exposure_qm": 1_200_000_000.0,
        "sensitivity": -0.5,  # Negativa = se beneficia
    },
    {
        "id": "depositante_dolarizado",
        "name": "Depositante USD (retira depósitos)",
        "threshold_pct": 5.0,
        "lgd": 0.10,
        "exposure_qm": SYNTHETIC_BANK_PARAMS["depositos_usd"] * SYNTHETIC_BANK_PARAMS["tipo_cambio_gtq_usd"],
        "sensitivity": 1.0,
    },
]


# ═══════════════════════════════════════════════════════════════════════════
# FUNCIONES DE CARGA DE DATOS REALES (stubs)
# ═══════════════════════════════════════════════════════════════════════════

def load_depositor_segments() -> Optional[list[dict[str, Any]]]:
    """Carga segmentos de depositantes desde JSON generado por data_processor.py.

    Busca automáticamente el archivo data/calibrated_segments.json.
    Si existe, lo carga. Si no, retorna None y se usan sintéticos.
    """
    json_path = Path(__file__).parent / "calibrated_segments.json"
    if json_path.exists():
        try:
            with open(json_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            segments = data.get("depositor_segments", [])
            if segments:
                logger.info(
                    "Segmentos reales cargados desde %s (%d arquetipos)",
                    json_path.name, len(segments),
                )
                return segments
        except Exception as e:
            logger.warning("Error leyendo %s: %s", json_path, e)
    return None


def load_credit_portfolio() -> Optional[list[dict[str, Any]]]:
    """Carga portafolio de crédito desde fuente real.

    INSTRUCCIONES PARA IMPLEMENTAR:
    ───────────────────────────────
    1. Conectar al sistema de cartera del banco.
    2. Query de ejemplo:

        SELECT
            segmento_credito AS id,
            nombre_segmento AS name,
            probabilidad_default_base AS pd_base,
            tasa_perdida_dado_default AS lgd,
            SUM(saldo_vigente) AS exposure_qm
        FROM cartera_credito
        WHERE estado IN ('VIGENTE', 'VENCIDO')
        GROUP BY segmento_credito, nombre_segmento,
                 probabilidad_default_base, tasa_perdida_dado_default;

    3. Los sensitivity_unemployment y sensitivity_inflation deben
       estimarse con regresiones históricas PD ~ desempleo + inflación
       por segmento, o usar los parámetros de los modelos IFRS9
       del banco.

    Returns:
        Lista de dicts o None si no hay datos reales disponibles.
    """
    logger.debug("load_credit_portfolio() — No implementado, usando sintéticos")
    return None


def load_fx_exposure() -> Optional[list[dict[str, Any]]]:
    """Carga exposición cambiaria desde fuente real.

    INSTRUCCIONES PARA IMPLEMENTAR:
    ───────────────────────────────
    1. Conectar al sistema de tesorería / posición cambiaria.
    2. Obtener exposiciones netas por segmento:
       - Deudores en USD con ingresos en GTQ
       - Importadores PYME
       - Exportadores (coberturas naturales)
       - Depósitos en USD

    3. Los thresholds representan el nivel de depreciación a partir
       del cual el segmento empieza a deteriorarse. Calibrar con
       el equipo de Riesgos de Mercado.

    Returns:
        Lista de dicts o None si no hay datos reales disponibles.
    """
    logger.debug("load_fx_exposure() — No implementado, usando sintéticos")
    return None


def load_bank_global_params() -> Optional[dict[str, Any]]:
    """Carga parámetros globales del banco desde JSON generado por data_processor.py.

    Busca automáticamente data/calibrated_segments.json.
    """
    json_path = Path(__file__).parent / "calibrated_segments.json"
    if json_path.exists():
        try:
            with open(json_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            params = data.get("bank_params", {})
            if params:
                logger.info("Parámetros del banco cargados desde %s", json_path.name)
                return params
        except Exception as e:
            logger.warning("Error leyendo %s: %s", json_path, e)
    return None


# ═══════════════════════════════════════════════════════════════════════════
# FUNCIÓN PRINCIPAL DE CALIBRACIÓN
# ═══════════════════════════════════════════════════════════════════════════

def get_calibration() -> dict[str, Any]:
    """Obtiene datos de calibración, mezclando reales con sintéticos.

    Intenta cargar datos reales primero. Si no están disponibles,
    usa los datos sintéticos como fallback. Si hay datos parciales,
    mezcla lo disponible.

    Returns:
        Dict con todas las calibraciones necesarias para el motor.
    """
    # Intentar cargar datos reales
    real_bank = load_bank_global_params()
    real_depositors = load_depositor_segments()
    real_credit = load_credit_portfolio()
    real_fx = load_fx_exposure()

    # Construir calibración con fallback
    bank_params = real_bank if real_bank else {**SYNTHETIC_BANK_PARAMS}
    depositor_segments = real_depositors if real_depositors else [*SYNTHETIC_DEPOSITOR_SEGMENTS]
    credit_segments = real_credit if real_credit else [*SYNTHETIC_CREDIT_SEGMENTS]
    fx_segments = real_fx if real_fx else [*SYNTHETIC_FX_SEGMENTS]

    # Agregar segmentos al bank_params para acceso uniforme
    bank_params["depositor_segments"] = depositor_segments
    bank_params["credit_segments"] = credit_segments
    bank_params["fx_segments"] = fx_segments

    sources_used = {
        "bank_params": "real" if real_bank else "synthetic",
        "depositor_segments": "real" if real_depositors else "synthetic",
        "credit_segments": "real" if real_credit else "synthetic",
        "fx_segments": "real" if real_fx else "synthetic",
    }

    logger.info("Calibración cargada — fuentes: %s", sources_used)
    bank_params["_calibration_sources"] = sources_used

    return bank_params


def apply_calibration_to_agents(
    agents: list,
    calibration: dict[str, Any],
) -> list:
    """Sobreescribe parámetros de agentes con datos de calibración.

    Busca en calibration['depositor_segments'] un registro con el mismo
    'id' que cada agente, y sobreescribe los atributos que encuentre.

    NO modifica el código de los agentes — solo sus atributos en runtime.

    Args:
        agents: Lista de BaseAgent instanciados.
        calibration: Dict retornado por get_calibration().

    Returns:
        La misma lista de agentes (modificados in-place).
    """
    segments = calibration.get("depositor_segments", [])
    seg_map = {s["id"]: s for s in segments}

    for agent in agents:
        seg = seg_map.get(agent.agent_id)
        if seg is None:
            continue

        # Mapeo de campos calibración → atributos del agente
        field_map = {
            "population": "population",
            "avg_balance_q": "avg_balance_q",
            "sensitivity": "sensitivity",
            "panic_threshold": "panic_threshold",
            "latency_periods": "latency_periods",
            "age": "age",
            "panic_multiplier": "panic_multiplier",
            "rumor_amplification": "rumor_amplification",
        }

        changes = []
        for cal_key, agent_attr in field_map.items():
            if cal_key in seg and hasattr(agent, agent_attr):
                old_val = getattr(agent, agent_attr)
                new_val = seg[cal_key]
                if old_val != new_val:
                    setattr(agent, agent_attr, new_val)
                    changes.append(f"{agent_attr}: {old_val}→{new_val}")

        if changes:
            logger.debug(
                "Calibración aplicada a %s: %s", agent.agent_id, ", ".join(changes)
            )

    return agents
