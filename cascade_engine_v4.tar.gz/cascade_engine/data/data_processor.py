"""
Procesador de datos del DWH → Arquetipos para el motor de cascada.

USO:
    python data/data_processor.py --input tu_archivo.csv --output data/calibrated_segments.json

ESTE SCRIPT:
    1. Lee el CSV que te entregó el equipo de BI
    2. Clasifica cada cuenta en un arquetipo basado en reglas simples
    3. Calcula los parámetros que necesita el motor (población, saldo, etc.)
    4. Exporta un JSON listo para que calibration.py lo consuma
    5. Genera un reporte en consola de lo que encontró

FORMATO DEL CSV ESPERADO:
    Columnas mínimas (los nombres se pueden cambiar abajo en COLUMN_MAP):
    - id_cliente:     Identificador anonimizado
    - saldo:          Saldo disponible en quetzales
    - tipo_cuenta:    Ej: "ahorro", "monetaria", "empresarial", "plazo_fijo"
    - tiene_credito:  "si" / "no" (o 1 / 0)
    - monto_credito:  Monto del crédito si tiene (0 si no)
    - canal_principal: "app", "agencia", "ejecutivo", "banca_empresarial"
    - antiguedad_anios: Años como cliente
    - tipo_persona:   "individual" / "juridica" (persona o empresa)

    Si tu CSV tiene nombres diferentes, cambiá el diccionario COLUMN_MAP abajo.
"""

from __future__ import annotations

import argparse
import json
import logging
import sys
from pathlib import Path
from typing import Any

import pandas as pd
import numpy as np

logging.basicConfig(level=logging.INFO, format="%(message)s")
logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════════
# CONFIGURACIÓN — MODIFICÁ ESTO SEGÚN TU CSV
# ═══════════════════════════════════════════════════════════════════

# Si las columnas de tu CSV tienen nombres diferentes, cambiá el valor
# (derecha) para que coincida con tu archivo. La clave (izquierda) no se toca.
COLUMN_MAP = {
    "id_cliente": "id_cliente",
    "saldo": "saldo",
    "tipo_cuenta": "tipo_cuenta",
    "tiene_credito": "tiene_credito",
    "monto_credito": "monto_credito",
    "canal_principal": "canal_principal",
    "antiguedad_anios": "antiguedad_anios",
    "tipo_persona": "tipo_persona",       # "individual" o "juridica"
}

# Umbrales para clasificar cuentas.
# Estos son los cortes que definen cada arquetipo.
# Ajustalos según lo que veas en la distribución de tu data.
THRESHOLDS = {
    # Capa 1: Corporativo e Institucional
    "corporativo_aaa_min_saldo": 50_000_000,     # Q50M+ → Corporativo AAA
    "empresa_mediana_min_saldo": 5_000_000,       # Q5M-Q50M con crédito → Empresa Mediana
    "institucional_tipos": ["gobierno", "institucional", "fideicomiso", "municipal"],

    # Capa 2: PYME y Comercial
    "pyme_min_saldo": 500_000,                    # Q500K-Q5M empresa → PYME
    "pyme_max_saldo": 5_000_000,

    # Capa 3: Personas
    "alto_valor_min_saldo": 150_000,              # Q150K+ individual → Alto Valor
    "digital_max_edad_cuenta": 5,                 # Menos de 5 años + canal app → Digital Joven
    "digital_canal": "app",
}

# Parámetros de comportamiento por defecto para cada arquetipo.
# Estos son estimaciones iniciales basadas en juicio.
# Vas a querer ajustarlos después de ver los primeros resultados.
DEFAULT_BEHAVIOR = {
    "corporativo_aaa": {
        "sensitivity": 0.25,
        "panic_threshold": 0.15,
        "preferred_channel": "executive",
        "latency_periods": 0,
        "panic_multiplier": 2.0,
        "withdrawal_pattern": "full_withdraw",
        "info_channel": "institucional",
    },
    "empresa_mediana_credito": {
        "sensitivity": 0.30,
        "panic_threshold": 0.55,
        "preferred_channel": "executive",
        "latency_periods": 0,
        "panic_multiplier": 1.0,
        "withdrawal_pattern": "partial_withdraw",
        "info_channel": "gremial",
    },
    "institucional_gobierno": {
        "sensitivity": 0.15,
        "panic_threshold": 0.70,
        "preferred_channel": "executive",
        "latency_periods": 2,
        "panic_multiplier": 1.0,
        "withdrawal_pattern": "full_withdraw",
        "info_channel": "institucional",
    },
    "pyme_comerciante": {
        "sensitivity": 0.55,
        "panic_threshold": 0.35,
        "preferred_channel": "branch",
        "latency_periods": 1,
        "panic_multiplier": 1.2,
        "withdrawal_pattern": "partial_withdraw",
        "info_channel": "gremial",
    },
    "pyme_credito": {
        "sensitivity": 0.30,
        "panic_threshold": 0.60,
        "preferred_channel": "executive",
        "latency_periods": 1,
        "panic_multiplier": 1.0,
        "withdrawal_pattern": "partial_withdraw",
        "info_channel": "ejecutivo",
    },
    "asalariado_nomina": {
        "sensitivity": 0.50,
        "panic_threshold": 0.25,
        "preferred_channel": "app",
        "latency_periods": 1,
        "panic_multiplier": 1.0,
        "withdrawal_pattern": "partial_withdraw",
        "info_channel": "redes",
    },
    "depositante_alto_valor": {
        "sensitivity": 0.40,
        "panic_threshold": 0.45,
        "preferred_channel": "executive",
        "latency_periods": 0,
        "panic_multiplier": 1.0,
        "withdrawal_pattern": "partial_withdraw",
        "info_channel": "ejecutivo",
    },
    "digital_joven": {
        "sensitivity": 0.65,
        "panic_threshold": 0.20,
        "preferred_channel": "app",
        "latency_periods": 0,
        "panic_multiplier": 1.0,
        "withdrawal_pattern": "transfer_out",
        "info_channel": "redes",
        "rumor_amplification": 0.4,
    },
    "otros_retail": {
        "sensitivity": 0.45,
        "panic_threshold": 0.40,
        "preferred_channel": "branch",
        "latency_periods": 1,
        "panic_multiplier": 1.0,
        "withdrawal_pattern": "partial_withdraw",
        "info_channel": "redes",
    },
    "empleado_agencia": {
        "sensitivity": 0.50,
        "panic_threshold": 0.40,
        "preferred_channel": "branch",
        "latency_periods": 0,
        "panic_multiplier": 1.4,
        "withdrawal_pattern": "amplify_panic",
        "info_channel": "interno",
    },
}


# ═══════════════════════════════════════════════════════════════════
# LÓGICA DE CLASIFICACIÓN
# ═══════════════════════════════════════════════════════════════════

def load_csv(path: str) -> pd.DataFrame:
    """Carga el CSV y renombra columnas según COLUMN_MAP."""
    logger.info(f"\n{'='*60}")
    logger.info(f"  Cargando: {path}")
    logger.info(f"{'='*60}")

    # Intentar diferentes separadores
    for sep in [",", ";", "\t", "|"]:
        try:
            df = pd.read_csv(path, sep=sep, encoding="utf-8")
            if len(df.columns) > 2:
                break
        except Exception:
            continue
    else:
        # Último intento con latin-1
        df = pd.read_csv(path, encoding="latin-1")

    logger.info(f"  Filas: {len(df):,}")
    logger.info(f"  Columnas encontradas: {list(df.columns)}")

    # Renombrar columnas
    reverse_map = {v: k for k, v in COLUMN_MAP.items()}
    df = df.rename(columns=reverse_map)

    # Normalizar tiene_credito a booleano
    if "tiene_credito" in df.columns:
        df["tiene_credito"] = df["tiene_credito"].apply(
            lambda x: str(x).lower().strip() in ("si", "sí", "1", "true", "yes", "s")
        )

    # Llenar NaN
    if "monto_credito" in df.columns:
        df["monto_credito"] = pd.to_numeric(df["monto_credito"], errors="coerce").fillna(0)
    else:
        df["monto_credito"] = 0

    if "antiguedad_anios" in df.columns:
        df["antiguedad_anios"] = pd.to_numeric(df["antiguedad_anios"], errors="coerce").fillna(3)
    else:
        df["antiguedad_anios"] = 3

    if "tipo_persona" not in df.columns:
        df["tipo_persona"] = "individual"

    if "canal_principal" not in df.columns:
        df["canal_principal"] = "agencia"

    if "tipo_cuenta" not in df.columns:
        df["tipo_cuenta"] = "ahorro"

    df["saldo"] = pd.to_numeric(df["saldo"], errors="coerce").fillna(0)

    logger.info(f"  Saldo total: Q{df['saldo'].sum():,.0f}")
    logger.info(f"  Saldo promedio: Q{df['saldo'].mean():,.0f}")
    logger.info(f"  Saldo mediana: Q{df['saldo'].median():,.0f}")

    return df


def classify_account(row: pd.Series) -> str:
    """Clasifica una cuenta en un arquetipo basado en reglas.

    Si querés cambiar la lógica de clasificación, modificá esta función.
    Cada condición se evalúa en orden de prioridad (más específico primero).
    """
    saldo = row.get("saldo", 0)
    tipo = str(row.get("tipo_cuenta", "")).lower().strip()
    credito = row.get("tiene_credito", False)
    persona = str(row.get("tipo_persona", "individual")).lower().strip()
    canal = str(row.get("canal_principal", "")).lower().strip()
    antig = row.get("antiguedad_anios", 3)

    T = THRESHOLDS

    # ── Capa 1: Corporativo e Institucional ──

    # Institucional/Gobierno: detectar por tipo de cuenta
    inst_tipos = T["institucional_tipos"]
    if any(t in tipo for t in inst_tipos) or any(t in persona for t in inst_tipos):
        return "institucional_gobierno"

    # Corporativo AAA: saldo > Q50M
    if saldo >= T["corporativo_aaa_min_saldo"]:
        return "corporativo_aaa"

    # Empresa Mediana con Crédito: Q5M-Q50M + jurídica + crédito
    if (saldo >= T["empresa_mediana_min_saldo"]
            and persona == "juridica" and credito):
        return "empresa_mediana_credito"

    # Empresa Mediana sin crédito pero jurídica con saldo alto → PYME grande
    if saldo >= T["empresa_mediana_min_saldo"] and persona == "juridica":
        return "pyme_comerciante"

    # ── Capa 2: PYME ──

    if (T["pyme_min_saldo"] <= saldo < T["pyme_max_saldo"]
            and persona == "juridica"):
        if credito:
            return "pyme_credito"
        return "pyme_comerciante"

    # ── Capa 3: Personas ──

    if persona in ("individual", "persona", "natural"):
        # Alto valor
        if saldo >= T["alto_valor_min_saldo"]:
            return "depositante_alto_valor"

        # Digital joven
        if canal == T["digital_canal"] and antig <= T["digital_max_edad_cuenta"]:
            return "digital_joven"

        # Asalariado (nómina)
        if "nomina" in tipo or "nómina" in tipo or "planilla" in tipo:
            return "asalariado_nomina"

        # Si tiene saldo y usa app
        if canal == "app":
            return "digital_joven"

        # Default retail
        return "asalariado_nomina"

    # Catch-all
    return "otros_retail"


def process_data(df: pd.DataFrame) -> list[dict[str, Any]]:
    """Procesa el DataFrame y genera la lista de arquetipos calibrados."""

    logger.info(f"\n{'='*60}")
    logger.info("  Clasificando cuentas en arquetipos...")
    logger.info(f"{'='*60}")

    # Clasificar cada cuenta
    df["archetype"] = df.apply(classify_account, axis=1)

    # Agregar por arquetipo
    segments = []
    total_saldo = df["saldo"].sum()

    for arch_id, group in df.groupby("archetype"):
        pop = len(group)
        saldo_total = group["saldo"].sum()
        saldo_avg = group["saldo"].mean()
        pct_depositos = saldo_total / total_saldo if total_saldo > 0 else 0
        pct_con_credito = group["tiene_credito"].mean() if "tiene_credito" in group.columns else 0

        # Canal dominante
        if "canal_principal" in group.columns:
            canal_dom = group["canal_principal"].mode().iloc[0] if len(group["canal_principal"].mode()) > 0 else "agencia"
        else:
            canal_dom = "agencia"

        # Ancla relacional (0-1)
        # 0.5 si tiene crédito + 0.3 por productos cruzados (proxy: antigüedad alta)
        # + 0.2 por antigüedad
        antig_media = group["antiguedad_anios"].mean() if "antiguedad_anios" in group.columns else 3
        ancla = (pct_con_credito * 0.5) + (min(antig_media / 15, 1.0) * 0.3)
        if pct_con_credito > 0.5:
            ancla += 0.2
        ancla = min(ancla, 1.0)

        # Obtener comportamiento por defecto
        behavior = DEFAULT_BEHAVIOR.get(arch_id, DEFAULT_BEHAVIOR["otros_retail"])

        seg = {
            "id": arch_id,
            "name": arch_id.replace("_", " ").title(),
            "population": pop,
            "avg_balance_q": round(saldo_avg, 2),
            "total_balance_q": round(saldo_total, 2),
            "pct_of_total_deposits": round(pct_depositos, 4),
            "pct_with_credit": round(pct_con_credito, 4),
            "dominant_channel": canal_dom,
            "anchor_index": round(ancla, 3),
            "avg_tenure_years": round(antig_media, 1),
            # Parámetros de comportamiento
            "sensitivity": behavior["sensitivity"],
            "panic_threshold": behavior["panic_threshold"],
            "preferred_channel": behavior["preferred_channel"],
            "latency_periods": behavior["latency_periods"],
            "panic_multiplier": behavior["panic_multiplier"],
            "withdrawal_pattern": behavior["withdrawal_pattern"],
            "info_channel": behavior["info_channel"],
        }

        if "rumor_amplification" in behavior:
            seg["rumor_amplification"] = behavior["rumor_amplification"]

        segments.append(seg)

        logger.info(
            f"  {arch_id:30s}  pop={pop:>7,}  saldo_avg=Q{saldo_avg:>14,.0f}  "
            f"total=Q{saldo_total:>16,.0f}  ({pct_depositos*100:5.1f}%)  "
            f"ancla={ancla:.2f}"
        )

    # Ordenar por saldo total descendente
    segments.sort(key=lambda s: s["total_balance_q"], reverse=True)

    # Agregar empleados del banco (siempre)
    emp_exists = any(s["id"] == "empleado_agencia" for s in segments)
    if not emp_exists:
        segments.append({
            "id": "empleado_agencia",
            "name": "Empleado Agencia",
            "population": 450,
            "avg_balance_q": 0,
            "total_balance_q": 0,
            "pct_of_total_deposits": 0,
            "pct_with_credit": 0,
            "dominant_channel": "branch",
            "anchor_index": 0.9,
            "avg_tenure_years": 5,
            **DEFAULT_BEHAVIOR["empleado_agencia"],
        })

    logger.info(f"\n  Total arquetipos: {len(segments)}")
    logger.info(f"  Cuentas clasificadas: {len(df):,}")
    logger.info(f"  Saldo total cubierto: Q{sum(s['total_balance_q'] for s in segments):,.0f}")

    return segments


def print_summary(segments: list[dict], bank_params: dict) -> None:
    """Imprime resumen ejecutivo de la calibración."""
    total_dep = bank_params.get("total_depositos_q", sum(s["total_balance_q"] for s in segments))

    logger.info(f"\n{'='*60}")
    logger.info("  RESUMEN DE CALIBRACIÓN")
    logger.info(f"{'='*60}")
    logger.info(f"\n  Depósitos totales: Q{total_dep:,.0f}")
    logger.info(f"  Arquetipos: {len(segments)}")
    logger.info(f"\n  {'Arquetipo':<30s} {'Pop':>8s} {'Saldo Tot':>16s} {'%Dep':>6s} {'Sens':>5s} {'Umbral':>7s}")
    logger.info(f"  {'-'*75}")

    for s in segments:
        logger.info(
            f"  {s['id']:<30s} {s['population']:>8,} "
            f"Q{s['total_balance_q']:>14,.0f} "
            f"{s['pct_of_total_deposits']*100:>5.1f}% "
            f"{s['sensitivity']:>5.2f} "
            f"{s['panic_threshold']:>6.2f}"
        )

    # Concentración
    top3 = sorted(segments, key=lambda s: s["total_balance_q"], reverse=True)[:3]
    top3_pct = sum(s["pct_of_total_deposits"] for s in top3) * 100
    logger.info(f"\n  Top 3 arquetipos concentran: {top3_pct:.1f}% de depósitos")

    # Validación
    covered = sum(s["total_balance_q"] for s in segments)
    coverage = covered / total_dep * 100 if total_dep > 0 else 0
    logger.info(f"  Cobertura vs depósitos totales: {coverage:.1f}%")
    if coverage < 90:
        logger.warning(f"  ⚠ Cobertura < 90% — puede haber cuentas faltantes en el CSV")
    if coverage > 105:
        logger.warning(f"  ⚠ Cobertura > 105% — verificar que no hay duplicados")

    logger.info(f"\n{'='*60}")


def save_output(segments: list[dict], bank_params: dict, output_path: str) -> None:
    """Guarda la calibración como JSON."""
    output = {
        "generated_at": str(pd.Timestamp.now()),
        "bank_params": bank_params,
        "depositor_segments": segments,
    }
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    logger.info(f"\n  ✓ Calibración guardada en: {output_path}")
    logger.info(f"    Para usarla, corre: python run.py --all --offline")
    logger.info(f"    El motor detecta automáticamente el archivo JSON.\n")


# ═══════════════════════════════════════════════════════════════════
# PARÁMETROS DEL BANCO — ACTUALIZÁ CON DATOS REALES
# ═══════════════════════════════════════════════════════════════════

def get_bank_params() -> dict[str, Any]:
    """Parámetros globales del banco.

    INSTRUCCIONES:
    Reemplazá los valores abajo con los datos reales de Tesorería/ALM.
    Estos 4 números los podés conseguir del último reporte de LCR
    o pidiéndolos directamente a Tesorería.
    """
    return {
        "nombre_banco": "G&T Continental",
        "pais": "Guatemala",
        "moneda": "GTQ",
        # ── REEMPLAZAR CON DATOS REALES ──
        "total_depositos_q": 18_000_000_000.0,      # Total depósitos (Q)
        "hqla_inicial_q": 26_100_000_000.0,          # HQLA (Q)
        "lcr_actual": 1.45,                           # LCR reportado
        "tipo_cambio_gtq_usd": 7.80,                 # TC Banguat
        "depositos_usd": 1_200_000_000.0,             # Depósitos en USD
    }


# ═══════════════════════════════════════════════════════════════════
# CLI
# ═══════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(
        description="Procesa CSV del DWH → Arquetipos calibrados para el motor de cascada",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Ejemplo:
  python data/data_processor.py --input depositos_gt.csv
  python data/data_processor.py --input depositos_gt.csv --output mis_arquetipos.json
        """,
    )
    parser.add_argument("--input", "-i", required=True, help="Ruta al CSV del DWH")
    parser.add_argument("--output", "-o", default="data/calibrated_segments.json",
                        help="Ruta de salida del JSON (default: data/calibrated_segments.json)")

    args = parser.parse_args()

    if not Path(args.input).exists():
        logger.error(f"Archivo no encontrado: {args.input}")
        sys.exit(1)

    # Cargar y procesar
    df = load_csv(args.input)
    segments = process_data(df)
    bank_params = get_bank_params()

    # Resumen
    print_summary(segments, bank_params)

    # Guardar
    save_output(segments, bank_params, args.output)


if __name__ == "__main__":
    main()
