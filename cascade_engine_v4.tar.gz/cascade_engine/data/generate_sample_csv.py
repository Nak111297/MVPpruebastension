"""
Genera un CSV de ejemplo que simula un extract del DWH de depósitos.
Esto es para probar el pipeline ANTES de tener datos reales.

Uso: python data/generate_sample_csv.py
Genera: data/sample_depositos.csv
"""
import numpy as np
import pandas as pd

rng = np.random.default_rng(42)

records = []

# Corporativos AAA (20 cuentas, saldos Q50M-Q500M)
for i in range(20):
    records.append({
        "id_cliente": f"CORP_{i:04d}",
        "saldo": rng.uniform(50_000_000, 500_000_000),
        "tipo_cuenta": "empresarial",
        "tiene_credito": rng.choice(["si", "no"], p=[0.7, 0.3]),
        "monto_credito": rng.uniform(10_000_000, 200_000_000) if rng.random() > 0.3 else 0,
        "canal_principal": "ejecutivo",
        "antiguedad_anios": rng.uniform(5, 25),
        "tipo_persona": "juridica",
    })

# Empresas medianas con crédito (200 cuentas, Q5M-Q50M)
for i in range(200):
    records.append({
        "id_cliente": f"EMED_{i:04d}",
        "saldo": rng.uniform(5_000_000, 50_000_000),
        "tipo_cuenta": "empresarial",
        "tiene_credito": "si",
        "monto_credito": rng.uniform(2_000_000, 30_000_000),
        "canal_principal": rng.choice(["ejecutivo", "banca_empresarial"]),
        "antiguedad_anios": rng.uniform(3, 20),
        "tipo_persona": "juridica",
    })

# Institucional/Gobierno (40 cuentas)
for i in range(40):
    records.append({
        "id_cliente": f"INST_{i:04d}",
        "saldo": rng.uniform(20_000_000, 300_000_000),
        "tipo_cuenta": rng.choice(["gobierno", "institucional", "fideicomiso"]),
        "tiene_credito": "no",
        "monto_credito": 0,
        "canal_principal": "ejecutivo",
        "antiguedad_anios": rng.uniform(5, 30),
        "tipo_persona": "juridica",
    })

# PYMEs (1500 cuentas, Q500K-Q5M)
for i in range(1500):
    has_credit = rng.choice(["si", "no"], p=[0.4, 0.6])
    records.append({
        "id_cliente": f"PYME_{i:04d}",
        "saldo": rng.uniform(500_000, 5_000_000),
        "tipo_cuenta": "empresarial",
        "tiene_credito": has_credit,
        "monto_credito": rng.uniform(200_000, 3_000_000) if has_credit == "si" else 0,
        "canal_principal": rng.choice(["banca_empresarial", "agencia", "ejecutivo"], p=[0.4, 0.4, 0.2]),
        "antiguedad_anios": rng.uniform(1, 15),
        "tipo_persona": "juridica",
    })

# Depositantes alto valor persona (4000 cuentas, Q150K-Q3M)
for i in range(4000):
    records.append({
        "id_cliente": f"ALTV_{i:04d}",
        "saldo": rng.uniform(150_000, 3_000_000),
        "tipo_cuenta": rng.choice(["ahorro", "plazo_fijo", "monetaria"]),
        "tiene_credito": rng.choice(["si", "no"], p=[0.3, 0.7]),
        "monto_credito": rng.uniform(50_000, 500_000) if rng.random() > 0.7 else 0,
        "canal_principal": rng.choice(["app", "ejecutivo", "agencia"], p=[0.3, 0.3, 0.4]),
        "antiguedad_anios": rng.uniform(3, 20),
        "tipo_persona": "individual",
    })

# Asalariados nómina (45000 cuentas, Q2K-Q30K)
for i in range(45000):
    records.append({
        "id_cliente": f"NOMI_{i:05d}",
        "saldo": rng.exponential(12000) + 2000,
        "tipo_cuenta": "nomina",
        "tiene_credito": rng.choice(["si", "no"], p=[0.2, 0.8]),
        "monto_credito": rng.uniform(5_000, 50_000) if rng.random() > 0.8 else 0,
        "canal_principal": rng.choice(["app", "agencia"], p=[0.45, 0.55]),
        "antiguedad_anios": rng.uniform(0.5, 12),
        "tipo_persona": "individual",
    })

# Digital joven (20000 cuentas, Q1K-Q20K)
for i in range(20000):
    records.append({
        "id_cliente": f"DIGI_{i:05d}",
        "saldo": rng.exponential(8000) + 1000,
        "tipo_cuenta": "ahorro",
        "tiene_credito": "no",
        "monto_credito": 0,
        "canal_principal": "app",
        "antiguedad_anios": rng.uniform(0.3, 4),
        "tipo_persona": "individual",
    })

df = pd.DataFrame(records)

# Redondear
df["saldo"] = df["saldo"].round(2)
df["monto_credito"] = df["monto_credito"].round(2)
df["antiguedad_anios"] = df["antiguedad_anios"].round(1)

output = "data/sample_depositos.csv"
df.to_csv(output, index=False)

total = df["saldo"].sum()
print(f"CSV generado: {output}")
print(f"  {len(df):,} cuentas")
print(f"  Saldo total: Q{total:,.0f}")
print(f"  Top 20 cuentas: Q{df.nlargest(20, 'saldo')['saldo'].sum():,.0f} ({df.nlargest(20, 'saldo')['saldo'].sum()/total*100:.1f}%)")
