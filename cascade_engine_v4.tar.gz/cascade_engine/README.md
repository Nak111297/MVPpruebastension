# Cascade Engine — Motor de Simulación de Cascada para Stress Testing Bancario

**G&T Continental — Gerencia de Riesgos Financieros, Guatemala**

Motor de simulación que reemplaza los supuestos estáticos de comportamiento de clientes en pruebas de tensión (stress testing) con comportamiento emergente simulado por arquetipos de clientes usando un LLM local.

## Base académica

- *Generative Agent Simulations of 1,000 People* — Park et al., Stanford 2024
- *Generative Agents: Interactive Simulacra of Human Behavior* — Park et al., Stanford/Google, ACM UIST 2023
- Bank of England Working Paper 2025: Agent-Based Modeling at Central Banks
- Basel Committee BIS WP 29: Making Supervisory Stress Tests More Macroprudential (Principio 8)

## Características principales

- **Comportamiento emergente**: agentes LLM simulan decisiones de clientes en primera persona, no reglas fijas.
- **100% local**: todo corre en localhost — ningún dato del banco sale de la red interna.
- **Efecto cascada**: más gente actuando → más rumor → más gente actúa. Dinámica no lineal realista.
- **3 módulos**: liquidez (corrida de depósitos), crédito (deterioro de portafolio), FX (shock cambiario).
- **10 escenarios** pre-configurados con intervenciones del banco y regulador.
- **Siempre funcional**: si Ollama no está disponible, usa fallback determinístico transparente.
- **Reproducible**: semilla aleatoria configurable.
- **Exportación profesional**: JSON, CSV y Excel con formato para la Gerencia.

## Instalación en Windows

### 1. Prerrequisitos

- Python 3.10 o superior: [python.org/downloads](https://www.python.org/downloads/)
  - Al instalar, marcar "Add Python to PATH"
- Git (opcional): [git-scm.com](https://git-scm.com/)

### 2. Clonar o copiar el proyecto

```powershell
# Si tiene Git:
git clone <url-del-repo> cascade_engine
cd cascade_engine

# Si no: copiar la carpeta cascade_engine/ al directorio deseado
cd cascade_engine
```

### 3. Crear entorno virtual

```powershell
python -m venv .venv
.venv\Scripts\activate
```

### 4. Instalar dependencias

```powershell
pip install -r requirements.txt
```

### 5. (Opcional) Instalar Ollama para modo LLM

1. Descargar Ollama: [ollama.com/download](https://ollama.com/download)
2. Instalar y abrir Ollama
3. Descargar el modelo:

```powershell
ollama pull llama3.2
```

4. Verificar que está corriendo:

```powershell
curl http://localhost:11434/api/tags
```

### 6. Verificar entorno

```powershell
python run.py --check
```

## Uso

### Ejecutar un escenario específico

```powershell
python run.py --scenario liq_001
```

### Ejecutar varios escenarios

```powershell
python run.py --scenario liq_001 liq_002 cred_001
```

### Ejecutar todos los escenarios

```powershell
python run.py --all
```

### Modo offline (sin LLM)

```powershell
python run.py --all --offline
```

### Controlar exportación

```powershell
python run.py --scenario liq_001 --export json excel
```

### Modo verbose con seed personalizada

```powershell
python run.py --all --offline --verbose --seed 123 --output-dir ./mis_resultados
```

## Escenarios disponibles

| ID | Módulo | Nombre | Severidad |
|---|---|---|---|
| `liq_001` | Liquidez | Corrida base sin intervención | Moderada |
| `liq_002` | Liquidez | Corrida con comunicado hora 2 | Moderada |
| `liq_003` | Liquidez | Corrida con ejecutivos hora 5 | Severa |
| `liq_004` | Liquidez | Corrida severa — app caída + filas | Severa |
| `cred_001` | Crédito | Shock macro leve | Leve |
| `cred_002` | Crédito | Shock macro severo | Severa |
| `cred_003` | Crédito | Shock severo + refinanciamiento mes 3 | Severa |
| `fx_001` | FX | Depreciación 8% gradual | Leve |
| `fx_002` | FX | Depreciación 18% shock + rumor | Severa |
| `fx_003` | FX | Depreciación 18% + intervención Banguat mes 2 | Severa |

## Arquetipos de depositantes (módulo liquidez)

| Arquetipo | Población | Saldo prom. | Sensibilidad | Umbral pánico | Canal |
|---|---|---|---|---|---|
| Conservador Mayor (+55) | 18,000 | Q45,000 | 85% | 30% | Agencia |
| Empresario con Crédito | 4,500 | Q200,000 | 35% | 60% | Ejecutivo |
| Millennial Digital | 35,000 | Q15,000 | 65% | 20% | App |
| Cliente Rural | 22,000 | Q7,500 | 40% | 70% | Agencia |
| Empleado de Agencia | 450 | Q0 (indirecto) | 50% | 40% | N/A |

## Arquitectura

```
cascade_engine/
├── run.py                    # Entry point CLI
├── config/
│   ├── settings.py           # LLMConfig, SimulationConfig, OutputConfig
│   └── scenarios.py          # 10 escenarios con intervenciones
├── agents/
│   ├── base_agent.py         # Abstracciones: BaseAgent, ScenarioState, AgentDecision
│   └── depositor_agents.py   # 5 arquetipos concretos
├── engine/
│   ├── cascade_engine.py     # Motor principal orquestador
│   ├── state_manager.py      # Estado global + cascada + métricas LCR
│   └── aggregator.py         # Decisión → población (binomial)
├── llm/
│   └── llm_client.py         # Cliente Ollama con retry/backoff
├── data/
│   └── calibration.py        # Datos sintéticos + stubs para datos reales
└── outputs/
    └── results_writer.py     # JSON, CSV, Excel
```

## Conexión con datos reales del banco

El archivo `data/calibration.py` contiene 4 funciones stub listas para implementar:

- `load_depositor_segments()` — Conectar al core bancario para segmentos de depositantes
- `load_credit_portfolio()` — Cargar portafolio de crédito para PDs y LGDs reales
- `load_fx_exposure()` — Obtener exposición cambiaria de tesorería
- `load_bank_global_params()` — Parámetros globales (HQLA, LCR, depósitos totales)

Cada función incluye instrucciones detalladas y queries de ejemplo.

## Notas de seguridad

- El LLM corre **100% local** via Ollama — ningún dato sale del banco.
- Los datos del banco nunca se hardcodean en el motor — siempre vienen de `calibration.py`.
- No hay dependencias de red en ejecución (solo instalación de paquetes).
- El sistema funciona completamente offline con `--offline`.

## Licencia

Uso interno — G&T Continental, Gerencia de Riesgos Financieros.
