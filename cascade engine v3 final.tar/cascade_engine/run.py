#!/usr/bin/env python3
"""
Motor de Simulación de Cascada para Stress Testing Bancario
G&T Continental — Gerencia de Riesgos Financieros

Entry point con CLI para ejecutar escenarios de stress testing
con comportamiento emergente simulado por agentes LLM.

Uso:
    python run.py --scenario liq_001          # Escenario específico
    python run.py --all                       # Todos los escenarios
    python run.py --offline                   # Sin LLM (fallback determinístico)
    python run.py --export json csv excel     # Formatos de exportación
    python run.py --check                     # Verifica entorno
"""

from __future__ import annotations

import argparse
import logging
import sys
import time
from dataclasses import asdict
from datetime import datetime
from pathlib import Path
from typing import Any

# ── Asegurar que el directorio raíz esté en sys.path ──
ROOT_DIR = Path(__file__).resolve().parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from config.scenarios import ALL_SCENARIOS, ScenarioDefinition, get_scenario
from config.settings import LLMConfig, LogLevel, OutputConfig, SimulationConfig, get_default_configs
from data.calibration import apply_calibration_to_agents, get_calibration
from engine.cascade_engine import CascadeEngine, SimulationResult
from outputs.results_writer import ResultsWriter

logger = logging.getLogger("cascade_engine")


def setup_logging(level: str = "INFO") -> None:
    """Configura logging global del motor."""
    log_level = getattr(logging, level.upper(), logging.INFO)
    logging.basicConfig(
        level=log_level,
        format="%(asctime)s │ %(levelname)-8s │ %(name)-24s │ %(message)s",
        datefmt="%H:%M:%S",
        handlers=[logging.StreamHandler(sys.stdout)],
    )
    # Silenciar loggers ruidosos
    logging.getLogger("urllib3").setLevel(logging.WARNING)
    logging.getLogger("requests").setLevel(logging.WARNING)


def check_environment() -> bool:
    """Verifica que el entorno tenga todo lo necesario.

    Returns:
        True si todo OK.
    """
    print("=" * 60)
    print("  Verificación de Entorno — Cascade Engine")
    print("=" * 60)
    all_ok = True

    # Python version
    py_ver = sys.version_info
    py_ok = py_ver >= (3, 10)
    print(f"\n  Python {py_ver.major}.{py_ver.minor}.{py_ver.micro}"
          f"  {'✓' if py_ok else '✗ Requiere >= 3.10'}")
    all_ok &= py_ok

    # Dependencias
    deps = {
        "numpy": "Muestreo binomial y estadísticas",
        "openpyxl": "Exportación a Excel (opcional)",
        "requests": "Comunicación con Ollama (opcional)",
    }

    print("\n  Dependencias:")
    for pkg, desc in deps.items():
        try:
            mod = __import__(pkg)
            ver = getattr(mod, "__version__", "?")
            print(f"    {pkg:15s} {ver:10s}  ✓  ({desc})")
        except ImportError:
            optional = pkg in ("openpyxl", "requests")
            status = "⚠ Opcional" if optional else "✗ Requerido"
            print(f"    {pkg:15s} {'---':10s}  {status}  ({desc})")
            if not optional:
                all_ok = False

    # Ollama
    print("\n  Ollama LLM:")
    try:
        import requests
        resp = requests.get("http://localhost:11434/api/tags", timeout=3)
        if resp.status_code == 200:
            models = [m.get("name", "") for m in resp.json().get("models", [])]
            print(f"    Servidor:  ✓ Disponible")
            print(f"    Modelos:   {', '.join(models) if models else 'Ninguno instalado'}")
            if any("llama3" in m for m in models):
                print(f"    llama3.2:  ✓ Encontrado")
            else:
                print(f"    llama3.2:  ⚠ No encontrado (instalar con: ollama pull llama3.2)")
        else:
            print(f"    Servidor:  ⚠ Responde pero status {resp.status_code}")
    except Exception:
        print(f"    Servidor:  ⚠ No disponible (modo --offline funcional)")

    # Calibración
    print("\n  Calibración:")
    cal = get_calibration()
    sources = cal.get("_calibration_sources", {})
    for key, source in sources.items():
        icon = "✓" if source == "real" else "⚠ sintético"
        print(f"    {key:25s}  {icon}")

    # Escenarios
    print(f"\n  Escenarios disponibles: {len(ALL_SCENARIOS)}")
    for sid, sc in ALL_SCENARIOS.items():
        print(f"    {sid:12s}  {sc.name}")

    print("\n" + "=" * 60)
    status = "✓ Entorno listo" if all_ok else "✗ Hay dependencias faltantes"
    print(f"  {status}")
    print("=" * 60)

    return all_ok


def run_simulation(
    scenario_ids: list[str],
    offline: bool = False,
    export_formats: list[str] | None = None,
    seed: int | None = None,
    output_dir: str | None = None,
    log_level: str = "INFO",
    verbose: bool = False,
) -> list[SimulationResult]:
    """Ejecuta la simulación para los escenarios indicados.

    Args:
        scenario_ids: Lista de IDs de escenarios a ejecutar.
        offline: Si True, no usa LLM.
        export_formats: Formatos de exportación.
        seed: Semilla aleatoria.
        output_dir: Directorio de salida.
        log_level: Nivel de logging.
        verbose: Si True, incluye razonamiento de agentes.

    Returns:
        Lista de SimulationResult.
    """
    setup_logging(log_level if not verbose else "DEBUG")

    # Configuración
    formats = export_formats or ["json", "csv", "excel"]
    llm_cfg, sim_cfg, out_cfg = get_default_configs(
        offline=offline,
        seed=seed,
        output_dir=output_dir,
        formats=formats,
    )

    if verbose:
        out_cfg = OutputConfig(
            output_dir=out_cfg.output_dir,
            formats=out_cfg.formats,
            include_agent_reasoning=True,
            include_period_snapshots=True,
            excel_sheet_per_scenario=True,
            timestamp_filenames=out_cfg.timestamp_filenames,
        )

    # Calibración
    bank_params = get_calibration()

    # Motor
    engine = CascadeEngine(llm_cfg, sim_cfg, out_cfg, bank_params)

    # Resolver escenarios
    scenarios: dict[str, ScenarioDefinition] = {}
    for sid in scenario_ids:
        try:
            scenarios[sid] = get_scenario(sid)
        except KeyError as e:
            logger.error(str(e))
            sys.exit(1)

    # Ejecutar
    start = time.time()
    logger.info(
        "\n╔══════════════════════════════════════════════════════╗\n"
        "║  CASCADE ENGINE — G&T Continental Stress Testing     ║\n"
        "║  Escenarios: %-38s║\n"
        "║  Modo: %-44s║\n"
        "╚══════════════════════════════════════════════════════╝",
        ", ".join(scenario_ids),
        "Offline (determinístico)" if offline else "Con LLM",
    )

    results = engine.run_all_scenarios(scenarios)
    total_time = time.time() - start

    # Exportar
    writer = ResultsWriter(out_cfg)
    run_metadata: dict[str, Any] = {
        "timestamp": datetime.now().isoformat(),
        "scenarios": scenario_ids,
        "offline": offline,
        "seed": sim_cfg.random_seed,
        "total_execution_seconds": round(total_time, 2),
        "engine_version": "1.0.0",
    }

    result_dicts = [_result_to_dict(r) for r in results]
    generated_files = writer.write_results(result_dicts, run_metadata)

    # Resumen final
    _print_final_summary(results, total_time, generated_files)

    return results


def _result_to_dict(result: SimulationResult) -> dict[str, Any]:
    """Convierte SimulationResult a dict serializable."""
    return {
        "scenario_id": result.scenario_id,
        "success": result.success,
        "error_message": result.error_message,
        "summary": result.summary,
        "snapshots": result.snapshots,
        "execution_time_seconds": result.execution_time_seconds,
        "llm_calls_made": result.llm_calls_made,
        "llm_fallbacks_used": result.llm_fallbacks_used,
        "metadata": result.metadata,
    }


def _print_final_summary(
    results: list[SimulationResult],
    total_time: float,
    files: list[Path],
) -> None:
    """Imprime resumen final de la ejecución."""
    print("\n" + "═" * 60)
    print("  RESUMEN FINAL DE EJECUCIÓN")
    print("═" * 60)

    for r in results:
        s = r.summary
        status = "✓" if r.success else "✗"
        print(f"\n  {status} {r.scenario_id}: {s.get('scenario_name', 'N/A')}")

        if s.get("total_withdrawals_qm", 0) > 0:
            lcr = s.get("final_lcr", 0)
            lcr_flag = " ⚠ BREACH" if s.get("lcr_breached") else ""
            print(f"    Retiros: Q{s['total_withdrawals_qm']:,.1f}M")
            print(f"    LCR final: {lcr:.3f}{lcr_flag}")
            print(f"    Población actuó: {s.get('pct_population_acted', 0) * 100:.1f}%")

        if s.get("cumulative_credit_loss_qm", 0) > 0:
            print(f"    Pérdida crédito: Q{s['cumulative_credit_loss_qm']:,.1f}M")

        if s.get("cumulative_fx_loss_qm", 0) > 0:
            print(f"    Pérdida FX: Q{s['cumulative_fx_loss_qm']:,.1f}M")

        print(f"    Tiempo: {r.execution_time_seconds:.2f}s "
              f"(LLM: {r.llm_calls_made} calls, {r.llm_fallbacks_used} fallbacks)")

    print(f"\n  Tiempo total: {total_time:.2f}s")
    print(f"\n  Archivos generados:")
    for f in files:
        print(f"    → {f}")
    print("═" * 60)


def build_parser() -> argparse.ArgumentParser:
    """Construye el parser de argumentos CLI."""
    parser = argparse.ArgumentParser(
        prog="cascade_engine",
        description=(
            "Motor de Simulación de Cascada para Stress Testing Bancario\n"
            "G&T Continental — Gerencia de Riesgos Financieros"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Escenarios disponibles:\n"
            "  Liquidez:  liq_001, liq_002, liq_003, liq_004\n"
            "  Crédito:   cred_001, cred_002, cred_003\n"
            "  FX:        fx_001, fx_002, fx_003\n"
            "\n"
            "Ejemplos:\n"
            "  python run.py --scenario liq_001\n"
            "  python run.py --all --offline\n"
            "  python run.py --scenario liq_001 liq_002 --export json excel\n"
            "  python run.py --check\n"
        ),
    )

    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument(
        "--scenario",
        nargs="+",
        metavar="ID",
        help="Uno o más IDs de escenario a ejecutar",
    )
    group.add_argument(
        "--all",
        action="store_true",
        help="Ejecutar todos los escenarios",
    )
    group.add_argument(
        "--check",
        action="store_true",
        help="Verificar entorno sin ejecutar simulación",
    )

    parser.add_argument(
        "--offline",
        action="store_true",
        default=False,
        help="Ejecutar sin LLM (fallback determinístico)",
    )
    parser.add_argument(
        "--export",
        nargs="+",
        choices=["json", "csv", "excel"],
        default=["json", "csv", "excel"],
        help="Formatos de exportación (default: json csv excel)",
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=None,
        help="Semilla aleatoria para reproducibilidad",
    )
    parser.add_argument(
        "--output-dir",
        type=str,
        default=None,
        help="Directorio de salida (default: ./results)",
    )
    parser.add_argument(
        "--log-level",
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        default="INFO",
        help="Nivel de logging",
    )
    parser.add_argument(
        "--verbose", "-v",
        action="store_true",
        help="Modo verbose (incluye razonamiento de agentes)",
    )

    return parser


def main() -> None:
    """Entry point principal."""
    parser = build_parser()
    args = parser.parse_args()

    if args.check:
        ok = check_environment()
        sys.exit(0 if ok else 1)

    # Determinar escenarios
    if args.all:
        scenario_ids = list(ALL_SCENARIOS.keys())
    else:
        scenario_ids = args.scenario

    # Ejecutar
    results = run_simulation(
        scenario_ids=scenario_ids,
        offline=args.offline,
        export_formats=args.export,
        seed=args.seed,
        output_dir=args.output_dir,
        log_level=args.log_level,
        verbose=args.verbose,
    )

    # Exit code basado en éxito
    all_ok = all(r.success for r in results)
    sys.exit(0 if all_ok else 1)


if __name__ == "__main__":
    main()
